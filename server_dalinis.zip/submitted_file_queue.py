from celery import shared_task
from queue import Queue
import os
import sys
from . import db
from .models import Submissions, Problems
from .email_sender import email_user_submission
import subprocess
import docker

### Submitted code set ###
Submitted_code_set = set()




def cpp_kompiliatorius(user_submission_file_name):

    submission_path = f'/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}'
    submission_cpp_path = f'/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}.cpp'
    kompiliuok_cmd = ['g++', '-o', submission_path, submission_cpp_path]

    try:
        subprocess.check_output(kompiliuok_cmd, stderr=subprocess.STDOUT)
        return True, ''  # Kompiliavimas pavyko
    except subprocess.CalledProcessError as e:
        error_msg = e.output.decode()
        return False, error_msg # Kompiliavimas nepavyko




def palygink_rezultatus(rezultatai, rezultatu_failas, order_doesnt_matter):
    # Graziname TRUE, jei programos ir oficialus rezultatai sutampa
    with open(rezultatu_failas) as f:
        rezultatu_duomenys = f.read()
        if order_doesnt_matter: rezultatu_duomenys = ''.join(sorted(rezultatu_duomenys))
    return rezultatai.strip() == rezultatu_duomenys.strip()




def paleisk_programa(duomenu_failas, duomenu_failo_pavadinimas, user_submission_file_name, Testo_id, Laiko_limtas, Atminties_limitas):

    client = docker.from_env()

    program_path = f'/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}'

    volumes = {
        program_path: {'bind': '/testavimo_aplinka/programa', 'mode': 'ro'},
        duomenu_failas: {'bind': f'/testavimo_aplinka/{duomenu_failo_pavadinimas}', 'mode': 'ro'}
    }

    cpu_limit = docker.types.Ulimit(name='cpu', soft=Laiko_limtas, hard=Laiko_limtas)

    try:
        
        ## Paleidžiame vartotojo sprendima konteineryje
        output = client.containers.run(
            'testavimo_aplinka',
            ulimits=[cpu_limit],
            mem_limit=f"{str(Atminties_limitas)}m",
            memswap_limit=f"{str(Atminties_limitas)}m",
            stdout=True,
            stderr=True,
            remove=True,
            volumes=volumes,
            read_only=True,
        )

        ## Gražiname programos rezultatą
        return output.decode('utf-8'), 0

    except docker.errors.ContainerError as e:

        if e.exit_status == 139:
            # Viršytas atminties limitas
            return '', 2
        elif e.exit_status == 137 or e.exit_status == 124:
            # Viršytas laiko limitas
            return '', 1
        else:
            # Nenumatyta dalinio testavimo klaida
            return '', 5




@shared_task(bind=True, queue='submitted_file_queue')
def compile_code(self, user_id, problem_id, task_id, time_limit, memory_limit, test_count, submitted_code, open_test_cases):


    submission = Submissions.query.filter_by(celery_id=self.request.id).first()

    ## Laukiame, kol vartotojo sprendimas atsiras databazėje
    while not submission:
        submission = Submissions.query.filter_by(celery_id=self.request.id).first()

    ## Pakeičiamas vartotojo pateikto sprendimo statusas ##
    if (user_id, task_id) in Submitted_code_set:
        submission.status = -1
        db.session.commit()
        return
    else:
        submission.status = 0
        db.session.commit()

    ## Gaunama informacija apie uždavinį
    problem = Problems.query.get(problem_id)



    ### Vartotojo pateiktas sprendimas testuojamas ###
    results = []
    Submitted_code_set.add((user_id, task_id))


    ## Vartotojo pateiktas kodas paverčiamas į cpp programą
    user_submission_file_name = str(user_id) + "_" + str(task_id)
    file_path = f'/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}.cpp'

    if os.path.exists(file_path):
        try: os.remove(file_path)
        except:
            Submitted_code_set.remove((user_id, task_id))
            submission.status = 1
            db.session.commit()
            return

    with open(file_path, 'w') as f:
        f.write(submitted_code)


    ## Vartotojo pateiktas kodas sukompiliuojamas
    kompiliavimas = cpp_kompiliatorius(user_submission_file_name)
    os.remove(f'/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}.cpp')
    if kompiliavimas[0] == False:

        old_error_msg = kompiliavimas[1]
        try:
            new_error_msg = old_error_msg.replace(f"/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}.cpp:", "")
        except:
            try:
                new_error_msg = old_error_msg.replace("/home/ubuntu/Pateikti_sprendimai", "")
            except:
                new_error_msg = old_error_msg

        ## Testavimo rezultatus išsaugojame databazėje bei pabaigiame testavimą
        submission.status = 2
        submission.score = 0
        submission.results = []
        submission.error_msg = new_error_msg
        submission.output = []
        db.session.commit()

        ## Testavimo aplinka pridedama prie laisvu aplinku saraso
        Submitted_code_set.remove((user_id, task_id))
        return


    ## Jei programa kompiliuojasi, paleidziame programa
    score = 0
    rezultatu_lentele = []
    programos_rezultatai = []

    for Testo_id in range(1, test_count+1):


        ## Pasiemame uždavinio duomenų ir rezultatų failus
        duomenu_failas = f'/home/ubuntu/Testai/{problem_id}/{Testo_id}.in'
        rezultatu_failas = f'/home/ubuntu/Testai/{problem_id}/{Testo_id}.sol'


        # Paleidziame programa su testo duomenimis
        rezultatai, klaidos_kodas = paleisk_programa(duomenu_failas, problem.input_file_name, user_submission_file_name, Testo_id, problem.timeLimit, problem.memoryLimit)

        # Jei eilės tvarka nesvarbi, išrikiuojame rezultatus
        if problem.order_doesnt_matter: rezultatai = ''.join(sorted(rezultatai))
        

        # Jei programos paleidimo metu atsirado klaidu
        if klaidos_kodas != 0: rezultatu_lentele.append(klaidos_kodas)


        # Palyginame rezultatus su oficialiais rezultatais
        elif palygink_rezultatus(rezultatai, rezultatu_failas, problem.order_doesnt_matter):
            score += 1
            rezultatu_lentele.append(3)
        else:
            rezultatu_lentele.append(4)


        # Jei nustatyta, išsaugomi programos spausdinami rezultatai
        if Testo_id <= open_test_cases:
            if len(rezultatai) > 1000: rezultatai = rezultatai[:1000] + "..."
            programos_rezultatai.append(rezultatai)


    ## Pašalinamas vartotojo pateiktas sukompiliuotas kodas
    if os.path.exists(f'/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}'):
        os.remove(f'/home/ubuntu/Pateikti_sprendimai/{user_submission_file_name}')

    ## Testavimo aplinka pridedama prie laisvu aplinku saraso
    Submitted_code_set.remove((user_id, task_id))

    ## Į databazę įkeliame testavimo rezultatus
    submission.status = 3
    submission.score = score
    submission.results = rezultatu_lentele
    submission.error_msg = ''
    submission.output = programos_rezultatai
    db.session.commit()

    ## Varotojui išsiunčiamas el. laiškas
    email_user_submission.delay(submission_id=submission.id)

    ## Pabaigiame programos testavima
    return