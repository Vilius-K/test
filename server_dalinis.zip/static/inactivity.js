let inactivityTime = 3600000; // 10 sekundziu (milesekundemes)

function resetTimer() {
  clearTimeout(localStorage.logoutTimer);
  localStorage.setItem('lastActivity', Date.now());
  localStorage.logoutTimer = setTimeout(logout, inactivityTime);
}

function logout() {
  // Grazinti uiser'i atgal i login page
  window.location.href = "/logout";
}

// Tikrina ar judina pele, ar kazka spaudzia
document.addEventListener("mousemove", resetTimer);
document.addEventListener("keydown", resetTimer);
document.addEventListener("click", resetTimer);

// Jeigu langas uzdarytas, kad viestiek tikrintu
document.addEventListener("DOMContentLoaded", () => {
  const lastActivity = localStorage.getItem('lastActivity');
  if (lastActivity && Date.now() - lastActivity < inactivityTime) {
    resetTimer();
  } else {
    logout(); // Jeigu nera jokio activity, automatiskai islogoutinti
  }
});