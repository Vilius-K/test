from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for
from flask_login import login_required, current_user
from .models import Task, Problems, User, School, Submissions, NewGroup, Lessons, School_waiting_list
from datetime import datetime, timedelta
from . import db
import os
import shutil
from threading import Thread, Lock
import re

### Blueprint config ###
school_admin = Blueprint('school_admin', __name__)
lock = Lock()

defaultDate=datetime(1111, 1, 1, 11, 11, 11)

@school_admin.context_processor
def inject_len():
    return dict(len=len)

def user_school_name():
    if current_user.school_id != 0: return School.query.get(current_user.school_id).name
    else: return ''

def user_is_in_the_task_list(task_id, user_id):

    task = Task.query.get(task_id)
    for task_user_id in task.users:
        if int(task_user_id) == user_id: return True
    return False

def user_is_in_the_group_list(group_id, user_id):

    group = NewGroup.query.get(group_id)
    for group_user_id in group.students:
        if int(group_user_id) == user_id: return True
    return False

def user_is_in_the_lesson_list(lesson_id, user_id):

    lesson = Lessons.query.get(lesson_id)
    for lesson_user_id in lesson.students:
        if int(lesson_user_id) == user_id: return True
    return False

def check_filename(filename):
    
    pattern = r'^[a-zA-Z0-9_]+\.(txt|in)$'
    if re.match(pattern, filename):
        return True
    else:
        return False


@school_admin.route('/school_admin/new_problem', methods=['GET', 'POST'])
@login_required
def new_problem():

    ## Patikriname, ar neviršytas sukurtų uždavinių limitas
    school = School.query.get(current_user.school_id)
    if current_user.urole == "SCHOOL-ADMIN" and school.created_problems == school.problem_limit and request.method == 'POST':
        flash('Viršytas sukurtų uždavinių limitas.', category='error')
        return redirect(url_for('school_admin.new_problem'))

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        # Reikiama informacija apie uždavinį
        taskName = request.form.get('taskName')
        timeLimit = request.form.get('timeLimit')
        memoryLimit = request.form.get('memoryLimit')
        pdf_file = request.files.get('PDF')
        test_files = request.files.getlist("tests")
        checkbox_value = request.form.get('order_doesnt_matter')
        input_file_name = request.form.get('input_file_name')

        if timeLimit != "" and (int(timeLimit) > 3 or int(timeLimit) < 1):
            flash('Laiko limitas galimas iki 3 sekundžių.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif memoryLimit != "" and (int(memoryLimit) > 300 or int(memoryLimit) < 10):
            flash('Atminties limitas galimas nuo 10 iki 300 mb.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif len(taskName) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif len(taskName) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif len(input_file_name) < 1:
            flash('Per trumpas duomenų failo pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif len(input_file_name) >= 10:
            flash('Per ilgas duomenų failo pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        elif check_filename(input_file_name) == False or not (".txt" in input_file_name or ".in" in input_file_name):
            flash('Neteisingas duomenų failo pavadinimas. Palaikomi .txt arba .in formatai. Failo pavadinimą gali sudaryti didžiosios arba mažosios lotyniškos raidės, skaičiai bei apatinio brūkšnio "_" simbolis.', category='error')
            return redirect(url_for('school_admin.new_problem'))
        else:

            if timeLimit == "":
                timeLimit = 1
            if memoryLimit == "":
                memoryLimit = 64

            if checkbox_value:
                order_doesnt_matter_bool = True
            else:
                order_doesnt_matter_bool = False

            # Serveris tikrina ar geras PDF formatas
            if pdf_file:
                pdf_extension = os.path.splitext(pdf_file.filename)[1].lower()
                if pdf_extension != ".pdf":
                    flash('Nepalaikomas uždavinio sąlygos failo formatas. Prašome pasirinkti .pdf failą.', category='error')
                    return redirect(url_for('school_admin.new_problem'))

            # Serveris tikrina ar geras testu formatas
            IN_FILES = 0
            SOL_FILES = 0

            for test_file in test_files:

                test_extension = os.path.splitext(test_file.filename)[1].lower()

                if test_extension in [".in"]:
                    IN_FILES += 1
                elif test_extension in [".sol"]:
                    SOL_FILES += 1
                elif test_extension in [".ch"]:
                    SOL_FILES += 1
                else:
                    flash('Nepalaikomas testų failo formatas. Prašome pasirinkti .in .sol arba .ch failus.', category='error')
                    return redirect(url_for('school_admin.new_problem'))

            # Patikriname, ar tinkamas testų skaičius
            if len(test_files) % 2 != 0:
                flash('Pateiktų testų skaičius turi būti lyginis.', category='error')
                return redirect(url_for('school_admin.new_problem'))

            # Patikriname, ar IN ir SOL failų skaičius lygus
            if IN_FILES != SOL_FILES:
                flash('Duomenų ir rezultatų failų skaičius turi būti lygus.', category='error')
                return redirect(url_for('school_admin.new_problem'))

            # Patikriname, ar neviršytas sukurtų testų limitas
            if len(test_files) >= 400:
                flash('Testų failų skaičius privalo būti mažesnis nei 400.', category='error')
                return redirect(url_for('school_admin.new_problem'))

            # Į databazę įkeliame informaciją apie sukurtą užduotį
            new_problem = Problems(
                name=taskName,
                timeLimit=timeLimit,
                memoryLimit=memoryLimit,
                testCount=len(test_files) / 2,
                school_id=current_user.school_id,
                order_doesnt_matter=order_doesnt_matter_bool,
                input_file_name=input_file_name
            )
            db.session.add(new_problem)
            db.session.commit()

            # Atnaujiname sukurtų uždavinių skaičių
            school.created_problems = school.created_problems + 1
            db.session.commit()

            # Serveryje išsaugome uždavinio PDF sąlygą
            pdfName = str(new_problem.id) + '.pdf'
            pdf_file.save('/home/ubuntu/PDF_Salygos/' + pdfName)

            test_files = sorted(test_files, key=lambda x: x.filename)
            os.makedirs(os.path.join('/home/ubuntu/Testai/', str(new_problem.id)))

            # Serveryje išsaugome uždavinio testus
            EXTENSION_IN = True
            test_case_id = 1
            for test_file in test_files:
                if EXTENSION_IN:
                    test_case_name = str(test_case_id) + '.in'
                    test_file.save(os.path.join('/home/ubuntu/Testai/', str(new_problem.id), test_case_name))
                    EXTENSION_IN = False
                else:
                    test_case_name = str(test_case_id) + '.sol'
                    test_file.save(os.path.join('/home/ubuntu/Testai/', str(new_problem.id), test_case_name))
                    EXTENSION_IN = True
                    test_case_id += 1

            # Jei nauja užduotis sukurta sėkmingai
            flash('Naujas uždavinys sukurtas sėkmingai!', category='success')
            return redirect(url_for('school_admin.new_problem'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        return render_template("new-problem.html", user=current_user, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/new_task', methods=['GET', 'POST'])
@login_required
def new_task():

    ## Patikriname, ar neviršytas sukurtų užduočių limitas
    school = School.query.get(current_user.school_id)
    if current_user.urole == "SCHOOL-ADMIN" and school.created_tasks == school.task_limit and request.method == 'POST':
        flash('Viršytas sukurtų užduočių limitas.', category='error')
        return redirect(url_for('school_admin.new_task'))

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        selected_problem_id = request.form.get('selectedProblemId')
        taskName = request.form.get('taskName')
        opening_date_str = request.form.get('openingDate')
        closing_date_str = request.form.get('closingDate')
        testing_date_str = request.form.get('testingDate')
        open_test_cases = request.form.get('OpenTestCases')

        if open_test_cases == '': open_test_cases = 0
        else: open_test_cases = int(open_test_cases)

        if not selected_problem_id:
            flash('Būtina pasirinkti uždavinį.', category='error')
            return redirect(url_for('school_admin.new_task'))

        selected_problem = Problems.query.get(selected_problem_id)

        ## Patikriname, ar egzistuoja ieškomas uždavinys ir ar jis priklauso tai pačiai mokyklai
        if not selected_problem or selected_problem.school_id != current_user.school_id:
            flash('Ieškomas uždavinys neegzistuoja.', category='error')
            return redirect(url_for('school_admin.new_task'))

        selected_users = request.form.get('selectedUserIds', '').split(',')
        selected_groups = request.form.get('selectedGroupIds', '').split(',')

        selected_users = list(selected_users)
        selected_users = list(set(selected_users))
        selected_users = [x for x in selected_users if x.isdigit()]

        selected_groups = list(selected_groups)
        selected_groups = list(set(selected_groups))
        selected_groups = [x for x in selected_groups if x.isdigit()]


        ## Patikriname, ar teisingai pasirinkti mokiniai
        if selected_groups != []:
            
            for user_id in selected_users:
                user = User.query.get(user_id)
                if not user or user.school_id != current_user.school_id:
                    flash('Neteisingai pasirikti mokiniai.', category='error')
                    return redirect(url_for('school_admin.new_task'))


        ## Patikriname, ar teisingai pasirinktos grupės
        if selected_groups != []:
            
            for group_id in selected_groups:
                group = NewGroup.query.get(group_id)
                if not group or group.school_id != current_user.school_id:
                    flash('Neteisingai pasiriktos grupės.', category='error')
                    return redirect(url_for('school_admin.new_task'))
                elif group and group.school_id == current_user.school_id:
                    for group_user in group.students:
                        selected_users.append(group_user)

        ## Pašaliname dublikatus
        selected_users = list(set(selected_users))

        ## Patikriname, ar teisingai užpildyti puslapio laukeliai
        if open_test_cases != 0 and (open_test_cases < 1 or open_test_cases > selected_problem.testCount):
            flash('Neteisingai pasirinkti atvirieji testai.', category='error')
            return redirect(url_for('school_admin.new_task'))

        if not taskName:
            flash('Būtina sukurti užduoties pavadinimą.', category='error')
            return redirect(url_for('school_admin.new_task'))
        
        if len(taskName) > 50:
            flash('Per ilgas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_task'))

        if len(taskName) < 1:
            flash('Per trumpas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_task'))

        if opening_date_str == '': openingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')

        if closing_date_str == '': closingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

        if testing_date_str == '': testingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: testingDate = datetime.strptime(testing_date_str, '%Y-%m-%dT%H:%M')

        if opening_date_str != '' and openingDate.year < datetime.now().year:
            flash('Netinkama užduoties atidarymo data.', category='error')
            return redirect(url_for('school_admin.new_task'))
        elif closing_date_str != '' and closingDate < datetime.now():
            flash('Netinkama užduoties uždarymo data.', category='error')
            return redirect(url_for('school_admin.new_task'))
        elif testing_date_str != '' and testingDate < datetime.now():
            flash('Netinkama užduoties testavimo data.', category='error')
            return redirect(url_for('school_admin.new_task'))
        else:
            new_task = Task(
                problemsId=selected_problem.id,
                name=taskName,
                openingDate=openingDate,
                closingDate=closingDate,
                testingDate=testingDate,
                school_id=current_user.school_id,
                open_test_cases=open_test_cases,
                users=selected_users
            )
            db.session.add(new_task)
            db.session.commit()

            # Atnaujiname sukurtų užduočių skaičių
            school.created_tasks = school.created_tasks + 1
            db.session.commit()

            flash('Nauja užduotis sukurta sėkmingai!', category='success')
            return redirect(url_for('school_admin.new_task'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        problems = Problems.query.filter_by(school_id=current_user.school_id).all()
        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        users = User.query.filter_by(school_id=current_user.school_id, urole='GENERAL').all()
        return render_template("new-task.html", user=current_user, problems=problems, school_name=user_school_name(), groups=groups, users=users)

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/problems')
@login_required
def problems():

    if current_user.urole == "SCHOOL-ADMIN":
        school_problems = Problems.query.filter_by(school_id=current_user.school_id).all()
        return render_template("problems.html", user=current_user, school_problems=school_problems, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/problems/<problem_id>', methods=['GET', 'POST'])
@login_required
def edit_problem(problem_id):

    problem = Problems.query.get(problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST' and problem:
        name = request.form.get('name')
        timeLimit = request.form.get('timeLimit')
        memoryLimit = request.form.get('memoryLimit')
        school_problems = Problems.query.filter_by(school_id=current_user.school_id).all()

        if timeLimit != None and (int(timeLimit) > 5 or int(timeLimit) < 1):
            flash('Laiko limitas galimas iki 5 sekundžių.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        elif memoryLimit != None and (int(memoryLimit) > 500 or int(memoryLimit) < 10):
            flash('Atminties limitas galimas nuo 10 iki 500 MB.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        elif len(name) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        elif len(name) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem'))
        else:
            problem.name = name
            problem.timeLimit = timeLimit
            problem.memoryLimit = memoryLimit
            db.session.commit()
            flash('Uždavinys sėkmingai atnaujintas.', category='success')
            return redirect(url_for('school_admin.problems'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET' and problem:
        return render_template("edit_problem.html", user=current_user, problem=problem, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_problem', methods=['POST'])
@login_required
def delete_problem():

    lock.acquire()
    delete_problem_id = request.form.get('problem_id')
    delete_problem = Problems.query.get(delete_problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and delete_problem and Task.query.filter_by(problemsId=delete_problem_id).first():
        lock.release()
        flash('Šis uždavinys yra naudojamas užduotyje, todėl uždavinio ištrinti negalima.', category='error')
        return redirect(url_for('school_admin.delete_problem'))

    elif current_user.urole == "SCHOOL-ADMIN" and delete_problem and Submissions.query.filter(Submissions.status.in_([-3, -2, 0])).all():
        lock.release()
        flash('Šis uždavinys yra naudojamas vartotojo sprendimo testavime, kurio testavimas yra suplanuotas arba uždavinys yra testuojamas šiuo metu.', category='error')
        return redirect(url_for('school_admin.delete_problem'))

    elif current_user.urole == "SCHOOL-ADMIN" and delete_problem:

        db.session.delete(delete_problem)
        db.session.commit()

        # Atnaujiname sukurtų uždavinių skaičių
        school = School.query.get(current_user.school_id)
        school.created_problems = school.created_problems - 1
        db.session.commit()

        shutil.rmtree(f'/home/ubuntu/Testai/{delete_problem_id}/')
        os.remove(f'/home/ubuntu/PDF_Salygos/{delete_problem_id}.pdf')

        lock.release()
        flash('Uždavinys sėkmingai ištrintas.', category='success')
        return redirect(url_for('school_admin.problems'))

    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/tasks')
@login_required
def tasks():

    if current_user.urole == "SCHOOL-ADMIN":
        school_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        return render_template("tasks.html", user=current_user, school_tasks=school_tasks, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/tasks/<task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    task = Task.query.get(task_id)

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST' and task:
        name = request.form.get('name')
        opening_date_str = request.form.get('openingDate')
        closing_date_str = request.form.get('closingDate')

        if len(name) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
        elif len(name) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
        else:

            if opening_date_str == '':
                openingDate = datetime(1111, 1, 1, 11, 11, 11)
            else:
                openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')

            if closing_date_str == '':
                closingDate = datetime(1111, 1, 1, 11, 11, 11)
            else:
                closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

            current_datetime = datetime.now()
            if opening_date_str != '' and (openingDate.year < current_datetime.year or
                                           openingDate > current_datetime + timedelta(days=365)):
                flash('Netinkama užduoties atidarymo data.', category='error')
            elif closing_date_str != '' and (closingDate < current_datetime or
                                              closingDate > current_datetime + timedelta(days=365) or
                                              closingDate < openingDate):
                flash('Netinkama užduoties uždarymo data.', category='error')
            else:
                task.name = name
                task.openingDate = openingDate
                task.closingDate = closingDate
                db.session.commit()
                return redirect(url_for('school_admin.tasks'))

        return render_template("edit_task.html", user=current_user, task=task, school_name=user_school_name(),
                               openingDate_default=(task.openingDate == datetime(1111, 1, 1, 11, 11, 11)),
                               closingDate_default=(task.closingDate == datetime(1111, 1, 1, 11, 11, 11)))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET' and task:
        return render_template("edit_task.html", user=current_user, task=task, school_name=user_school_name(),
                               openingDate_default=(task.openingDate == datetime(1111, 1, 1, 11, 11, 11)),
                               closingDate_default=(task.closingDate == datetime(1111, 1, 1, 11, 11, 11)))
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_task', methods=['POST'])
@login_required
def delete_task():

    delete_task_id = request.form.get('task_id')
    lock.acquire()
    delete_task = Task.query.get(delete_task_id)
    if delete_task: lessons = Lessons.query.filter(Lessons.tasks.contains(delete_task.id)).all()

    if current_user.urole == "SCHOOL-ADMIN" and delete_task and lessons:
        lock.release()
        flash('Ši užduotis naudojama pamokoje, todėl jos ištrinti negalima.', category='error')
        return redirect(url_for('school_admin.delete_task'))

    elif current_user.urole == "SCHOOL-ADMIN" and delete_task and Submissions.query.filter(Submissions.status.in_([-3, -2, 0]), Submissions.task_id == delete_task.id).all():
        lock.release()
        flash('Ši užduotis yra naudojama vartotojo sprendimo testavime, kurio testavimas yra suplanuotas arba užduotis yra testuojama šiuo metu.', category='error')
        return redirect(url_for('school_admin.delete_task'))

    elif current_user.urole == "SCHOOL-ADMIN" and delete_task:

        db.session.delete(delete_task)
        db.session.commit()

        # Atnaujiname sukurtų užduočių skaičių
        school = School.query.get(current_user.school_id)
        school.created_tasks = school.created_tasks - 1
        db.session.commit()

        lock.release()
        return redirect(url_for('school_admin.tasks'))

    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/school_users')
@login_required
def school_users():
    if current_user.urole == "SCHOOL-ADMIN":
        school_users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        school_users = sorted(school_users, key=lambda user: user.first_last_name.split()[-1])
        invitation_code = School.query.get(current_user.school_id).invitation_code
        return render_template("school_users.html", user=current_user, school_users=school_users, school_name=user_school_name(), invitation_code=invitation_code)
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/delete_user/<user_id>', methods=['POST'])
@login_required
def delete_school_user(user_id):

    lock.acquire()
    user = User.query.get(user_id)

    if current_user.urole == "SCHOOL-ADMIN" and user and user.school_id == current_user.school_id and user.urole == "GENERAL":

        all_school_tasks = Task.query.filter(Task.school_id == current_user.school_id).all()
        tasks = [task for task in all_school_tasks if user_is_in_the_task_list(task.id, user.id)]

        all_school_groups = NewGroup.query.filter(NewGroup.school_id == current_user.school_id).all()
        groups = [group for group in all_school_groups if user_is_in_the_group_list(group.id, user.id)]

        all_school_lessons = Lessons.query.filter(Lessons.school_id == current_user.school_id).all()
        lessons = [lesson for lesson in all_school_lessons if user_is_in_the_lesson_list(lesson.id, user.id)]

        for task in tasks:
            task_users = task.users
            modified_task_users = [char_id for char_id in task_users if char_id != str(user.id)]
            task.users = modified_task_users
            if task.users == []: db.session.delete(task)

        for group in groups:
            group_users = group.students
            modified_group_users = [char_id for char_id in group_users if char_id != str(user.id)]
            group.students = modified_group_users
            if group.students == []: db.session.delete(group)

        for lesson in lessons:
            lesson_users = lesson.students
            modified_lesson_users = [char_id for char_id in lesson_users if char_id != str(user.id)]
            lesson.students = modified_lesson_users
            if lesson.students == []: db.session.delete(lesson)

        user.school_id = 0
        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.school_users'))

    else:
        lock.release()
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/waiting_list')
@login_required
def waiting_list():
    if current_user.urole == "SCHOOL-ADMIN":
        invitation_code = School.query.get(current_user.school_id).invitation_code
        school_waiting_list = School_waiting_list.query.filter_by(school_id=current_user.school_id).all()
        return render_template("waiting_list.html", user=current_user, school_waiting_list=school_waiting_list, school_name=user_school_name(), invitation_code=invitation_code)
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/accept_joining_request/<request_id>', methods=['POST'])
@login_required
def accept_joining_request(request_id):

    lock.acquire()
    user_joining_request = School_waiting_list.query.get(request_id)
    if user_joining_request: user = User.query.get(user_joining_request.user_id)

    if current_user.urole == "SCHOOL-ADMIN" and user_joining_request and user_joining_request.school_id == current_user.school_id:
        user.school_id = current_user.school_id
        db.session.delete(user_joining_request)
        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.waiting_list'))

    else:
        lock.release()
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/reject_joining_request/<request_id>', methods=['POST'])
@login_required
def reject_joining_request(request_id):

    lock.acquire()
    user_joining_request = School_waiting_list.query.get(request_id)

    if current_user.urole == "SCHOOL-ADMIN" and user_joining_request and user_joining_request.school_id == current_user.school_id:
        db.session.delete(user_joining_request)
        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.waiting_list'))

    else:
        lock.release()
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/new-group', methods=['GET', 'POST'])
@login_required
def new_group():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':
        group_name = request.form.get('groupName')
        selected_student_ids = request.form.get('selectedStudentId')
        student_ids_list = list(selected_student_ids)
        student_ids_list = list(set(student_ids_list))
        student_ids_list = [x for x in student_ids_list if x.isdigit()]

        ## Patikriname, ar visi pasirinkti vartotojai egzistuoja
        for student_id in student_ids_list:
            user = User.query.get(student_id)
            if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
                flash('Blogai pasirinkti grupės mokiniai.', category='error')
                return redirect(url_for('school_admin.new_group'))

        if len(group_name) > 50:
            flash('Per ilgas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_group'))
        elif len(group_name) < 1:
            flash('Per trumpas užduoties pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_group'))

        new_group = NewGroup(name=group_name, students=student_ids_list, school_id=current_user.school_id)
        db.session.add(new_group)
        db.session.commit()
        flash('Nauja grupė sukurta sėkmingai.', category='success')
        return redirect(url_for('school_admin.new_group'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        users_data = [{'id': user.id, 'first_last_name': user.first_last_name} for user in users]
        return render_template("new-group.html", user=current_user, users=users_data, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))


import json
@school_admin.route('/school_admin/groups', methods=['GET', 'POST'])
@login_required
def groups():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':

        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        students_by_group = {}

        for group in groups:

            all_school_groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
            students = User.query.filter(User.id.in_(group.students)).all()
            students_by_group[group.id] = [{"id": student.id, "name": student.first_last_name} for student in students]

        users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL")
        return render_template('groups.html', groups=groups, students_by_group=students_by_group, user=current_user, school_name=user_school_name(), users=users)

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        group_id = request.form.get('selectedGroupId')
        user_id = request.form.get('selectedUserId')

        group = NewGroup.query.get(group_id)
        user = User.query.get(user_id)

        ## Jei tokia grupė arba vartotojas neegzistuoja arba tai pačiai mokyklai nepriklauso
        if not group or not user:
            flash('Blogai pasirinktas mokinys ar grupė.', category='error')
            return redirect(url_for('school_admin.groups'))

        if group.school_id != current_user.school_id or user.school_id != current_user.school_id:
            flash('Blogai pasirinktas mokinys ar grupė.', category='error')
            return redirect(url_for('school_admin.groups'))

        ## Patikriname, ar vartotojas dar nepriklauso pasirinktai grupei
        if str(user.id) in group.students:
            flash('Mokinys jau priklauso pasirinktai grupei.', category='error')
            return redirect(url_for('school_admin.groups'))

        ## Pridedame vartotoja prie pasirinktos grupės
        current_students = group.students
        updated_students = current_students + [str(user.id)]
        group.students = updated_students
        db.session.commit()

        flash('Mokinys sėkmingai pridėtas prie pasirinktos grupės.', category='success')
        return redirect(url_for('school_admin.groups'))

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/new_lesson', methods=['GET', 'POST'])
@login_required
def new_lesson():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        name = request.form.get('lessonName')
        note = request.form.get('lessonNote')
        opening_date_str = request.form.get('openingDate')
        closing_date_str = request.form.get('closingDate')
        selected_tasks_ids = request.form.get('selectedProblemId')
        selected_users_ids = request.form.get('selectedUserId')
        tasks_ids_list = list(selected_tasks_ids)
        tasks_ids_list = list(set(tasks_ids_list))
        users_ids_list = list(selected_users_ids)
        users_ids_list = list(set(users_ids_list))

        if current_user.id in users_ids_list: users_ids_list.remove(current_user.id)
        users_ids_list = [x for x in users_ids_list if x.isdigit()]
        tasks_ids_list = [x for x in tasks_ids_list if x.isdigit()]

        if opening_date_str == '': openingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')
        if closing_date_str == '': closingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

        ## Patikriname, ar teisingai pasirinkti pamokos mokiniai
        for user_id in users_ids_list:
            user = User.query.get(user_id)
            if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
                flash('Netinkamai pasirinkti pamokos mokiniai.', category='error')
                return redirect(url_for('school_admin.new_lesson'))

        ## Patikriname, ar teisingai pasirinkti pamokos užduotys
        for task_id in tasks_ids_list:
            task = Task.query.get(task_id)
            if not task or task.school_id != current_user.school_id:
                flash('Netinkamai pasirinkti pamokos uždaviniai.', category='error')
                return redirect(url_for('school_admin.new_lesson'))
            elif openingDate != defaultDate and task.openingDate != defaultDate and task.openingDate > openingDate:
                flash(f'Uždavinio „{task.name}” atidarymo data yra vėlesnė nei pamokos atidarymo data.', category='error')
                return redirect(url_for('school_admin.new_lesson'))
            elif closingDate != defaultDate and task.closingDate != defaultDate and task.closingDate < closingDate:
                flash(f'Uždavinio „{task.name}” uždarymo data yra ankstesnė nei pamokos uždarymo data.', category='error')
                return redirect(url_for('school_admin.new_lesson'))
            elif task.users != [] and sorted(task.users) != sorted(users_ids_list):
                flash(f'Uždavinio „{task.name}” pasirinkti mokiniai arba grupės nesutampa su pamokos pasirinktais mokiniais arba grupėmis.', category='error')
                return redirect(url_for('school_admin.new_lesson'))

        if len(name) > 50:
            flash('Per ilgas pamokos pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif len(name) < 1:
            flash('Per trumpas pamokos pavadinimas.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif len(note) > 700:
            flash('Per ilga pamokos žinutė.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif opening_date_str != '' and openingDate.year < datetime.now().year:
            flash('Netinkama pamokos atidarymo data.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif closing_date_str != '' and closingDate < datetime.now():
            flash('Netinkama pamokos uždarymo data.', category='error')
            return redirect(url_for('school_admin.new_lesson'))
        elif len(tasks_ids_list) == 0:
            flash('Būtina pasirinkti bent vieną užduotį.', category='error')
            return redirect(url_for('school_admin.new_lesson'))

        new_lesson = Lessons(name=name, note=note, tasks=tasks_ids_list, openingDate=openingDate, closingDate=closingDate, students=users_ids_list,
            school_id=current_user.school_id, owner_id=current_user.id)
        db.session.add(new_lesson)
        db.session.commit()

        flash('Nauja pamoka sukurta sėkmingai.', category='success')
        return redirect(url_for('school_admin.new_lesson'))

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        return render_template('new-lesson.html', problems=tasks, user=current_user, users=users, groups=groups, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/lessons')
@login_required
def lessons():

    if current_user.urole == "SCHOOL-ADMIN":
        lessons = Lessons.query.filter_by(school_id=current_user.school_id).all()

        students_by_lesson = {}
        problems_by_lesson = {}

        for lesson in lessons:
            students = User.query.filter(User.id.in_(lesson.students)).all()
            student_names = [student.first_last_name for student in students]

            problems = Task.query.filter(Task.id.in_(lesson.tasks)).all()
            problem_names = [problem.name for problem in problems]

            students_by_lesson[lesson.id] = student_names
            problems_by_lesson[lesson.id] = problem_names

        return render_template('school_admin_lessons.html', lessons=lessons, students_by_lesson=students_by_lesson, problems_by_lesson=problems_by_lesson, user=current_user, school_name=user_school_name(), defaultDate=defaultDate)
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/delete_lesson/<lesson_id>', methods=['POST'])
@login_required
def delete_lesson(lesson_id):

    lock.acquire()
    lesson = Lessons.query.get(lesson_id)

    if current_user.urole == "SCHOOL-ADMIN" and lesson and lesson.owner_id == current_user.id:
        db.session.delete(lesson)
        db.session.commit()
        lock.release()
        flash('Pamoka sėkmingai ištrinta.', category='success')
        return redirect(url_for('school_admin.lessons'))
    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/student_submissions')
@login_required
def student_submissions():
    if current_user.urole == "SCHOOL-ADMIN":
        page = request.args.get('page', 1, type=int)
        sort = request.args.get('sort', None)
        start_date = request.args.get('start_date', None)
        end_date = request.args.get('end_date', None)
        search_name_query = request.args.get('search_name', '')
        search_task_query = request.args.get('search_task', '')
        score_filter = request.args.get('score_filter', 'all')

        submission_query = Submissions.query.join(User).join(Task).join(Problems).filter(User.school_id == current_user.school_id, User.urole == "GENERAL")

        if start_date:
            start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
            submission_query = submission_query.filter(Submissions.date >= start_date)
        if end_date:
            end_date = datetime.strptime(end_date, "%Y-%m-%d").date() + timedelta(days=1)
            submission_query = submission_query.filter(Submissions.date < end_date)

        if sort == 'oldest':
            submission_query = submission_query.order_by(Submissions.date.asc())
        elif sort == 'newest':
            submission_query = submission_query.order_by(Submissions.date.desc())

        if search_name_query:
            submission_query = submission_query.filter(User.first_last_name.ilike(f'%{search_name_query}%'))
        if search_task_query:
            submission_query = submission_query.filter(Task.name.ilike(f'%{search_task_query}%'))

        if score_filter == 'zero':
            submission_query = submission_query.filter(Submissions.score == 0)
        elif score_filter == 'max':
            submission_query = submission_query.filter(Submissions.score == Problems.testCount)
        elif score_filter == 'between':
            submission_query = submission_query.filter(Submissions.score > 0, Submissions.score < Problems.testCount)

        submissions = submission_query.paginate(page=page, per_page=10)

        return render_template('student-submissions.html', submissions=submissions, user=current_user, school_name=user_school_name(), page=page)
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_user_from_group/<user_id>/<group_id>', methods=['POST'])
@login_required
def delete_user_from_group(user_id, group_id):

    lock.acquire()
    user = User.query.get(user_id)
    group = NewGroup.query.get(group_id)

    if current_user.urole == "SCHOOL-ADMIN" and user and group and user.school_id == current_user.school_id and group.school_id == current_user.school_id and user.urole == "GENERAL":

        ## Pašaliname vartotoją iš grupės
        group_users = group.students
        modified_group_users = [char_id for char_id in group_users if char_id != str(user.id)]
        group.students = modified_group_users
        if group.students == []: db.session.delete(group)

        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.groups'))

    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_group/<group_id>', methods=['POST'])
@login_required
def delete_group(group_id):

    lock.acquire()
    group = NewGroup.query.get(group_id)

    if current_user.urole == "SCHOOL-ADMIN" and group and group.school_id == current_user.school_id:
        db.session.delete(group)
        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.groups'))

    else:
        lock.release()
        return redirect(url_for('views.home'))