from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for, Response
from flask_login import login_required, current_user
from .models import Task, Problems, User, School, Submissions, Lessons, NewGroup
from datetime import datetime, timezone
from . import db
from .submitted_file_queue import compile_code
import pytz
from celery.result import AsyncResult
from datetime import timedelta
from sqlalchemy import func, or_
import math

views = Blueprint('views', __name__)
Submitted_code_set = set()

defaultDate=datetime(1111, 1, 1, 11, 11, 11)
vilnius_tz = pytz.timezone('Europe/Vilnius')


@views.context_processor
def inject_len():
    return dict(len=len)


def user_school_name():
    if current_user.school_id != 0: return School.query.get(current_user.school_id).name
    else: return ''


def submitted_code_set_remove(user_id, problem_id):
    try: Submitted_code_set.remove((user_id,  problem_id))
    except: pass


def task_is_availible(task):

    if task.openingDate != defaultDate and task.closingDate != defaultDate and (task.openingDate <= datetime.now() and task.closingDate > datetime.now()):
        return True
    elif task.openingDate != defaultDate and task.closingDate == defaultDate and (task.openingDate <= datetime.now()):
        return True
    elif task.closingDate != defaultDate and task.openingDate == defaultDate and (task.closingDate > datetime.now()):
        return True
    elif task.openingDate == defaultDate and task.closingDate == defaultDate: return True
    else: return False


def lesson_is_availible(lesson):

    if lesson.openingDate != defaultDate and lesson.closingDate != defaultDate and lesson.openingDate <= datetime.now() and lesson.closingDate > datetime.now():
        return True
    elif lesson.openingDate != defaultDate and lesson.closingDate == defaultDate and lesson.openingDate <= datetime.now():
        return True
    elif lesson.closingDate != defaultDate and lesson.openingDate == defaultDate and lesson.closingDate > datetime.now():
        return True
    elif lesson.openingDate == defaultDate and lesson.closingDate == defaultDate:
        return True
    else:
        return False


def user_is_in_the_task_list(task_id):

    task = Task.query.get(task_id)
    for user_id in task.users:
        if int(user_id) == current_user.id: return True
    return False


def task_authorization(task_id):

    try: task = Task.query.get(task_id)
    except: return False

    if task and task.school_id == current_user.school_id and task_is_availible(task) and task.users == []:
        return True
    elif task and task.school_id == current_user.school_id and task_is_availible(task) and task.users != [] and user_is_in_the_task_list(task_id):
        return True
    elif task and task.school_id == current_user.school_id and current_user.urole == "SCHOOL-ADMIN":
        return True
    else: return False


@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    page = request.args.get('page', 1, type=int)
    sort = request.args.get('sort', None)
    start_date = request.args.get('start_date', None)
    end_date = request.args.get('end_date', None)
    search_query = request.args.get('search', '')

    all_school_tasks = Task.query.filter(Task.school_id == current_user.school_id).all()
    if current_user.urole == "GENERAL": result = [task for task in all_school_tasks if task_authorization(task.id)]
    else: result = all_school_tasks

    if start_date:
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        result = [task for task in result if task.date >= start_date]
    if end_date:
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date() + timedelta(days=1)
        result = [task for task in result if task.date < end_date]

    if sort == 'oldest':
        result.sort(key=lambda task: task.date)
    elif sort == 'newest':
        result.sort(key=lambda task: task.date, reverse=True)

    num_tasks_per_page = 10
    start_idx = (page - 1) * num_tasks_per_page
    end_idx = start_idx + num_tasks_per_page
    tasks_to_display = result[start_idx:end_idx]

    if search_query:
        tasks_to_display = [task for task in tasks_to_display if search_query.lower() in task.name.lower()]

    num_pages = math.ceil(len(tasks_to_display) / num_tasks_per_page)
    has_prev_page = page > 1
    has_next_page = page < num_pages

    return render_template(
        'home.html',
        tasks=tasks_to_display,
        user=current_user,
        page=page,
        prev_page=page - 1 if has_prev_page else None,
        next_page=page + 1 if has_next_page else None,
        has_prev_page=has_prev_page,
        has_next_page=has_next_page,
        search_query=search_query,
        start_date=start_date,
        end_date=end_date,
        sort=sort,
        school_name=user_school_name()
    )


@views.route('/pdf/<task_id>')
@login_required
def pdf(task_id):

    task = Task.query.get(task_id)

    if task and task_authorization(task.id):
        path = f'/home/ubuntu/PDF_Salygos/{task.problemsId}.pdf'
        return send_file(path)
    else:
        return redirect(url_for('views.home'))



@views.route('/task/<task_id>', methods=['GET', 'POST'])
@login_required
def task(task_id):

    task = Task.query.filter_by(id=task_id).first()
    if not task: return redirect(url_for('views.home'))
    problem = Problems.query.get(task.problemsId)


    if request.method == 'POST' and task and task_authorization(task.id):

        submitted_code = request.form.get('submitted_code')

        ### Jei vartotojo pateiktas sprendimas yra per ilgas:
        if len(submitted_code) >= 560000:
            flash('Pateiktas sprendimas yra per ilgas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))
        elif len(submitted_code) < 1:
            flash('Pateiktas sprendimas yra per trumpas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))

        ### Vartotojo pateiktas sprendimas yra perduodamas pateiktų sprendimų eilei
        if Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-2).first():
            flash('Vienu metu gali būti pateiktas tik vienas suplanuotas sprendimas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))

        elif Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-3).first():
            flash('Vienu metu gali būti pateiktas tik vienas sprendimas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))

        elif Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=0).first():
            flash('Vienu metu gali būti pateiktas tik vienas sprendimas.', category='error')
            return redirect(url_for('views.task', task_id=task_id))

        ### Vartotojo pateiktas sprendimas yra įkeliamas į databazę
        if task.testingDate == defaultDate or task.testingDate <= datetime.now():
            user_submission_status = -3
        else:
            user_submission_status = -2

        new_submission = Submissions(user_id=current_user.id, task_id=task.id, status=user_submission_status, submitted_code=submitted_code)
        db.session.add(new_submission)
        db.session.commit()

        ### Vartotojo sprendimas perduodamas pateiktų sprendimų eilei
        if user_submission_status == -3:
            user_submission = compile_code.delay(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount,
                submitted_code, task.open_test_cases)
        else:
            vilnius_dt = vilnius_tz.localize(task.testingDate)
            user_submission = compile_code.apply_async(args=(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount, submitted_code, task.open_test_cases),
                eta=vilnius_dt.astimezone(pytz.UTC))

        ### Celery ID kodas išsaugomas databazėje
        new_submission.celery_id = user_submission.id
        db.session.commit()

        if user_submission_status == -3:
            flash('Sprendimas gautas ir šiuo metu yra vertinamas.', category='success')
        else:
            flash(f'Sprendimas gautas ir bus vertinamas {task.testingDate}', category='success')

        return redirect(url_for('views.task', task_id=task_id))

    elif not task_authorization(task.id):
        flash('Užduotis neegzistuoja arba jūs neturite teisės jos pasiekti.', category='error')
        return redirect(url_for('views.home'))

    elif request.method == 'GET':
        return render_template('task.html', task_id=task.id, task_name=task.name, user=current_user, school_name=user_school_name())

    else:
        return redirect(url_for('views.home'))



@views.route('/submissions')
@login_required
def submissions():

    page = request.args.get('page', 1, type=int)
    sort = request.args.get('sort', None)
    start_date = request.args.get('start_date', None)
    end_date = request.args.get('end_date', None)
    search_task_query = request.args.get('search_task', '')
    score_filter = request.args.get('score_filter', 'all')

    submission_query = Submissions.query.join(User).join(Task).join(Problems).filter(User.id == current_user.id)

    if start_date:
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        submission_query = submission_query.filter(Submissions.date >= start_date)
    if end_date:
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date() + timedelta(days=1)
        submission_query = submission_query.filter(Submissions.date < end_date)

    if sort == 'oldest':
        submission_query = submission_query.order_by(Submissions.date.asc())
    elif sort == 'newest':
        submission_query = submission_query.order_by(Submissions.date.desc())

    if search_task_query:
        submission_query = submission_query.filter(Task.name.ilike(f'%{search_task_query}%'))

    if score_filter == 'zero':
        submission_query = submission_query.filter(Submissions.score == 0)
    elif score_filter == 'max':
        submission_query = submission_query.filter(Submissions.score == Problems.testCount)
    elif score_filter == 'between':
        submission_query = submission_query.filter(Submissions.score > 0, Submissions.score < Problems.testCount)

    submissions = submission_query.paginate(page=page, per_page=10)

    return render_template('submissions.html', submissions=submissions, user=current_user, school_name=user_school_name(), page=page)



@views.route('/submissions/view_submission/<submission_id>')
@login_required
def view_submission(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission: submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id:
        response = Response(submission.submitted_code, content_type='text/plain')
        filename = f'{submission.task.name}.cpp'
        filename_encoded = filename.encode('utf-8')
        response.headers.set('Content-Disposition', 'attachment', filename=filename_encoded)
        return response

    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id:
        response = Response(submission.submitted_code, content_type='text/plain')
        filename = f'{submission.task.name}.cpp'
        filename_encoded = filename.encode('utf-8')
        response.headers.set('Content-Disposition', 'attachment', filename=filename_encoded)
        return response

    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/resubmit/<submission_id>')
@login_required
def resubmit(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission and submission.user_id == current_user.id and submission.status == -1:

        task = Problems.query.get(submission.task_id)

        if task.testingDate == defaultDate or task.testingDate <= datetime.now():
            user_submission = compile_code.delay(current_user.id,  task.problems.id, task.id, task.problems.timeLimit, task.problems.memoryLimit, task.problems.testCount,
                submission.submitted_code, task.open_test_cases)
            submission.status = -3
        
        else:
            vilnius_dt = vilnius_tz.localize(task.testingDate)
            user_submission = compile_code.apply_async(args=(current_user.id,  task.problems.id, task.id, task.problems.timeLimit, task.problems.memoryLimit, task.problems.testCount,
                submission.submitted_code, task.open_test_cases),
                eta=vilnius_dt.astimezone(pytz.UTC))
            submission.status = -2

        db.session.commit()
        flash('Sprendimas pateiktas iš naujo.', category='success')
        return redirect(url_for('views.submissions'))
    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/cancel_submission/<submission_id>')
@login_required
def cancel_submission(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission and submission.user_id == current_user.id and (submission.status == -2 or submission.status == -3):

        result = AsyncResult(submission.celery_id)

        if result.status == 'PENDING':
            result.revoke(terminate=True)
            db.session.delete(submission)
            db.session.commit()
            flash('Sprendimo testavimas buvo atšauktas.', category='success')

        else:
            flash('Sprendimo testavimo atšaukti nepavyko.', category='error')

        return redirect(url_for('views.submissions'))
    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/error/<submission_id>')
@login_required
def submission_error(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission: submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id and submission.status == 2:
        return submission.error_msg
    elif submission and submission_user.school_id == current_user.school_id and submission.status == 2:
        return submission.error_msg
    else:
        return redirect(url_for('views.home'))


@views.route('/submissions/testing_results/<submission_id>')
@login_required
def testing_results(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission: submission_user = User.query.get(submission.user_id)

    ## Jei nėra ištrinta sprendimo užduotis
    if submission and submission.task and submission.user_id == current_user.id and submission.status == 3:
        return render_template('results.html', results=submission.results, user=current_user, school_name=user_school_name(), task_name=submission.task.name,
            date=submission.date, score=submission.score, test_count=submission.task.problems.testCount, open_test_cases=submission.task.open_test_cases, id=submission.id, task_id=submission.task.id)
    
    elif submission and submission.task and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id and submission.status == 3:
        return render_template('results.html', results=submission.results, user=current_user, school_name=user_school_name(), task_name=submission.task.name,
            date=submission.date, score=submission.score, test_count=submission.task.problems.testCount, open_test_cases=submission.task.open_test_cases, id=submission.id, task_id=submission.task.id)
    
    ## Jei yra ištrinta sprendimo užduotis
    elif submission and submission.user_id == current_user.id and submission.status == 3:
        return render_template('results_no_task.html', results=submission.results, user=current_user, school_name=user_school_name(),
            date=submission.date, score=submission.score, id=submission.id)
    
    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id and submission.status == 3:
        return render_template('results_no_task.html', results=submission.results, user=current_user, school_name=user_school_name(),
            date=submission.date, score=submission.score, id=submission.id)

    else:
        return redirect(url_for('views.home'))



@views.route('/task/<task_id>/test_case/<test_case_id>/<test_type>')
@login_required
def test_case_input_output(task_id, test_case_id, test_type):

    task_id = int(task_id)
    test_case_id = int(test_case_id)
    task = Task.query.get(task_id)
    if task: problem = Problems.query.get(task.problemsId)

    if task and problem and task_authorization(task_id) and test_case_id >= 1 and test_case_id <= task.open_test_cases:

        if test_type == "IN":
            return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.in')
            try: return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.in')
            except: return redirect(url_for('views.home'))

        elif test_type == "SOL":
            try: return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.sol')
            except: return redirect(url_for('views.home'))

        else: return redirect(url_for('views.home'))

    else:
        return redirect(url_for('views.home'))



@views.route('/task/<submission_id>/test_case/<test_case_id>')
@login_required
def user_test_case_output(submission_id, test_case_id):

    submission_id = int(submission_id)
    test_case_id = int(test_case_id)
    submission = Submissions.query.get(submission_id)

    if submission: submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id and test_case_id >= 1 and test_case_id <= submission.task.open_test_cases:

        output = submission.output[test_case_id-1]
        response = Response(output, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{test_case_id}.sol')
        return response

    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id and test_case_id >= 1 and test_case_id <= submission.task.open_test_cases:

        output = submission.output[test_case_id-1]
        response = Response(output, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{test_case_id}.sol')
        return response

    else: 
        return redirect(url_for('views.home'))



@views.route('/lessons')
@login_required
def lessons():

    lessons = Lessons.query.filter(or_(Lessons.students.contains(current_user.id), Lessons.students == [])).all()
    available_lessons = [lesson for lesson in lessons if lesson_is_availible(lesson)]
    lessons = available_lessons
    tasks_for_all_lessons = []

    for lesson in lessons:
        tasks = Task.query.filter(Task.id.in_(lesson.tasks)).all()
        tasks_for_all_lessons.append(tasks)

    return render_template('lessons.html', lessons=lessons, user=current_user, school_name=user_school_name(), tasks_for_all_lessons=tasks_for_all_lessons, lesson_id=0, defaultDate=defaultDate)


@views.route('/edit_user', methods=['GET', 'POST'])
@login_required
def edit_user():

    if request.method == 'POST':

        user = User.query.get(current_user.id)
        first_last_name = request.form.get('first_last_name')
        email = request.form.get('email')
        user_by_email = User.query.filter_by(email=email).first()

        if user.email != email and user_by_email:
            flash('El. pašto adresas jau panaudotas.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(email) < 4:
            flash('El. pašto adresas turi būti ilgesnis nei 3 simboliai.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(email) > 150:
            flash('El. pašto adresas turi būti trumpesnis nei 150 simbolių.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(first_last_name) < 3:
            flash('Vartotojo vardas ir pavardė turi būti ilgesni nei 3 simboliai.', category='error')
            return redirect(url_for('views.edit_user'))
        elif len(first_last_name) > 40:
            flash('Vartotojo vardas ir pavardė būti trumpesni nei 40 simbolių.', category='error')
            return redirect(url_for('views.edit_user'))

        user.first_last_name = first_last_name
        user.email = email
        db.session.commit()
        flash('Varotojo duomenys sėkmingai atnaujinti.', category='success')
        return redirect(url_for('views.edit_user'))

    else:
        return render_template('edit_user.html', user=current_user, school_name=user_school_name())