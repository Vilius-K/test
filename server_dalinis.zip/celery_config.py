from celery import Celery

def make_celery(app):
    celery = Celery(
        app.import_name,
        broker=app.config['CELERY_CONFIG']['broker_url'],
        backend=app.config['CELERY_CONFIG']['result_backend']
    )
    celery.conf.update(app.config['CELERY_CONFIG'])

    ## Nustatome kelias Celery eiles
    celery.conf.task_queues = {
        'submitted_file_queue': {
            'exchange': 'submitted_file_queue_exchange',
            'routing_key': 'submitted_file_queue',
        },
        'email_sender': {
            'exchange': 'email_sender_exchange',
            'routing_key': 'email_sender',
        },
    }

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask

    return celery