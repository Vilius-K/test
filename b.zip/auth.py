from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from .models import User, School, School_waiting_list, Password_reset_request, User_settings, Email_verification
from werkzeug.security import generate_password_hash, check_password_hash
from . import db
from flask_login import login_user, login_required, logout_user, current_user
from datetime import datetime, timedelta
import random
from .email_sender import email_verification_code, delete_password_reset_request
import string
import pytz
from google.oauth2 import id_token
from google.auth.transport import requests
import json
import secrets
from PIL import Image, ImageDraw, ImageFont


auth = Blueprint('auth', __name__)
vilnius_tz = pytz.timezone('Europe/Vilnius')


def generate_profile_icon(ProfileUser):

    colors = ["#aa47bc", "#7a1fa2", "#78909c", "#465a65", "#ec407a", "#c2175b", 
          "#5c6bc0", "#0288d1", "#00579d", "#0098a6", "#00887a", "#004c3f", 
          "#689f39", "#33691e", "#8c6e63", "#5d4038", "#7e57c2", "#512da7", 
          "#ef6c00", "#f5511e", "#bf360c"]

    special_letters = ["Č", "Ė", "Š", "Ū", "Ž"]

    if not ProfileUser.first_last_name:
        raise ValueError("Username cannot be empty")
    
    # Get the first letter of the username and handle Lithuanian letters
    first_letter = ProfileUser.first_last_name[0].upper()

    # Choose a random background color
    bg_color = random.choice(colors)

    # Create a blank image with the background color
    img = Image.new('RGB', (320, 320), color=bg_color)

    # Initialize ImageDraw
    draw = ImageDraw.Draw(img)

    # Load the specific font file
    try:
        font_size = 180
        font = ImageFont.truetype("/home/ubuntu/Ubuntu.ttf", font_size)  # Use the font file provided
    except IOError:
        # Fallback to a built-in font with a smaller size
        font_size = 100
        font = ImageFont.load_default()

    # Calculate text size and position for accurate centering
    bbox = draw.textbbox((0, 0), first_letter, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    text_x = (320 - text_width) // 2
    text_y = (320 - text_height) // 2
    
    if first_letter in special_letters:
        text_y -= 12
    else:
        text_y -= 40

    draw.text((text_x, text_y), first_letter, fill="white", font=font)
    img.save(f"/home/ubuntu/Profile_images/{ProfileUser.id}.png")  # This will save the image


@auth.route('/defaultProfileImg/<userID>')
@login_required
def defaultProfileImg(userID):

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400

    user = User.query.get(userID)
    if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
        flash('Vartotojas, kuriam norima nustatyti numatytąją profilio reikšmę, neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
        return redirect(url_for('school_admin.school_users'))

    ## Sugeneruojama numatytoji profilio nuotrauka
    generate_profile_icon(user)

    flash('Vartotojo profilio nuotrauka sėkmingai pakeista į numatytąją reikšmę.', category='success')
    return redirect(url_for('school_admin.user_info', user_id=user.id))


@auth.route('/banProfileImg/<userID>')
@login_required
def banProfileImg(userID):

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400

    user = User.query.get(userID)
    if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
        flash('Vartotojas, kuriam norima nustatyti numatytąją profilio reikšmę, neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
        return redirect(url_for('school_admin.school_users'))

    ## Vartotojui užblokuojama profilio pakeitimo funkcija
    user.profileImgBan = True
    db.session.commit()

    ## Sugeneruojama numatytoji profilio nuotrauka
    generate_profile_icon(user)

    flash('Vartotojo profilio nuotraukos keitimo funkcija buvo sėkmingai užblokuota.', category='success')
    return redirect(url_for('school_admin.user_info', user_id=user.id))


@auth.route('/unbanProfileImg/<userID>')
@login_required
def unbanProfileImg(userID):

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400

    user = User.query.get(userID)
    if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
        flash('Vartotojas, kuriam norima nustatyti numatytąją profilio reikšmę, neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
        return redirect(url_for('school_admin.school_users'))

    ## Vartotojui užblokuojama profilio pakeitimo funkcija
    user.profileImgBan = False
    db.session.commit()

    flash('Vartotojo profilio nuotraukos keitimo funkcija buvo sėkmingai atblokuota.', category='success')
    return redirect(url_for('school_admin.user_info', user_id=user.id))


@auth.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        data = request.get_json()
        email = data.get('email')
        password = data.get('password')

        ## Surandamas vartotojas pagal nurodytą el. paštą
        user = User.query.filter_by(email=email).first()
        if user: user_school = School.query.filter_by(id=user.school_id).first()

        login_user(user, remember=True)
        return jsonify({'redirect': '/school_admin/student_submissions'}), 200

        ## Jeigu toks vartotojas neegzistuoja arba nurodytas neteisingas paskyros slaptažodis
        if not user or not check_password_hash(user.password, password):
            return jsonify({'error': 'Neteisingas el. pašto adresas ir/arba slaptažodis.'}), 400

        ## Jeigu vartotojo mokyklos galiojimo laikas pasibaigęs
        if user_school and user_school.availible_until <= datetime.now():
            return jsonify({'error': 'Mokyklos paskyros galiojimo laikas pasibaigęs. Susisiekite su mokyklos administratoriumi.'}), 400

        ## Jei vartotojo el. pašto adresas nera patvirtintas
        if not user.emailVerified:

            ## Sugeneruojamas patvirtinimo kodas
            verification_code = secrets.randbelow(9000) + 1000
            same_verification_code = Email_verification.query.filter_by(code=verification_code).first()
            while same_verification_code:
                verification_code = secrets.randbelow(9000) + 1000
                same_verification_code = Email_verification.query.filter_by(code=verification_code).first()

            ## Jei yra senas patvirtinimas, jį ištriname
            old_verification = Email_verification.query.filter_by(user_id=user.id).first()
            if old_verification:
                db.session.delete(old_verification)
                db.session.commit()

            ## Sukuriame naują patvirtinimą
            new_verification = Email_verification(user_id=user.id, code=verification_code)
            db.session.add(new_verification)
            db.session.commit()

            ## Išsiunčiame patvirtinimą
            email_verification_code.delay(user.id, verification_code, "El. pašto adreso patvirtinimo kodas")
            return jsonify({'redirect': 'emailVerification'}), 200

        ## Jei vartotojui dar nėra priskirta mokykla
        if user.school_id == 0:
            return jsonify({'redirect': 'watingList'}), 200

        ## Nukreipiame vartotoją į atitinkamą puslapį
        login_user(user, remember=True)

        if user.urole == "SCHOOL-ADMIN":
            return jsonify({'redirect': '/school_admin/student_submissions'}), 200
        else:
            return jsonify({'redirect': '/'}), 200

    return render_template("login.html", user=current_user)


@auth.route('/api/google_login', methods=['POST'])
def google_login():

    token = request.form['credential']
    CLIENT_ID = "818513483833-gavi2lfft7njn3r3nrma0j4fj76s190b.apps.googleusercontent.com"

    try:
        
        idinfo = id_token.verify_oauth2_token(token, requests.Request(), CLIENT_ID)
        exp_date = datetime.utcfromtimestamp(idinfo['exp'])

        if idinfo['aud'] != CLIENT_ID:
            flash('Klaida: neteisinga Google paskyros žymė', category='error')
            return redirect(url_for('auth.login'))

        if not(idinfo['iss'] == "https://accounts.google.com" or idinfo['iss'] == "accounts.google.com"):
            flash('Klaida: neteisinga Google paskyros žymė', category='error')
            return redirect(url_for('auth.login'))

        if exp_date < datetime.utcnow():
            flash('Klaida: prisijungimo užklausa nebegalioja', category='error')
            return redirect(url_for('auth.login'))

        ## Ieškome vartotojo
        user = User.query.filter_by(google_sub=idinfo['sub']).first()

        if not user:

            user = User.query.filter_by(email=idinfo['email']).first()
            if user:
                user.google_sub = idinfo['sub']
                db.session.commit()
                login_user(user, remember=True)
                if user.urole == "SCHOOL-ADMIN":
                    return redirect(url_for('school_admin.student_submissions'))
                else:
                    return redirect(url_for('views.home'))
            else:
                flash('Paskyra neegzistuoja. Įsitikinkite, kad Google paskyros el. pašto adresas sutampa su platformos paskyros el. pašto adresu.', category='error')
                return redirect(url_for('auth.login'))

        else:
            login_user(user, remember=True)
            if user.urole == "SCHOOL-ADMIN":
                return redirect(url_for('school_admin.student_submissions'))
            else:
                return redirect(url_for('views.home'))

    except ValueError:
        flash('Klaida: prisijungimo užklausa nebegalioja', category='error')
        return redirect(url_for('auth.login'))


@auth.route('/verifyEmail', methods=['POST'])
def verifyEmail():

    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    code = data.get('code')

    ## Surandame vartotoją pagal el. pašto adresą
    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password, password):
        return jsonify({'error': 'Neteisingas prisijungimo metu įvestas el. pašto adresas ir/arba slaptažodis. Bandykite prisijungti dar kartą.'}), 400

    ## Patikriname patvirtinimo kodą
    verification = Email_verification.query.filter_by(user_id=user.id).first()
    if not verification or verification.code != code:
        return jsonify({'error': 'Neteisingas patvirtinimo kodas.'}), 400

    ## Patikriname ar patvirtinimo kodas dar galioja
    request_date = datetime.strptime(verification.code_request_date, "%Y-%m-%d %H:%M:%S.%f")
    if request_date + timedelta(minutes=10) <= datetime.now():
        return jsonify({'error': 'Baigėsi patvirtinimo kodo galiojimo laikas. Bandykite prisijungti iš naujo.'}), 400

    ## Patvirtiname vartotojo el. pašto adresą
    user.emailVerified = True
    db.session.delete(verification)
    db.session.commit()

    ## Nukreipiame vartotoją į atitinkamą puslapį
    login_user(user, remember=True)
    if user.urole == "SCHOOL-ADMIN":
        return jsonify({'redirect': '/school_admin/student_submissions'}), 200
    elif user.school_id == 0:
        return jsonify({'redirect': 'watingList'}), 200
    else:
        return jsonify({'redirect': '/'}), 200


@auth.route('/password_reset')
def password_reset():
    return render_template("password_reset.html")


@auth.route('/password_reset_request', methods=['POST'])
def password_reset_request():

    data = request.get_json()
    email = data.get('email')

    ## Sugeneruojamas patvirtinimo kodas
    verification_code = secrets.randbelow(9000) + 1000
    same_verification_code = Password_reset_request.query.filter_by(code=verification_code).first()
    while same_verification_code:
        verification_code = secrets.randbelow(9000) + 1000
        same_verification_code = Password_reset_request.query.filter_by(code=verification_code).first()

    ## Surandamas vartotojas pagal nurodytą el. paštą
    user = User.query.filter_by(email=email).first()

    ## Jei toks vartotojas egzistuoja ir jau yra sukurta slaptažodžio pakeitimo užklausa, pašaliname ją
    if user:
        reset_request = Password_reset_request.query.filter_by(user_id=user.id).first()
        if reset_request:
            db.session.delete(reset_request)
            db.session.commit()

    ## Jei toks vartotojas egzistuoja, išsiunčiame jam el. laišką su patvirtinimo kodu
    if user:
        new_password_reset_request = Password_reset_request(user_id=user.id, code=verification_code)
        db.session.add(new_password_reset_request)
        db.session.commit()

        email_verification_code.delay(user.id, verification_code, "Slaptažodžio pakeitimo užklausos patvirtinimo kodas")
        delete_datetime = datetime.now() + timedelta(minutes=10)
        vilnius_dt = vilnius_tz.localize(delete_datetime)
        delete_password_reset_request.apply_async(args=(new_password_reset_request.id,), eta=vilnius_dt.astimezone(pytz.UTC))

    return jsonify({'success': "Patvirtinimo kodas sėkmingai išsiųstas."}), 200


@auth.route('/submitPasswordResetCode', methods=['POST'])
def submitPasswordResetCode():

    data = request.get_json()
    code = data.get('code')

    ## Ieškome slaptažodžio pakeitimo užklausos pagal nurodytą kodą
    password_reset_request = Password_reset_request.query.filter_by(code=code).first()

    if not password_reset_request:
        return jsonify({'error': "Slaptažodžio pakeitimo užklausos kodas neteisingas arba baigėsio jo galiojimo laikas."}), 400

    request_date = datetime.strptime(password_reset_request.request_date, "%Y-%m-%d %H:%M:%S.%f")
    if request_date + timedelta(minutes=10) <= datetime.now():
        db.session.delete(password_reset_request)
        db.session.commit()
        return jsonify({'error': "Slaptažodžio pakeitimo užklausos kodas neteisingas arba baigėsio jo galiojimo laikas."}), 400

    ## Patvirtiname slaptažodžio pakeitimo užklausą
    password_reset_request.verified = True
    password_reset_request.verification_date = datetime.now()
    db.session.commit()

    return jsonify({'success': "Slaptažodžio pakeitimo užklausa sėkmingai patvirtinta."}), 200


@auth.route('/createNewPassword', methods=['POST'])
def createNewPassword():

    data = request.get_json()
    code = data.get('code')
    password1 = data.get('password1')
    password2 = data.get('password2')

    ## Ieškome slaptažodžio pakeitimo užklausos pagal nurodytą kodą
    password_reset_request = Password_reset_request.query.filter_by(code=code).first()

    ## Jeigu slaptažodžio pakeitimo užklausa neegzistuoja arba nėra patvirtinta
    if not password_reset_request or not password_reset_request.verified:
        return jsonify({'error': "Slaptažodžio pakeitimo užklausa neegzistuoja arba nėra patvirtinta"}), 400

    ## Jeigu baigėsi laikas, skirtas sukurti naują slaptažodį
    verification_date = datetime.strptime(password_reset_request.verification_date, "%Y-%m-%d %H:%M:%S.%f")
    if verification_date + timedelta(minutes=10) <= datetime.now():
        db.session.delete(password_reset_request)
        db.session.commit()
        return jsonify({'error': "Baigėsi laikas, skirtas sukurti naują slaptažodį. Bandykite per naujo."}), 400

    ## Jei slaptažodžiai nesutampa
    if password1 != password2:
        return jsonify({'error': "Klaida: slaptažodžiai nesutampa."}), 400

    user = User.query.get(password_reset_request.user_id)
    if not user:
        db.session.delete(password_reset_request)
        db.session.commit()
        return jsonify({'error': "Paskyra, kuriai norima pakeisti slaptažodį, nebeegzistuoja."}), 400

    ## Pakeičiame vartotojo slaptažodį
    user.password = generate_password_hash(password1, method='sha256')
    db.session.delete(password_reset_request)
    db.session.commit()

    return jsonify({'success': "Slaptažodis sėkmingai atnaujintas."}), 200


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))


@auth.route('/loginForced')
@login_required
def loginForced():
    current_user.loginForced = True
    db.session.commit()
    logout_user()
    return redirect(url_for('auth.login'))


@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():

    if request.method == 'POST':

        data = request.get_json()
        first_last_name = data.get('first_last_name')
        email = data.get('email')
        password1 = data.get('password1')
        password2 = data.get('password2')
        invitation_code = data.get('invitation_code')

        ## Pagal nurodytą pakvietimo kodą surandame mokyklą
        user = User.query.filter_by(email=email).first()
        user_school = School.query.filter_by(invitation_code=invitation_code).first()

        if user:
            return jsonify({'error': "Klaida: El. pašto adresas jau panaudotas."}), 400
        elif len(email) < 4:
            return jsonify({'error': "El. pašto adresas turi būti ilgesnis nei 3 simboliai."}), 400
        elif len(email) > 150:
            return jsonify({'error': "El. pašto adresas turi būti trumpesnis nei 150 simbolių."}), 400
        elif len(first_last_name) <= 4:
            return jsonify({'error': "Vartotojo vardas ir pavardė kartu sudėjus turi sudaryti bent 4 simbolius."}), 400
        elif len(first_last_name) >= 40:
            return jsonify({'error': "Vartotojo vardas ir pavardė kartu sudėjus turi sudaryti ne daugiau nei 40 simbolių."}), 400
        elif password1 != password2:
            return jsonify({'error': "Klaida: Slpatažodžiai nesutampa."}), 400
        elif len(password1) < 7:
            return jsonify({'error': "Slptažodis turi būti ilgesnis nei 6 simboliai."}), 400
        elif len(password1) > 150:
            return jsonify({'error': "Slptažodis turi būti trumpesnis nei 150 simbolių."}), 400
        elif not user_school:
            return jsonify({'error': "Nurodytas netinkamas mokyklos prisijungimo kodas."}), 400
        elif user_school.availible_until != datetime(1111, 1, 1, 11, 11, 11) and user_school.availible_until < datetime.now():
            return jsonify({'error': "Mokyklos paskyros galiojimo laikas pasibaigęs. Susisiekite su mokyklos administratoriumi"}), 400
        else:

            ## Sukuriamas naujas vartotojas
            new_user = User(email=email, first_last_name=first_last_name, password=generate_password_hash(
                password1, method='sha256'), urole="GENERAL")
            db.session.add(new_user)
            db.session.commit()

            new_user_settings = User_settings(user_id=new_user.id)
            db.session.add(new_user_settings)
            db.session.commit()

            ## Sukuriama nauja vartotojo profilio nuotrauka
            generate_profile_icon(new_user)

            ## Užregistruojamas prašymas patekti į mokyklą
            new_school_joining_request = School_waiting_list(user_id=new_user.id, school_id=user_school.id)
            db.session.add(new_school_joining_request)
            db.session.commit()

            ## Sugeneruojamas el. pašto adreso patvirtinimo kodas
            verification_code = secrets.randbelow(9000) + 1000
            same_verification_code = Email_verification.query.filter_by(code=verification_code).first()
            while same_verification_code:
                verification_code = secrets.randbelow(9000) + 1000
                same_verification_code = Email_verification.query.filter_by(code=verification_code).first()

            ## Sukuriame naują el. pašto adreso patvirtinimą
            new_verification = Email_verification(user_id=new_user.id, code=verification_code)
            db.session.add(new_verification)
            db.session.commit()

            ## Išsiunčiame el. pašto adreso patvirtinimą
            email_verification_code.delay(new_user.id, verification_code, "El. pašto adreso patvirtinimo kodas")
            return jsonify({'success': "Paskyra sukurta sėkmingai."}), 200

    return render_template("sign_up.html", user=current_user)