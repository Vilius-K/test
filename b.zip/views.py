from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for, Response
from flask_login import login_required, current_user, logout_user
from .models import Task, Problems, User, School, Submissions, NewGroup, Messages, User_settings, User_class, Tag, CompetitiveTaskResult, GlobalMessage, CompetitiveTaskCopy, Contest, CodeComment, Profile_delete_request, School_waiting_list, Password_reset_request, Plagiarism_pair, TaskDraft
from datetime import datetime, timezone
from . import db
from .submitted_file_queue import compile_code
import pytz
from celery.result import AsyncResult
from datetime import timedelta
from sqlalchemy import func, or_, Column, and_
import math
from .email_sender import email_new_message, email_competitive_task_end, email_competitive_task_reminder, email_verification_code, email_msg
from .competitive_task_queue import end_competitive_task
from .ranking import competitive_task_ranking
from itertools import groupby
from sqlalchemy.orm.attributes import flag_modified
import json
import os
import mimetypes
from PIL import Image
from werkzeug.security import check_password_hash
import secrets
import csv
from io import StringIO


views = Blueprint('views', __name__)
Submitted_code_set = set()

defaultDate=datetime(1111, 1, 1, 11, 11, 11)
vilnius_tz = pytz.timezone('Europe/Vilnius')


@views.context_processor
def inject_len():
    return dict(len=len)


def user_school_name():
    if current_user.school_id != 0: return School.query.get(current_user.school_id).name
    else: return ''


def submitted_code_set_remove(user_id, problem_id):
    try: Submitted_code_set.remove((user_id,  problem_id))
    except: pass


def task_is_availible(task):

    if task.openingDate != defaultDate and task.closingDate != defaultDate and (task.openingDate <= datetime.now() and task.closingDate > datetime.now()):
        return True
    elif task.openingDate != defaultDate and task.closingDate == defaultDate and (task.openingDate <= datetime.now()):
        return True
    elif task.closingDate != defaultDate and task.openingDate == defaultDate and (task.closingDate > datetime.now()):
        return True
    elif task.openingDate == defaultDate and task.closingDate == defaultDate: return True
    else: return False


def topic_is_availible(topic):

    if topic.openingDate != defaultDate and topic.closingDate != defaultDate and topic.openingDate <= datetime.now() and topic.closingDate > datetime.now():
        return True
    elif topic.openingDate != defaultDate and topic.closingDate == defaultDate and topic.openingDate <= datetime.now():
        return True
    elif topic.closingDate != defaultDate and topic.openingDate == defaultDate and topic.closingDate > datetime.now():
        return True
    elif topic.openingDate == defaultDate and topic.closingDate == defaultDate:
        return True
    else:
        return False


def user_is_in_the_task_list(task_id):

    task = Task.query.get(task_id)
    for user_id in task.users:
        if int(user_id) == current_user.id: return True
    return False


def task_authorization(task_id):

    try: task = Task.query.get(task_id)
    except: return False

    if task and task.school_id == current_user.school_id and task_is_availible(task) and task.users == []:
        return True
    elif task and task.school_id == current_user.school_id and task_is_availible(task) and task.users != [] and user_is_in_the_task_list(task_id):
        return True
    elif task and task.school_id == current_user.school_id and current_user.urole == "SCHOOL-ADMIN":
        return True
    else: return False


def sorting_class(user_class):
    class_name = user_class.name if user_class else ""
    parts = ["".join(g) for _, g in groupby(class_name, key=str.isdigit)]
    parts = [str(part) if part.isdigit() else str(part) for part in parts]
    return (user_class is None, parts)

def sorting_users_by_class(user):
    class_name = user.user_class.name if user.user_class else ""
    parts = ["".join(g) for _, g in groupby(class_name, key=str.isdigit)]
    parts = [int(part) if part.isdigit() else part for part in parts]
    parts = [str(part) for part in parts]
    first_last_name = user.first_last_name.split()
    second_word = first_last_name[1] if len(first_last_name) > 1 else ""
    return (user.user_class is None, parts, second_word)

def getSubmissionScoreByID(submission_id):
    submission = Submissions.query.get(submission_id)
    if submission:
        return submission.score
    else:
        return -1


def findContests():

    class Contests:
        def __init__(self, previous, upcoming):
            self.previous = previous
            self.upcoming = upcoming

    upcoming_contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()
    if not upcoming_contest:
        upcoming_contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate > datetime.now()).order_by(Contest.openingDate.asc()).first()
    previous_contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.closingDate <= datetime.now()).order_by(Contest.closingDate.desc()).first()

    contests = Contests(previous_contest, upcoming_contest)
    return contests



@views.route('/', methods=['GET', 'POST'])
@login_required
def home():

    page = request.args.get('page', 1, type=int)
    taskID = request.args.get('taskID', None)
    task_mode = request.args.get('task_mode', 'all')
    contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()

    all_school_tasks = Task.query.filter(Task.school_id == current_user.school_id)

    ## Jei nustatytas užduoties filtravimas, filtruojame užduotis pagal užduotį
    selected_task_name = ""
    selected_task = Task.query.get(taskID)
    if selected_task and selected_task.school_id == current_user.school_id:
        selected_task_name = selected_task.name
        all_school_tasks = all_school_tasks.filter(Task.id == selected_task.id)

    ## Jei nustatytas užduoties tipo filtravimas, filtruojame užduotis pagal jų tipą
    if task_mode == "default" or task_mode == "competitive":
        all_school_tasks = all_school_tasks.filter(Task.mode == task_mode)

    all_school_tasks = all_school_tasks.all()
    if current_user.urole == "GENERAL" and not contest:
        result = [task for task in all_school_tasks if task_authorization(task.id)]
        result.sort(key=lambda task: task.date, reverse=True)

    elif current_user.urole == "GENERAL":
        result = []
        for taskID in contest.tasks:
            contestTask = Task.query.get(taskID)
            if contestTask:
                result.append(contestTask)
    
    else:
        result = all_school_tasks
        result.sort(key=lambda task: task.date, reverse=True)

    ## Surenkame visas užduotis be filtravimo
    if not contest:
        all_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        all_tasks = [task for task in all_tasks if task_authorization(task.id)]
    else:
        all_tasks = Task.query.filter_by(contestID=contest.id).all()

    num_tasks_per_page = 12
    start_idx = (page - 1) * num_tasks_per_page
    end_idx = start_idx + num_tasks_per_page
    tasks_to_display = result[start_idx:end_idx]

    available_competitive_tasks = []
    for task in tasks_to_display:
        competitive_task_result = CompetitiveTaskResult.query.filter_by(user_id=current_user.id, task_id=task.id).first()
        if competitive_task_result and competitive_task_result.status == "participated":
            available_competitive_tasks.append("participated")
        elif competitive_task_result and competitive_task_result.status == "participating":
            available_competitive_tasks.append("participating")
        elif task.not_participating and current_user.id in task.not_participating:
            available_competitive_tasks.append("unavailable")
        elif task.mode == "competitive":
            available_competitive_tasks.append("available")
        else:
            available_competitive_tasks.append("unavailable")

    correct_submissions = []
    incorrect_submissions = []
    for task in tasks_to_display:
        correct_submission = Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, score=task.problems.testCount).first()
        correct_submissions.append(correct_submission)
        if task.problems.testCount != 1:
            incorrect_submission = Submissions.query.filter(Submissions.user_id == current_user.id, Submissions.task_id == task.id, Submissions.score.between(1, task.problems.testCount - 1)).first()
        else:
            incorrect_submission = None
        incorrect_submissions.append(incorrect_submission)

    num_pages = math.ceil(len(result) / num_tasks_per_page)
    has_prev_page = page > 1
    has_next_page = page < num_pages

    return render_template(
        'home.html',
        tasks=tasks_to_display,
        user=current_user,
        page=page,
        prev_page=page - 1 if has_prev_page else None,
        next_page=page + 1 if has_next_page else None,
        has_prev_page=has_prev_page,
        has_next_page=has_next_page,
        num_pages=num_pages,
        correct_submissions=correct_submissions,
        incorrect_submissions=incorrect_submissions,
        available_competitive_tasks=available_competitive_tasks,
        defaultDate=defaultDate,
        all_tasks=all_tasks,
        taskID=taskID,
        selected_task_name=selected_task_name,
        task_mode=task_mode,
        school_name=user_school_name(),
        userContests=findContests(),
        current_time=datetime.now(),
        pageName="Užduotys"
    )



@views.route('/pdf/<task_id>')
@login_required
def pdf(task_id):

    task = Task.query.get(task_id)
    competitive_task_results = CompetitiveTaskResult.query.filter_by(user_id=current_user.id, task_id=task.id).first()

    if current_user.urole == "SCHOOL-ADMIN" and task.school_id == current_user.school_id:
        path = f'/home/ubuntu/PDF_Salygos/{task.problemsId}.pdf'
        return send_file(path)
    elif task and task.mode != "competitive" and task_authorization(task.id):
        path = f'/home/ubuntu/PDF_Salygos/{task.problemsId}.pdf'
        return send_file(path)
    elif task and task.mode == "competitive" and (competitive_task_results.status == "participating" or competitive_task_results.status == "participated") and task_authorization(task.id):
        path = f'/home/ubuntu/PDF_Salygos/{task.problemsId}.pdf'
        return send_file(path)
    else:
        return redirect(url_for('views.home'))


@views.route('/task/<task_id>', methods=['GET', 'POST'])
@login_required
def task(task_id):

    task = Task.query.filter_by(id=task_id).first()
    if not task:
        return redirect(url_for('views.home'))

    problem = Problems.query.get(task.problemsId)
    competitive_task_results_status = CompetitiveTaskResult.query.filter_by(user_id=current_user.id, task_id=task_id).first()

    ## Jei užduočiai yra nustatytas varžybų rėžimas, vartotojas yra nukreipiamas į atitinkamus puslapius
    if current_user.urole != "SCHOOL-ADMIN" and task_authorization(task.id) and task.mode == "competitive":

        ## Jeigu vartotojas dar nedalyvavo arba šiuo metu dalyvauja varžybose, jis persiunčiamas į varžybo rėžimo puslapį
        if competitive_task_results_status and competitive_task_results_status.status == "participating":
            return redirect(url_for('views.task_competitive_mode', task_id=task_id))
        if not competitive_task_results_status:
            if not task.not_participating:
                return redirect(url_for('views.task_competitive_mode', task_id=task_id))
            if not current_user.id in task.not_participating:
                return redirect(url_for('views.task_competitive_mode', task_id=task_id))

    if request.method == 'POST' and task_authorization(task.id):

        data = request.get_json()
        submitted_code = data.get('submitted_code')
        language = data.get('submissionLanguage')
        compiler = data.get('submissionCompiler')

        ## Patikriname pasirinktą kalbą
        if language and not(language == "c++" or language == "python3"):
            return jsonify({'error': "Neteisingai pasirinkta sprendimo programavimo kalba."})
        elif not language:
            language = current_user.settings.default_language

        ## Patikriname pasirinktą kompiliatorių
        if compiler and language == "c++" and not(compiler == "clang" or compiler == "gcc"):
            return jsonify({'error': "Neteisingai pasirinktas kodo kompiliatorius."})
        elif not compiler:
            compiler = "clang"

        ### Jei vartotojo pateiktas sprendimas yra per ilgas:
        if len(submitted_code) >= 560000:
            return jsonify({'error': "Pateiktas sprendimas yra per ilgas."})
        elif len(submitted_code) < 1:
            return jsonify({'error': "Pateiktas sprendimas yra per trumpas."})

        ### Vartotojo pateiktas sprendimas yra perduodamas pateiktų sprendimų eilei
        if Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-2).first():
            return jsonify({'error': "Vienu metu gali būti pateiktas tik vienas suplanuotas sprendimas."})

        elif Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-3).first():
            return jsonify({'error': "Vienu metu gali būti pateiktas tik vienas sprendimas."})

        elif Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=0).first():
            return jsonify({'error': "Vienu metu gali būti pateiktas tik vienas sprendimas."})

        ### Vartotojo pateiktas sprendimas yra įkeliamas į databazę
        if task.testingDate == defaultDate or task.testingDate <= datetime.now():
            user_submission_status = -3
        else:
            user_submission_status = -2

        new_submission = Submissions(user_id=current_user.id, task_id=task.id, status=user_submission_status, submitted_code=submitted_code, language=current_user.settings.default_language)
        db.session.add(new_submission)
        db.session.commit()

        ### Vartotojo sprendimas perduodamas pateiktų sprendimų eilei
        if user_submission_status == -3:
            user_submission = compile_code.delay(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount,
                submitted_code, task.open_test_cases, language, compiler)
        else:
            vilnius_dt = vilnius_tz.localize(task.testingDate)
            user_submission = compile_code.apply_async(args=(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount, submitted_code, task.open_test_cases, language, compiler),
                eta=vilnius_dt.astimezone(pytz.UTC))

        ### Celery ID kodas išsaugomas databazėje
        new_submission.celery_id = user_submission.id
        db.session.commit()

        if user_submission_status == -3:
            return jsonify({'success': "Sprendimas gautas ir šiuo metu yra vertinamas."})
        else:
            return jsonify({'success': f"Sprendimas gautas ir bus vertinamas {task.testingDate}"})

    elif request.method == 'GET' and not task_authorization(task.id):
        flash('Užduotis neegzistuoja arba jūs neturite teisės jos pasiekti.', category='error')
        return redirect(url_for('views.home'))

    elif request.method == 'GET' and task_authorization(task.id):

        user_school = School.query.get(current_user.school_id)
        task_solved = Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, score=task.problems.testCount).first()

        if task.problems.testCount != 1:
            task_not_solved = Submissions.query.filter(Submissions.user_id == current_user.id, Submissions.task_id == task.id, Submissions.score.between(1, task.problems.testCount - 1)).first()
        else:
            task_not_solved = None

        return render_template('task.html', user_school=user_school, task_id=task.id, task_name=task.name, user=current_user, school_name=user_school_name(), task_solved=task_solved, task_not_solved=task_not_solved, userContests=findContests(), current_time=datetime.now(), pageName=task.name)

    else:
        return redirect(url_for('views.home'))


@views.route('/task/<task_id>/competitive_mode', methods=['GET', 'POST'])
@login_required
def task_competitive_mode(task_id):

    task = Task.query.get(task_id)
    competitive_task_result = CompetitiveTaskResult.query.filter_by(user_id=current_user.id, task_id=task_id).first()

    ## Jei užduotis neegzistuoja arba vartotojas neturi teisės jos pasiekti
    if not task or not task_authorization(task_id):
        flash('Užduotis neegzistuoja arba jūs neturite teisės jos pasiekti.', category='error')
        return redirect(url_for('views.home'))

    ## Jei reikia, vartotojas nukreipiamas į atitinkamus puslapius
    if current_user.urole == "SCHOOL-ADMIN" or task.mode != "competitive":
        return redirect(url_for('views.task', task_id=task_id))
    if competitive_task_result and competitive_task_result.status == "participated":
        return redirect(url_for('views.task', task_id=task_id))
    if task.not_participating and current_user.id in task.not_participating:
        return redirect(url_for('views.task', task_id=task_id))

    if competitive_task_result and task.competitiveTaskDuration != -1:
        time_difference = datetime.now() - datetime.strptime(competitive_task_result.start_date, '%Y-%m-%d %H:%M:%S')
        time_difference_minutes = round(time_difference.total_seconds() / 60)
        if time_difference_minutes >= task.competitiveTaskDuration:
            flash('Užduoties varžybų laikas jau pasibaigė, todėl toliau dalyvauti varžybose negalite.', category='success')
            return redirect(url_for('views.task_standings', task_id=task_id))

    problem = Problems.query.get(task.problemsId)

    if request.method == 'POST':

        data = request.get_json()
        submitted_code = data.get('submitted_code')
        language = data.get('submissionLanguage')
        compiler = data.get('submissionCompiler')

        ## Patikriname pasirinktą kalbą
        if language and not(language == "c++" or language == "python3"):
            return jsonify({'error': "Neteisingai pasirinkta sprendimo programavimo kalba."})
        elif not language:
            language = current_user.settings.default_language

        ## Patikriname pasirinktą kompiliatorių
        if compiler and language == "c++" and not(compiler == "clang" or compiler == "gcc"):
            return jsonify({'error': "Neteisingai pasirinktas kodo kompiliatorius."})
        elif not compiler:
            compiler = "clang"

        ### Jei vartotojo pateiktas sprendimas yra per ilgas:
        if len(submitted_code) >= 560000:
            return jsonify({'error': "Pateiktas sprendimas yra per ilgas."})
        elif len(submitted_code) < 1:
            return jsonify({'error': "Pateiktas sprendimas yra per trumpas."})

        ### Vartotojo pateiktas sprendimas yra perduodamas pateiktų sprendimų eilei
        if Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-2).first():
            return jsonify({'error': "Vienu metu gali būti pateiktas tik vienas suplanuotas sprendimas."})

        elif Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=-3).first():
            return jsonify({'error': "Vienu metu gali būti pateiktas tik vienas sprendimas."})

        elif Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, status=0).first():
            return jsonify({'error': "Vienu metu gali būti pateiktas tik vienas sprendimas."})

        ### Vartotojo pateiktas sprendimas yra įkeliamas į databazę
        if task.testingDate == defaultDate or task.testingDate <= datetime.now():
            user_submission_status = -3
        else:
            user_submission_status = -2

        new_submission = Submissions(user_id=current_user.id, task_id=task.id, status=user_submission_status, submitted_code=submitted_code, language=current_user.settings.default_language)
        db.session.add(new_submission)
        db.session.commit()

        ### Vartotojo sprendimas perduodamas pateiktų sprendimų eilei
        if user_submission_status == -3:
            user_submission = compile_code.delay(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount,
                submitted_code, task.open_test_cases, language, compiler)
        else:
            vilnius_dt = vilnius_tz.localize(task.testingDate)
            user_submission = compile_code.apply_async(args=(current_user.id,  problem.id, task_id, problem.timeLimit, problem.memoryLimit, problem.testCount, submitted_code, task.open_test_cases, language, compiler),
                eta=vilnius_dt.astimezone(pytz.UTC))

        ### Celery ID kodas išsaugomas databazėje
        new_submission.celery_id = user_submission.id
        db.session.commit()

        if user_submission_status == -3:
            return jsonify({'success': "Sprendimas gautas ir šiuo metu yra vertinamas."})
        else:
            return jsonify({'success': f'Sprendimas gautas ir bus vertinamas {task.testingDate}'})

    elif request.method == 'GET':

        ## Surandama informacija apie vartotojo dalyvavimą užduoties varžybose
        if competitive_task_result:
            start_date = competitive_task_result.start_date
        else:

            ## Sukuriamas duomenų bazės įrašas apie mokinio dalyvavimą varžybose
            new_competitive_task_result = CompetitiveTaskResult(task_id=task.id, user_id=current_user.id)
            db.session.add(new_competitive_task_result)
            db.session.commit()
            start_date = new_competitive_task_result.start_date

            ## Suplanuojamas pranešimo apie artėjančią varžybų pabaigą išsiuntimas
            if task.openingDate != defaultDate and task.closingDate != defaultDate:

                left_time = task.closingDate - datetime.now()
                left_time_minutes = round(left_time.total_seconds() / 60)

                if left_time_minutes >= 120:
                    send_reminder_before_minutes = round((left_time_minutes*20) / 100)
                    send_reminder_date = task.closingDate - timedelta(minutes=send_reminder_before_minutes)
                    send_reminder_date_seconds = (send_reminder_date - datetime.now()).total_seconds()
                    email_competitive_task_reminder.apply_async(args=(new_competitive_task_result.id,), countdown=send_reminder_date_seconds)

            elif task.competitiveTaskDuration == -1:
                send_reminder_date = datetime.strptime(new_competitive_task_result.start_date, '%Y-%m-%d %H:%M:%S') + timedelta(days=5)
                send_reminder_date_seconds = (send_reminder_date - datetime.now()).total_seconds()
                email_competitive_task_reminder.apply_async(args=(new_competitive_task_result.id,), countdown=send_reminder_date_seconds)

            elif task.competitiveTaskDuration >= 120:
                send_reminder_before_minutes = round((task.competitiveTaskDuration*20) / 100)
                send_reminder_date = datetime.strptime(new_competitive_task_result.start_date, '%Y-%m-%d %H:%M:%S') + timedelta(minutes=task.competitiveTaskDuration-send_reminder_before_minutes)
                send_reminder_date_seconds = (send_reminder_date - datetime.now()).total_seconds()
                email_competitive_task_reminder.apply_async(args=(new_competitive_task_result.id,), countdown=send_reminder_date_seconds)

            ## Suplanuojamas automatinis užduoties varžybų pabaigimas
            if task.openingDate != defaultDate and task.closingDate != defaultDate:
                end_competitive_task_time = task.closingDate + timedelta(minutes=2)
                end_competitive_task_time_seconds = (end_competitive_task_time - datetime.now()).total_seconds()
                end_competitive_task.apply_async(args=(new_competitive_task_result.id,), countdown=end_competitive_task_time_seconds)

            elif task.competitiveTaskDuration != -1:
                end_competitive_task_time = datetime.strptime(new_competitive_task_result.start_date, '%Y-%m-%d %H:%M:%S') + timedelta(minutes=task.competitiveTaskDuration+2)
                end_competitive_task_time_seconds = (end_competitive_task_time - datetime.now()).total_seconds()
                end_competitive_task.apply_async(args=(new_competitive_task_result.id,), countdown=end_competitive_task_time_seconds)

        task_solved = Submissions.query.filter_by(user_id=current_user.id, task_id=task.id, score=task.problems.testCount).first()

        if task.problems.testCount != 1:
            task_not_solved = Submissions.query.filter(Submissions.user_id == current_user.id, Submissions.task_id == task.id, Submissions.score.between(1, task.problems.testCount - 1)).first()
        else:
            task_not_solved = None

        if task.competitiveTaskDuration != -1 and competitive_task_result:
            end_date = datetime.strptime(competitive_task_result.start_date, '%Y-%m-%d %H:%M:%S') + timedelta(minutes=task.competitiveTaskDuration)
            start_date = "-"
        elif task.competitiveTaskDuration != -1 and new_competitive_task_result:
            end_date = datetime.strptime(new_competitive_task_result.start_date, '%Y-%m-%d %H:%M:%S') + timedelta(minutes=task.competitiveTaskDuration)
            start_date = "-"
        else:
            end_date = "-"

        user_school = School.query.get(current_user.school_id)
        return render_template('task_competitive_mode.html', user_school=user_school, task_id=task.id, task_name=task.name, user=current_user, school_name=user_school_name(), task_solved=task_solved, task_not_solved=task_not_solved, start_date=start_date, end_date=end_date, userContests=findContests(), current_time=datetime.now(), pageName=task.name)

    else:
        return redirect(url_for('views.home'))



@views.route('/end_competitive_task/<task_id>', methods=['GET', 'POST'])
@login_required
def end_competitive_task_api(task_id):

    competitive_task_results = CompetitiveTaskResult.query.filter_by(user_id=current_user.id, task_id=task_id).first()
    task = Task.query.get(task_id)

    if competitive_task_results and task and competitive_task_results.status == "participating" and task.competitiveTaskDuration != -1:

        time_difference = datetime.now() - datetime.strptime(competitive_task_results.start_date, '%Y-%m-%d %H:%M:%S')
        time_difference_minutes = round(time_difference.total_seconds() / 60)

        if time_difference_minutes >= task.competitiveTaskDuration:
            flash("Kadangi užduoties varžybų laikas pasibaigė, varžybos buvo sustabdytos automatiškai.", category="success")
            return jsonify({'info': 'Kadangi užduoties varžybų laikas pasibaigė, varžybos buvo sustabdytos automatiškai.'}), 200

    if competitive_task_results and task and not task_authorization(task.id):
        flash("Kadangi užduoties varžybų laikas pasibaigė, varžybos buvo sustabdytos automatiškai.", category="success")
        return jsonify({'info': 'Kadangi užduoties varžybų laikas pasibaigė, varžybos buvo sustabdytos automatiškai.'}), 200

    if competitive_task_results and competitive_task_results.status == "participating":

        submissions = Submissions.query.filter_by(user_id=current_user.id, task_id=task_id).all()
        submissions_not_plagiarised = Submissions.query.filter_by(user_id=current_user.id, task_id=task_id, plagiarism_pairs=None).all()

        ## Jei vartotojas nepateikė nei vieno sprendimo, vartotojas pasitraukė iš užduoties varžybų
        if not submissions:
            if task and task.not_participating:
                not_participating_users = task.not_participating
                not_participating_users.append(current_user.id)
                task.not_participating = not_participating_users
                flag_modified(task, 'not_participating')
                db.session.commit()
            elif task:
                not_participating_users = []
                not_participating_users.append(current_user.id)
                task.not_participating = not_participating_users
                flag_modified(task, 'not_participating')
                db.session.commit()

            db.session.delete(competitive_task_results)
            db.session.commit()
            flash("Kadangi nepateikėte nei vieno užduoties sprendimo, jūs buvote pašalintas iš užduoties varžybų.", category="success")
            return jsonify({'info': 'Kadangi nepateikėte nei vieno užduoties sprendimo, jūs buvote pašalintas iš užduoties varžybų.'}), 200

        elif submissions and not submissions_not_plagiarised:

            competitive_task_results.status = "participated"
            competitive_task_results.score = -1
            db.session.commit()

            flash("Kadangi visiems pateiktiems užduoties sprendimams buvo nustatytas galimas plagiatas, jūsų varžybos nebus vertinamos. Kai už varžybas atsakingas mokytojas pašalins plagiato žymę nuo bent vieno iš jūsų pateikto sprendimo, jūsų varžybos bus įvertintos.", category="success")
            return jsonify({'info': 'Kadangi visiems pateiktiems užduoties sprendimams buvo nustatytas galimas plagiatas, jūsų varžybos nebus vertinamos. Kai už varžybas atsakingas mokytojas pašalins plagiato žymę nuo bent vieno iš jūsų pateikto sprendimo, jūsų varžybos bus įvertintos.'}), 200


        submissions_not_plagiarised_sorted = sorted(submissions_not_plagiarised, key=lambda submission: (-submission.score, submission.date))
        submissions_not_plagiarised = sorted(submissions_not_plagiarised, key=lambda submission: submission.date)

        competitive_task_results.status = "participated"
        competitive_task_results.end_date = submissions_not_plagiarised[len(submissions_not_plagiarised)-1].date
        competitive_task_results.best_submission_id = submissions_not_plagiarised[len(submissions_not_plagiarised_sorted)-1].id
        competitive_task_results.attempts = len(submissions_not_plagiarised)

        start_date_datetime = datetime.strptime(competitive_task_results.start_date, "%Y-%m-%d %H:%M:%S")
        start_date_datetime = start_date_datetime.replace(second=0)

        end_date_datetime = datetime.strptime(submissions_not_plagiarised[len(submissions_not_plagiarised)-1].date, "%Y-%m-%d %H:%M:%S")
        end_date_datetime = end_date_datetime.replace(second=0)

        time_difference = end_date_datetime - start_date_datetime
        difference_in_minutes = time_difference.total_seconds() / 60
        score = round(difference_in_minutes) + (len(submissions_not_plagiarised)-1)*5
        competitive_task_results.score = score
        
        db.session.commit()

        ## Apskaičiuojamas vartotojo reitingas
        #competitive_task_ranking.delay(competitive_task_results.task_id)

        ## Vartotojui išsiunčiamas laiškas su varžybų ataskaita
        email_competitive_task_end.delay(current_user.id, competitive_task_results.task_id)

        return jsonify({'success': 'Jus sėkmingai pabaigėte užduoties varžybas.'}), 200

    elif competitive_task_results and competitive_task_results.status == "participated":
        return jsonify({'success': 'Jūsų užduoties varžybos jau buvo sustabdytos anksčiau.'}), 200

    else:
        return redirect(url_for('views.home'))


@views.route('/api/contest/<contestID>/info', methods=['POST'])
@login_required
def contest_info(contestID):

    if request.method == 'POST':

        contest = Contest.query.get(contestID)
        if contest and contest.school_id == current_user.school_id and contest.openingDate <= datetime.now() and contest.closingDate >= datetime.now():

            score = 0
            total_points = 0
            contest_tasks = Task.query.filter_by(contestID = contest.id).all()

            for task in contest_tasks:
                best_task_submission = Submissions.query.filter(Submissions.task_id == task.id).order_by(Submissions.score.desc()).first()
                total_points += task.problems.testCount
                if best_task_submission:
                    score += best_task_submission.score

            ## Gražinama informacija apie konkursą
            return jsonify({'score': score, 'totalPoints': total_points}), 200

        else:
            return jsonify({'error': 'Konkursas neegzistuoja, nepriklauso jūsų mokyklai arba šiuo metu nevyksta, todėl peržiūrėti informacijos apie konkursą negalima.'}), 400

    else:
        return jsonify({'error': 'Neteisinga užklausa. Naudokite POST užklausą.'}), 400


@views.route('/task/<task_id>/standings')
@login_required
def task_standings(task_id):

    task = Task.query.get(task_id)

    if not task or not task_authorization(task.id) or task.mode != "competitive":
        flash("Nurodyta varžybų užduotis neegzistuoja arba jūs neturite teisės peržiūrėti varžybų rezultatų.", category="error")
        return redirect(url_for('views.home'))
        
    competitive_task_results = CompetitiveTaskResult.query.filter(
        CompetitiveTaskResult.task_id == task.id,
        CompetitiveTaskResult.status == "participated",
        CompetitiveTaskResult.score != -1
    ).all()
    competitive_task_results = sorted(competitive_task_results, key=lambda competitive_task_result: (-getSubmissionScoreByID(competitive_task_result.best_submission_id), competitive_task_result.score))
    
    best_submissions_scores = []
    user_places_in_competition = []
    user_place_in_competition = -1
    standings = []

    for competitive_task_result in competitive_task_results:
        best_submissions_scores.append(getSubmissionScoreByID(competitive_task_result.best_submission_id))

    for index, competitive_task_result in enumerate(competitive_task_results):
        
        ## Išsaugomas vartotojo vardas jei vartotojas nepateikė prašymo slėpti jo vardą varžybų rezultatuose
        user = User.query.get(competitive_task_result.user_id)
        if user and user.settings.hide_name_in_competitions and user.id != current_user.id:
            user_name = "Vartotojas paslėptas"
            user_id = -1
        elif user:
            user_name = user.first_last_name
            user_id = user.id
        else:
            user_name = "Vartotojas pašalintas"
            user_id = -1

        ## Išsaugoma informacija apie vartotojo užimtą vietą varžybose
        if index != 0 and best_submissions_scores[index-1] == best_submissions_scores[index] and competitive_task_results[index-1].score == competitive_task_result.score:
            user_places_in_competition.append(user_places_in_competition[index-1])
        elif index != 0 and best_submissions_scores[index-1] == 0:
            user_places_in_competition.append(user_places_in_competition[index-1])
        elif index != 0:
            user_places_in_competition.append(user_places_in_competition[index-1]+1)
        else:
            user_places_in_competition.append(1)

        if user.id == current_user.id:
            user_place_in_competition = user_places_in_competition[index]

        data = {
            'user_id': user_id,
            'user_name': user_name,
            'place_in_competition': user_places_in_competition[index],
            'score': best_submissions_scores[index],
            'time': competitive_task_results[index].score
        }
        standings.append(data)

    return render_template('task_standings.html', standings=standings, user_place_in_competition=user_place_in_competition, task=task, user=current_user, school_name=user_school_name(), userContests=findContests(), current_time=datetime.now(), pageName="Varžybų rezultatai")


@views.route('/contest/<contest_id>/standings')
@login_required
def contest_standings(contest_id):

    contest = Contest.query.get(contest_id)
    if not contest or contest.school_id != current_user.school_id or contest.openingDate > datetime.now():
        return redirect(url_for('views.home'))

    ## Pagalbinė struktūra, skirta saugoti konkurso rezultatą
    class ContestResult:
        def __init__(self, user, place, points, time, tasks):
            self.user = user
            self.place = place
            self.points = points
            self.time = time
            self.tasks = tasks

    ## Surenkame informaciją apie konkurso užduotis
    contestTasks = []
    for taskID in contest.tasks:
        task = Task.query.get(taskID)
        contestTasks.append(task)

    ## Surenkame informaciją apie konkurse dalyvavusius dalyvius
    contestResults = []
    users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
    for user in users:

        total_points = 0
        total_time = 0
        tasks = []
        participated = False

        contest_start_date = contest.openingDate
        contest_start_date = contest_start_date.replace(second=0)

        ## Pereiname per visas konkurso užduotis
        for taskID in contest.tasks:

            submissions = Submissions.query.filter(Submissions.task_id == taskID, Submissions.user_id == user.id, Submissions.status > 0)
            highest_score_submission = submissions.order_by(Submissions.score.desc()).first()

            if submissions.count() == 0:
                tasks.append((-1, -1))

            elif submissions.filter(Submissions.score == highest_score_submission.score).count() == 1:

                submission_date = datetime.strptime(highest_score_submission.date, '%Y-%m-%d %H:%M:%S')
                submission_date = submission_date.replace(second=0)
                time_diff = submission_date - contest_start_date
                minutes_diff = round(time_diff.total_seconds() / 60)
                tasks.append((highest_score_submission.score, f'{minutes_diff} min'))

                ## Sprendimo laikas ir taškai pridedami prie bendro laiko ir taškų
                total_points += highest_score_submission.score
                total_time += minutes_diff

                ## Apskaičiuojamas papildomas laikas
                additional_submissions = Submissions.query.filter(Submissions.task_id == taskID, Submissions.user_id == user.id, Submissions.status > 0).all()
                total_time = total_time + 5 * (len(additional_submissions)-1)
                participated = True

            else:

                best_submission = submissions.filter(Submissions.score == highest_score_submission.score).order_by(Submissions.date).first()
                submission_date = datetime.strptime(best_submission.date, '%Y-%m-%d %H:%M:%S')
                submission_date = submission_date.replace(second=0)
                time_diff = submission_date - contest_start_date
                minutes_diff = round(time_diff.total_seconds() / 60)
                tasks.append((best_submission.score, f'{minutes_diff} min'))

                ## Sprendimo laikas ir taškai pridedami prie bendro laiko ir taškų
                total_points += best_submission.score
                total_time += minutes_diff

                ## Apskaičiuojamas papildomas laikas
                if highest_score_submission.score != highest_score_submission.task.problems.testCount:
                    additional_submissions = Submissions.query.filter(Submissions.task_id == taskID, Submissions.user_id == user.id, Submissions.status > 0).all()
                else:
                    additional_submissions = Submissions.query.filter(Submissions.task_id == taskID, Submissions.user_id == user.id, Submissions.status > 0, Submissions.id < highest_score_submission.id).all()
                
                total_time = total_time + 5 * (len(additional_submissions)-1)
                participated = True

        ## Išsaugomas vartotojo konkurso rezultatas
        if participated:
            userContestResult = ContestResult(user, -1, total_points, total_time, tasks)
        else:
            userContestResult = ContestResult(user, -1, -1, -1, tasks)
        contestResults.append(userContestResult)

    ## Konkurso dalyvių rezultatai surikiuojami pagal taškus, laiką
    contestResults = sorted(contestResults, key=lambda contestResult: (-contestResult.points, contestResult.time))

    ## Konkurso dalyviams priskiriamos vietos
    for index, contestResult in enumerate(contestResults):

        if index != 0 and contestResult.points == contestResults[index-1].points and contestResult.time == contestResults[index-1].time:
            contestResults[index].place = contestResults[index-1].place
        elif index != 0:
            contestResults[index].place = contestResults[index-1].place + 1
        else:
            contestResults[index].place = 1

    return render_template('contest_standings.html', contest=contest, contestResults=contestResults, tasks=contestTasks, user=current_user, school_name=user_school_name(), userContests=findContests(), current_time=datetime.now())


@views.route('/api/task/<task_id>/standings', methods=['GET'])
@login_required
def task_standings_api(task_id):

    task = Task.query.get(task_id)

    if not task or not task_authorization(task.id) or task.mode != "competitive":
        return jsonify({'error': 'Nurodyta varžybų užduotis neegzistuoja arba jūs neturite teisės peržiūrėti varžybų rezultatų.'}), 400
        
    competitive_task_results = CompetitiveTaskResult.query.filter(
        CompetitiveTaskResult.task_id == task.id,
        CompetitiveTaskResult.status == "participated",
        CompetitiveTaskResult.score != -1
    ).all()
    competitive_task_results = sorted(competitive_task_results, key=lambda competitive_task_result: (-getSubmissionScoreByID(competitive_task_result.best_submission_id), competitive_task_result.score))
    
    best_submissions_scores = []
    user_places_in_competition = []
    user_place_in_competition = -1
    standings = []

    for competitive_task_result in competitive_task_results:
        best_submissions_scores.append(getSubmissionScoreByID(competitive_task_result.best_submission_id))

    for index, competitive_task_result in enumerate(competitive_task_results):
        
        ## Išsaugomas vartotojo vardas jei vartotojas nepateikė prašymo slėpti jo vardą varžybų rezultatuose
        user = User.query.get(competitive_task_result.user_id)
        if user and user.settings.hide_name_in_competitions and user.id != current_user.id:
            user_name = "Vartotojas paslėptas"
        elif user:
            user_name = user.first_last_name
        else:
            user_name = "Vartotojas pašalintas"

        ## Išsaugoma informacija apie vartotojo užimtą vietą varžybose
        if index != 0 and best_submissions_scores[index-1] == best_submissions_scores[index] and competitive_task_results[index-1].score == competitive_task_result.score:
            user_places_in_competition.append(user_places_in_competition[index-1])
        elif index != 0 and best_submissions_scores[index-1] == 0:
            user_places_in_competition.append(user_places_in_competition[index-1])
        elif index != 0:
            user_places_in_competition.append(user_places_in_competition[index-1]+1)
        else:
            user_places_in_competition.append(1)

        if user.id == current_user.id:
            user_place_in_competition = user_places_in_competition[index]

        data = {
            'user_name': user_name,
            'place_in_competition': user_places_in_competition[index],
            'score': best_submissions_scores[index],
            'time': competitive_task_results[index].score
        }
        standings.append(data)

    return jsonify({'standings': standings, 'user_place_in_competition': user_place_in_competition}), 200



@views.route('/api/competitive_task_report', methods=['POST'])
@login_required
def competitive_task_report_api():

    data = json.loads(request.data.decode('utf-8'))
    taskID = data.get('taskID')
    competitive_task_result = CompetitiveTaskResult.query.filter_by(task_id=taskID, user_id=current_user.id, status="participated").first()

    ## Jei vartotojoas dar nepabaigė varžybų arba jose nedalyvavo
    if not competitive_task_result:
        return jsonify({'error': 'Nurodyta varžybų užduotis neegzistuoja arba jūs negalite šiuo metu gauti varžybų ataskaitos.'}), 400

    competititve_task_report = []

    ## Į varžybų ataskaitą itraukiame varžybų pradžią
    report_data = {
        'action': 'competitive_task_start',
        'score': 0,
        'date': competitive_task_result.start_date
    }
    competititve_task_report.append(report_data)

    ## Į varžybų ataskaitą itraukiame visus vartotojo pateikimus ir papildomų pateikimų bausmes
    user_submissions_with_plagiarism = Submissions.query.filter_by(task_id=competitive_task_result.task_id, user_id=current_user.id).all()
    user_submissions = Submissions.query.filter_by(task_id=competitive_task_result.task_id, user_id=current_user.id, plagiarism_pairs=None).all()

    if not user_submissions_with_plagiarism:
        return jsonify({'error': 'Jūs nesate pateikę nei vieno varžybų užduoties sprendimo, todėl negalite gauti varžybų ataskaitos.'}), 400

    if not user_submissions:
        return jsonify({'error': 'Visiems pateiktiems varžybų uždavinio sprendimams nustatytas galimas plagiatas, todėl negalite gauti varžybų ataskaitos.'}), 400
    
    elif len(user_submissions) == 1:

        ## Į ataskaitą įtraukiame vieną ir vienintelį pateikimą
        report_data = {
            'action': 'first_submission',
            'score': user_submissions[0].score,
            'date': user_submissions[0].date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame varžybų uždarymą
        report_data = {
            'action': 'competitive_task_end',
            'score': 0,
            'date': competitive_task_result.end_date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame vartotojo varžybų rezultatą
        report_data = {
            'action': 'competitive_task_result',
            'score': user_submissions[0].score,
            'date': f'{competitive_task_result.score} min.'
        }
        competititve_task_report.append(report_data)

    else:

        ## Į ataskaitą įtraukiame prirmą pateikimą
        report_data = {
            'action': 'first_submission',
            'score': user_submissions[0].score,
            'date': user_submissions[0].date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame papildomus pateikimus
        best_submission_score = 0
        for index, submission in enumerate(user_submissions):

            if index == 0:
                continue

            best_submission_score = max(best_submission_score, submission.score)

            report_data = {
                'action': 'aditional_submission',
                'score': submission.score,
                'date': submission.date
            }
            competititve_task_report.append(report_data)

            report_data = {
                'action': 'aditional_submission_time_penalty',
                'score': 0,
                'date': '+5 minutės'
            }
            competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame varžybų uždarymą
        report_data = {
            'action': 'competitive_task_end',
            'score': 0,
            'date': competitive_task_result.end_date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame vartotojo varžybų rezultatą
        report_data = {
            'action': 'competitive_task_result',
            'score': best_submission_score,
            'date': f'{competitive_task_result.score} min.'
        }
        competititve_task_report.append(report_data)

    ## Išsiunčiame sugeneruotą varžybų ataskaitą
    return jsonify({'competititve_task_report': competititve_task_report})


@views.route('/submissions')
@login_required
def submissions():

    ## Jei šiuo metu vyksta konkursas
    tasks = []
    contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()
    if not contest:
        user_submissions = Submissions.query.filter_by(user_id=current_user.id).all()
    else:
        user_submissions = Submissions.query.join(Task).filter(Submissions.user_id == current_user.id, Task.contestID == contest.id).all()

    for submission in user_submissions:
        if submission.task and submission.task not in tasks:
            tasks.append(submission.task)

    return render_template('submissions.html', user=current_user, tasks=tasks, school_name=user_school_name(), userContests=findContests(), current_time=datetime.now(), pageName="Pateikti sprendimai")


@views.route('/api/submissions')
@login_required
def submissions_api():

    page = request.args.get('page', 1, type=int)
    start_date = request.args.get('start_date', None)
    end_date = request.args.get('end_date', None)
    task_id = request.args.get('taskID', None)
    score_filter = request.args.get('score_filter', 'all')

    #x = 10/0

    ## Jei šiuo metu vyksta konkursas
    contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()
    if not contest:
        submission_query = Submissions.query.join(User).join(Task).join(Problems).filter(User.id == current_user.id)
    else:
        submission_query = Submissions.query.join(User).join(Task).join(Problems).filter(User.id == current_user.id, Task.contestID == contest.id)

    submission_query = submission_query.order_by(Submissions.date.desc())

    ## Jei nustatyta pradžios data, filtruojame pateiktus sprendimus
    if start_date != None and start_date != "None" and start_date != "":
        try:
            start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
            submission_query = submission_query.filter(Submissions.date >= start_date)
        except ValueError:
            return jsonify({'error': 'Neteisingai nurodyta pradžios data.'}), 400

    ## Jei nustatyta pabaigos data, filtruojame pateiktus sprendimus
    if end_date != None and end_date != "None" and end_date != "":
        try:
            end_date = datetime.strptime(end_date, "%Y-%m-%d").date() + timedelta(days=1)
            submission_query = submission_query.filter(Submissions.date < end_date)
        except ValueError:
            return jsonify({'error': 'Neteisingai nurodyta pabaigos data.'}), 400

    ## Jei nustatyta užduotis, ją patikriname ir pridedame prie bendro filtravimo
    if task_id:
        task = Task.query.get(task_id)
        if task and task.school_id == current_user.school_id:
            submission_query = submission_query.filter(Task.id == task.id)

    ## Ieškome sprendimų su nurodytu surinktų taškų tipu
    if score_filter == 'zero':
        submission_query = submission_query.filter(Submissions.status != -3, Submissions.status != -2, Submissions.status != 0, Submissions.score == 0)
    elif score_filter == 'max':
        submission_query = submission_query.filter(Submissions.status != -3, Submissions.status != -2, Submissions.status != 0, Submissions.score == Problems.testCount)
    elif score_filter == 'between':
        submission_query = submission_query.filter(Submissions.status != -3, Submissions.status != -2, Submissions.status != 0, Submissions.score > 0, Submissions.score < Problems.testCount)
    else:
        score_filter = 'all'


    ## Surenkame informaciją apie pateiktus sprendimus
    submissions = submission_query.paginate(page=page, per_page=20)
    submissions_list = []

    for index, submission in enumerate(submissions):

        if submission.status == -3:
            if submission.task:
                submissions_in_queue = Submissions.query.filter(
                    (Submissions.status == -3) &
                    (Submissions.id < submission.id)
                ).all()
                status_msg = f'Pateiktas sprendimas yra {max(len(submissions_in_queue), 1)} eilėje'
            else:
                status_msg = "Pateiktas sprendimas laukia eilėje"

        elif submission.status == -2:
            if submission.task:
                status_msg = f'Testavimas suplanuotas {submission.task.testingDate}'
            else:
                status_msg = "Testavimas bus atliktas nustatytu metu"

        elif submission.status == -1:
            status_msg = "Testavimas atšauktas"
        elif submission.status == 0:
            status_msg = "Testuojama"
        elif submission.status == 1:
            status_msg = "Testavimo klaida"
        elif submission.status == 2:
            status_msg = "Nesikompiliuoja"
        elif submission.status == 3:
            status_msg = "Testavimas baigtas"


        if submission.task:
            task_name = submission.task.name
            task_id = submission.task.id
            if submission.task.problems:
                max_score = submission.task.problems.testCount
            else:
                max_score = -1
        else:
            task_name = "Užduoties sprendimas"
            task_id = -1
            max_score = -1


        if submission.task and submission.task.mode == "competitive" and submission.plagiarism_pairs:
            plagiarised = "True"
        elif submission.task and submission.task.mode == "competitive" and not submission.plagiarism_pairs:
            plagiarised = "False"
        else:
            plagiarised = "-"


        submission_data = {
            'id': submission.id,
            'task_id': task_id,
            'status': submission.status,
            'status_msg': status_msg,
            'row_id': (page-1)*20 + index + 1,
            'task_name': task_name,
            'score': submission.score,
            'max_score': max_score,
            'date': submission.date,
            'error_msg': submission.error_msg,
            'messages': len(submission.messages),
            'plagiarised': plagiarised,
        }

        submissions_list.append(submission_data)

    return jsonify({'submissions': submissions_list, 'page': page, 'pages': submissions.pages})



@views.route('/api/messages')
@login_required
def messages_api():

    submissionId = request.args.get('submissionId')
    contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()

    ## Patikriname, ar ieškomas sprendimas egzistuoja
    submission = Submissions.query.get(submissionId)
    if current_user.urole == "GENERAL" and not submission:
        return jsonify({'error': 'Nurodytas sprendimas neegzistuoja arba nepriklauso jūsų vartotojui.'}), 400
    elif not submission:
        return jsonify({'error': 'Nurodytas sprendimas neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400
    elif current_user.urole == "GENERAL" and submission.user_id != current_user.id:
        return jsonify({'error': 'Nurodytas sprendimas neegzistuoja arba nepriklauso jūsų vartotojui.'}), 400
    elif current_user.urole == "SCHOOL-ADMIN" and submission.user.school_id != current_user.school_id:
        return jsonify({'error': 'Nurodytas sprendimas neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400
    elif contest and current_user.urole == "GENERAL" and not (submission.task and submission.task.contestID == contest.id):
        return jsonify({'error': 'Konkurso metu pasiekti ne konkurso užduotis ir su jais susijusią informaciją draudžiama.'}), 400

    ## Surenkame informaciją apie sprendimui skirtas žinutes
    user_messages = Messages.query.filter_by(submission_id=submission.id).all()
    messages_list = []

    for message in user_messages:

        ## Gaunamas žinutės autoriaus vardas
        if message.user.first_last_name:
            message_user_name = message.user.first_last_name
        else:
            message_user_name = "Pašalintas vartotojas"

        ## Jei žinutę perskaitė ne autorius, žinutė pažymima kaip perskaityta
        if message.user.id != current_user.id and not message.seen:
            message.seen = True
            db.session.commit()

        message_data = {
            'user_name': message_user_name,
            'date': message.date,
            'message': message.message,
        }
        
        messages_list.append(message_data)

    return jsonify({'messages': messages_list})



@views.route('/api/codeComments', methods=['POST'])
@login_required
def codeComments_api():

    data = request.get_json()
    submission_id = data.get('submissionId')

    ## Patikrinamas nurodytas sprendimas
    submission = Submissions.query.get(submission_id)
    if current_user.urole == "SCHOOL-ADMIN":
        if not submission or not submission.user or submission.user.school_id != current_user.school_id:
            return jsonify({'error': 'Nurodytas sprendimas neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400
    else:
        if not submission or not submission.user or submission.user_id != current_user.id:
            return jsonify({'error': 'Nurodytas sprendimas neegzistuoja arba nepriklauso jūsų vartotojui.'}), 400

    ## Surenkami visi nurodyto sprendimo kodo komentarai
    comments = CodeComment.query.filter_by(submission_id=submission.id).all()
    comments_list = []

    for comment in comments:

        ## Gaunamas komentaro autoriaus vardas
        if comment.user:
            comment_user_name = comment.user.first_last_name
            comment_user_id = comment.user.id
        else:
            comment_user_name = "Pašalintas vartotojas"
            comment_user_id = -1

        comment_data = {
            'user_name': comment_user_name,
            'user_id': comment_user_id,
            'date': comment.date.strftime("%Y-%m-%d %H:%M"),
            'startRow': comment.startRow,
            'startCol': comment.startCol,
            'endRow': comment.endRow,
            'endCol': comment.endCol,
            'comment': comment.comment,
        }
        comments_list.append(comment_data)

    comments_list.sort(key=lambda x: (x['startRow'], x['startCol'], x['endRow'], x['endCol']))
    return jsonify({'comments': comments_list})



@views.route('/api/messages/unseen')
@login_required
def unseen_messages_api():

    ## Surenkame neperžiūrėtas globalias žinutes
    unseen_messages_global = GlobalMessage.query.filter(
        GlobalMessage.user_role == current_user.urole or GlobalMessage.user_role == "ALL",
        GlobalMessage.school_id == current_user.school_id or GlobalMessage.school_id == -1,
        GlobalMessage.expiration_date > datetime.now(),
    ).all()

    if current_user.urole == "SCHOOL-ADMIN":
        unseen_messages = Messages.query.join(User).filter(User.school_id == current_user.school_id, User.urole == "GENERAL", Messages.seen == False).all()
    else:
        unseen_messages = Messages.query.join(User).filter(and_(Messages.submission.has(Submissions.user_id == current_user.id), User.urole == "SCHOOL-ADMIN", Messages.seen == False)).all()

    ## Surinkti pranešimai sudedami ir išsiunčiami vartotojui
    unseen_messages_list = []

    for unseen_message in unseen_messages:
        sender_user = User.query.get(unseen_message.user_id)
        if sender_user and unseen_message.submission and unseen_message.submission.task:

            ## Apskaičiuojamas datų skirtumas
            delta = datetime.now() - datetime.strptime(unseen_message.date, '%Y-%m-%d %H:%M:%S')
            days = delta.days
            hours, remainder = divmod(delta.seconds, 3600)
            minutes, seconds = divmod(remainder, 60)

            if days != 0:
                timestamp_str = f'Prieš {days}d. ir {hours}val.'
            elif hours != 0:
                timestamp_str = f'Prieš {hours}h. ir {minutes}min.'
            elif minutes != 0:
                timestamp_str = f'Prieš {minutes}min.'
            else:
                timestamp_str = f'Prieš {seconds}sek.'

            ## Žinutė pažymima kaip perskaityta
            unseen_message.seen = True
            db.session.commit()

            message_data = {
                'sender': f'{sender_user.first_last_name}',
                'timestamp': timestamp_str,
                'message': f'{unseen_message.message}',
            }
            unseen_messages_list.append(message_data)

    for unseen_message_global in unseen_messages_global:

        if unseen_message_global.seen and str(current_user.id) in unseen_message_global.seen:
            continue

        message_data = {
            'sender': 'Platformos administratorius',
            'timestamp': '',
            'message': f'{unseen_message_global.message}',
        }
        unseen_messages_list.append(message_data)

        if not unseen_message_global.seen:
            unseen_message_global.seen = [str(current_user.id)]
            flag_modified(unseen_message_global, 'seen')
            db.session.commit()
        else:
            unseen_message_global.seen.append(str(current_user.id))
            flag_modified(unseen_message_global, 'seen')
            db.session.commit()

    return jsonify({'messages': unseen_messages_list})



@views.route('/submissions/view_submission', methods=['POST'])
@login_required
def view_submission():

    data = request.get_json()
    submission_id = data.get('submissionId')
    submission = Submissions.query.get(submission_id)
    contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()
    
    if submission: submission_user = User.query.get(submission.user_id)
    if contest and current_user.urole == "GENERAL" and not (submission and submission.task and submission.task.contestID == contest.id):
        return jsonify({'error': 'Varžybų metu peržiūrėti ne varžybų užduočių sprendimus draudžiama.'}), 400

    if submission and submission.user_id == current_user.id:

        ## Surandame pateikto sprendimo užduotį
        if submission.task:
            taskName = submission.task.name
            totalPoints = submission.task.problems.testCount
        else:
            taskName = "Pašalinta užduotis"
            totalPoints = -1

        ## Surenkama informacija apie sprendimą
        submission_data = {
            'id': submission.id,
            'taskName': taskName,
            'date': submission.date,
            'score': submission.score,
            'totalPoints': totalPoints,
            'lang': submission.language,
            'submitted_code': submission.submitted_code,
        }
        return jsonify({'submission': submission_data})

    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id:

        ## Surandame pateikto sprendimo užduotį
        if submission.task:
            taskName = submission.task.name
            totalPoints = submission.task.problems.testCount
        else:
            taskName = "Pašalinta užduotis"
            totalPoints = -1

        ## Surenkama informacija apie sprendimą
        submission_data = {
            'id': submission.id,
            'user': submission.user.first_last_name,
            'taskName': taskName,
            'date': submission.date,
            'score': submission.score,
            'totalPoints': totalPoints,
            'lang': submission.language,
            'submitted_code': submission.submitted_code,
        }
        return jsonify({'submission': submission_data})

    else:
        return jsonify({'error': 'Sprendimas neegzistuoja arba nepriklauso jūsų mokyklai, todėl jo peržiūrėti negalima.'}), 400



@views.route('/submissions/download_submission/<submission_id>')
@login_required
def download_submission(submission_id):

    submission = Submissions.query.get(submission_id)
    contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()
    if submission: submission_user = User.query.get(submission.user_id)
    if contest and current_user.urole == "GENERAL" and not (submission and submission.task and submission.task.contestID == contest.id):
        return redirect(url_for('views.home'))

    if submission and submission.user_id == current_user.id:
        response = Response(submission.submitted_code, content_type='text/plain')

        if submission.language == "c++":
            if submission.task:
                filename = f'{submission.task.name}.cpp'
            else:
                filename = 'uzdavinio_sprendimas.cpp'
        else:
            if submission.task:
                filename = f'{submission.task.name}.py'
            else:
                filename = 'uzdavinio_sprendimas.py'

        filename_encoded = filename.encode('utf-8')
        response.headers.set('Content-Disposition', 'attachment', filename=filename_encoded)
        return response

    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id:
        response = Response(submission.submitted_code, content_type='text/plain')

        if submission.language == "c++":
            if submission.task:
                filename = f'{submission.task.name}.cpp'
            else:
                filename = 'uzdavinio_sprendimas.cpp'
        else:
            if submission.task:
                filename = f'{submission.task.name}.py'
            else:
                filename = 'uzdavinio_sprendimas.py'

        filename_encoded = filename.encode('utf-8')
        response.headers.set('Content-Disposition', 'attachment', filename=filename_encoded)
        return response

    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/resubmit/<submission_id>')
@login_required
def resubmit(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission and submission.user_id == current_user.id and submission.status == -1:

        task = Task.query.get(submission.task_id)

        if task.testingDate == defaultDate or task.testingDate <= datetime.now():
            user_submission = compile_code.delay(current_user.id,  task.problems.id, task.id, task.problems.timeLimit, task.problems.memoryLimit, task.problems.testCount,
                submission.submitted_code, task.open_test_cases, current_user.settings.default_language, "clang")
            submission.status = -3
        
        else:
            vilnius_dt = vilnius_tz.localize(task.testingDate)
            user_submission = compile_code.apply_async(args=(current_user.id,  task.problems.id, task.id, task.problems.timeLimit, task.problems.memoryLimit, task.problems.testCount,
                submission.submitted_code, task.open_test_cases, current_user.settings.default_language, "clang"),
                eta=vilnius_dt.astimezone(pytz.UTC))
            submission.status = -2

        db.session.commit()
        flash('Sprendimas pateiktas iš naujo.', category='success')
        return redirect(url_for('views.submissions'))
    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/cancel_submission/<submission_id>')
@login_required
def cancel_submission(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission and submission.user_id == current_user.id and (submission.status == -2 or submission.status == -3):

        if not submission.task.allow_cancel_submission:
            flash('Sprendimo atšaukimas yra negalimas šiam sprendimui.', category='error')
            return redirect(url_for('views.submissions'))

        result = AsyncResult(submission.celery_id)

        if result.status == 'PENDING':
            result.revoke(terminate=True)
            db.session.delete(submission)
            db.session.commit()
            flash('Sprendimo testavimas buvo atšauktas.', category='success')

        else:
            flash('Sprendimo testavimo atšaukti nepavyko.', category='error')

        return redirect(url_for('views.submissions'))
    else:
        return redirect(url_for('views.home'))



@views.route('/submissions/error/<submission_id>')
@login_required
def submission_error(submission_id):

    submission = Submissions.query.get(submission_id)
    if submission: submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id and submission.status == 2:
        return submission.error_msg
    elif submission and submission_user.school_id == current_user.school_id and submission.status == 2:
        return submission.error_msg
    else:
        return redirect(url_for('views.home'))


@views.route('/submissions/testing_results/<submission_id>')
@login_required
def testing_results(submission_id):

    test_input = []
    test_output = []
    user_output = []
    contest = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate <= datetime.now(), Contest.closingDate >= datetime.now()).first()
    submission = Submissions.query.get(submission_id)
    if submission: submission_user = User.query.get(submission.user_id)

    ## Jei šiuo metu vyksta konkursas
    if contest and not (submission.task and submission.task.contestID) == contest.id:
        return redirect(url_for('views.home'))

    ## Į masyvą sudedami testų duomenys ir sprendimo rezultatai
    if submission and submission.task and submission.status == 3:

        for test_id in range(1, min(len(submission.output), submission.task.open_test_cases)+1):

            input_file = f'/home/ubuntu/Testai/{submission.task.problemsId}/{test_id}.in'
            output_file = f'/home/ubuntu/Testai/{submission.task.problemsId}/{test_id}.sol'
            user_output.append(submission.output[test_id-1])

            with open(input_file) as f:
                input_data = f.read()
                if len(input_data.splitlines()) <= 10000 and len(input_data) <= 1000000:
                    test_input.append(input_data)
                else:
                    test_input.append("Failo peržiūra negalima dėl per didelio failo dydžio. Norint peržiūrėti šį failą, atsisiųskite jį.")

            with open(output_file) as f:
                output_data = f.read()
                if len(output_data.splitlines()) <= 10000 and len(output_data) <= 1000000:
                    test_output.append(output_data)
                else:
                    test_output.append("Failo peržiūra negalima dėl per didelio failo dydžio. Norint peržiūrėti šį failą, atsisiųskite jį.")


    ## Jei nėra ištrinta sprendimo užduotis
    if submission and submission.task and submission.user_id == current_user.id and submission.status == 3:
        return render_template('results.html', results=submission.results, user=current_user, school_name=user_school_name(), task_name=submission.task.name,
            date=submission.date, score=submission.score, test_count=submission.task.problems.testCount, open_test_cases=min(len(submission.output), submission.task.open_test_cases), id=submission.id, task_id=submission.task.id,
            test_input=test_input, test_output=test_output, user_output=user_output, python_error_msg=submission.python_error_msg, userContests=findContests(), current_time=datetime.now(), pageName="Testavimo rezultatai")
    
    elif submission and submission.task and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id and submission.status == 3:
        return render_template('results.html', results=submission.results, user=current_user, school_name=user_school_name(), task_name=submission.task.name,
            date=submission.date, score=submission.score, test_count=submission.task.problems.testCount, open_test_cases=min(len(submission.output), submission.task.open_test_cases), id=submission.id, task_id=submission.task.id,
            test_input=test_input, test_output=test_output, user_output=user_output, python_error_msg=submission.python_error_msg, userContests=findContests(), current_time=datetime.now(), pageName="Testavimo rezultatai")
    
    ## Jei yra ištrinta sprendimo užduotis
    elif submission and submission.user_id == current_user.id and submission.status == 3:
        return render_template('results_no_task.html', results=submission.results, user=current_user, school_name=user_school_name(),
            date=submission.date, score=submission.score, id=submission.id, python_error_msg=submission.python_error_msg, userContests=findContests(), current_time=datetime.now(), pageName="Testavimo rezultatai")
    
    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id and submission.status == 3:
        return render_template('results_no_task.html', results=submission.results, user=current_user, school_name=user_school_name(),
            date=submission.date, score=submission.score, id=submission.id, python_error_msg=submission.python_error_msg, userContests=findContests(), current_time=datetime.now(), pageName="Testavimo rezultatai")

    else:
        return redirect(url_for('views.home'))



@views.route('/task/<task_id>/test_case/<test_case_id>/<test_type>')
@login_required
def test_case_input_output(task_id, test_case_id, test_type):

    task_id = int(task_id)
    test_case_id = int(test_case_id)
    task = Task.query.get(task_id)
    if task: problem = Problems.query.get(task.problemsId)

    if task and problem and task_authorization(task_id) and test_case_id >= 1 and test_case_id <= task.open_test_cases:

        if test_type == "IN":
            return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.in')
            try: return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.in')
            except: return redirect(url_for('views.home'))

        elif test_type == "SOL":
            try: return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.sol')
            except: return redirect(url_for('views.home'))

        else: return redirect(url_for('views.home'))

    else:
        return redirect(url_for('views.home'))



@views.route('/task/<submission_id>/test_case/<test_case_id>')
@login_required
def user_test_case_output(submission_id, test_case_id):

    submission_id = int(submission_id)
    test_case_id = int(test_case_id)
    submission = Submissions.query.get(submission_id)

    if submission: submission_user = User.query.get(submission.user_id)

    if submission and submission.user_id == current_user.id and test_case_id >= 1 and test_case_id <= len(submission.output):

        output = submission.output[test_case_id-1]
        response = Response(output, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{test_case_id}.sol')
        return response

    elif submission and current_user.urole == "SCHOOL-ADMIN" and submission_user.school_id == current_user.school_id and test_case_id >= 1 and test_case_id <= len(submission.output):

        output = submission.output[test_case_id-1]
        response = Response(output, content_type='text/plain')
        response.headers.set('Content-Disposition', 'attachment', filename=f'{test_case_id}.sol')
        return response

    else: 
        return redirect(url_for('views.home'))



@views.route('/edit_user', methods=['GET', 'POST'])
@login_required
def edit_user():

    if request.method == 'POST':

        data = request.get_json()
        default_language = data.get('default_language')
        send_submission_copy = data.get('send_submission_copy')
        send_student_submission_copy = data.get('send_student_submission_copy')
        send_new_teacher_comment = data.get('send_new_teacher_comment')
        send_new_student_comment = data.get('send_new_student_comment')
        hide_name_in_competitions = data.get('hide_name_in_competitions')

        user = User.query.get(current_user.id)
        if not (default_language == "c++" or default_language == "python3"):
            return jsonify({'error': 'Numatytoji programavimo kalba gali būti C++ arba Python 3.'}), 200

        if current_user.urole == "SCHOOL-ADMIN":
            user.settings.send_submission_email = send_submission_copy
            user.settings.send_student_submission_email = send_student_submission_copy
            user.settings.send_new_student_comment_email = send_new_student_comment
            user.settings.default_language = default_language
        elif current_user.urole == "GENERAL":
            user.settings.send_submission_email = send_submission_copy
            user.settings.send_new_comment_email = send_new_teacher_comment
            user.settings.default_language = default_language
            user.settings.hide_name_in_competitions = hide_name_in_competitions
        elif current_user.urole == "SERVER-ADMIN":
            user.settings.send_submission_email = send_submission_copy
            user.settings.default_language = default_language
            user.settings.hide_name_in_competitions = hide_name_in_competitions

        db.session.commit()
        return jsonify({'success': 'Vartotojo nustatymai sėkmingai atnaujinti.'}), 200
    else:

        if current_user.urole == "SCHOOL-ADMIN":

            school_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
            school_classes = sorted(school_classes, key=sorting_class)
            tags = Tag.query.filter_by(school_id=current_user.school_id).all()
            groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
            users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
            users = sorted(users, key=sorting_users_by_class)

            all_classes_users = []
            for school_class in school_classes:
                class_users = User.query.filter_by(school_id=current_user.school_id, class_id=school_class.id, urole="GENERAL").all()
                class_users_ids = []
                for user_id in class_users:
                    class_users_ids.append(user_id.id)
                all_classes_users.append(class_users_ids)

            groupUsers = []
            for group in groups:
                students = []
                for groupUserID in group.students:
                    groupUser = User.query.get(groupUserID)
                    if groupUser:
                        students.append(groupUser)
                groupUsers.append(students)

            user_school = School.query.get(current_user.school_id)
            return render_template('edit_user.html', user=current_user, school_name=user_school_name(), user_school=user_school, school_classes=school_classes, all_classes_users=all_classes_users, users=users, tags=tags, groups=groups, groupUsers=groupUsers, pageName="Nustatymai")
        else:
            return render_template('edit_user.html', user=current_user, school_name=user_school_name(), userContests=findContests(), current_time=datetime.now(), pageName="Nustatymai")



@views.route('/submit_comment', methods=['POST'])
@login_required
def submit_comment():

    if request.method == 'POST':

        data = request.get_json()
        submission_id = data.get('submissionId')
        message = data.get('comment')

        submission = Submissions.query.get(submission_id)
        if not submission or submission.user_id != current_user.id:

            if submission and current_user.urole == "SCHOOL-ADMIN" and submission.user.school_id == current_user.school_id:
                pass
            else:
                return jsonify({'error': 'Netinkamas sprendimo ID numeris.'}), 400

        if len(message) > 600:
            return jsonify({'error': 'Komentaro ilgis privalo būti mažesnis nei 600 simbolių.'}), 400

        new_message = Messages(
            user_id=current_user.id,
            message=message,
            submission_id=submission_id
        )

        db.session.add(new_message)
        db.session.commit()

        if current_user.urole == "SCHOOL-ADMIN" and submission.user.settings.send_new_comment_email:
            email_new_message.delay(new_message.id, None)

        elif current_user.urole == "GENERAL":

            teachers = User.query.filter_by(school_id=submission.user.school_id, urole="SCHOOL-ADMIN").all()
            for teacher in teachers:
                if teacher.settings.send_new_student_comment_email:
                    email_new_message.delay(new_message.id, teacher.id)


        return jsonify({'success': 'Naujas komentaras sėkmingai pridėtas.'}), 200



@views.route('/rank')
@login_required
def user_rank():

    competitive_task_results = CompetitiveTaskResult.query.filter(CompetitiveTaskResult.user_id == current_user.id, CompetitiveTaskResult.rank != -1).all()

    if not competitive_task_results:
        flash('Jūs dar nedalyvavote nei vienose varžybose, kurios buvo įvertintos, todėl negalite pasiekti šio puslapio.', category='error')
        return redirect(url_for('views.home'))

    ## Surikiuojame varžybų rezultatus pagal varžybų uždavinį
    def sort_by_task_rank_FileID(competitive_task_result):
        task = Task.query.get(competitive_task_result.task_id)
        task_copy = CompetitiveTaskCopy.query.filter_by(taskID=competitive_task_result.task_id).first()
        if task:
            return task.rank_FileID
        else:
            return task.task_copy

    competitive_task_results = sorted(competitive_task_results, key=sort_by_task_rank_FileID)

    ## Išsaugome varžybų uždavinių pavadinimus ir gautą už dalyvavimą varžybose gautą reitingą
    userRankHistory = []
    userPlaceInCompetitions = []
    competitiveTaskNames = []

    ## Randame vartotojo užimtą vietą varžybose
    def user_place_in_competition(user_competitive_task_result):

        competitive_task_results_users = CompetitiveTaskResult.query.filter(
            CompetitiveTaskResult.task_id == user_competitive_task_result.task_id,
            CompetitiveTaskResult.status == "participated",
            CompetitiveTaskResult.score != -1
        ).all()
        competitive_task_results_users = sorted(competitive_task_results_users, key=lambda competitive_task_result: (-getSubmissionScoreByID(competitive_task_result.best_submission_id), competitive_task_result.score))

        best_submissions_scores = []
        user_places_in_competition = []

        for competitive_task_result in competitive_task_results_users:
            best_submissions_scores.append(getSubmissionScoreByID(competitive_task_result.best_submission_id))

        for index, competitive_task_result in enumerate(competitive_task_results_users):

            if index != 0 and best_submissions_scores[index-1] == best_submissions_scores[index] and competitive_task_results_users[index-1].score == competitive_task_result.score:
                user_places_in_competition.append(user_places_in_competition[index-1])
            elif index != 0 and best_submissions_scores[index-1] == 0:
                user_places_in_competition.append(user_places_in_competition[index-1])
            elif index != 0:
                user_places_in_competition.append(user_places_in_competition[index-1]+1)
            else:
                user_places_in_competition.append(1)

            if competitive_task_result.user_id == user_competitive_task_result.user_id:
                return user_places_in_competition[index]

    for competitive_task_result in competitive_task_results:

        userRankHistory.append(competitive_task_result.rank)
        task = Task.query.get(competitive_task_result.task_id)
        task_copy = CompetitiveTaskCopy.query.filter_by(taskID=competitive_task_result.task_id).first()
        usr_place_in_competition = user_place_in_competition(competitive_task_result)
        userPlaceInCompetitions.append(usr_place_in_competition)

        if task:
            competitiveTaskNames.append(task.name)
        elif task_copy:
            competitiveTaskNames.append(task_copy)
        else:
            competitiveTaskNames.append("Užduotis pašalinta")

    ## Sugeneruojame mokinio klasės varžybų lentelę
    if current_user.user_class:
        user_class_name = current_user.user_class.name
        users_ranks = User.query.join(User_class).filter(User.school_id == current_user.school_id, User_class.id == current_user.user_class.id, User.current_rank != -1).all()
    else:
        user_school = School.query.get(current_user.school_id)
        user_class_name = user_school.name
        users_ranks = User.query.filter(User.school_id == current_user.school_id, User.current_rank != -1).all()

    users_places_in_leaderboard = []
    users_contests = []
    users_ranks = sorted(users_ranks, key=lambda user: -user.current_rank)

    for index, user_rank in enumerate(users_ranks):

        user_contests = CompetitiveTaskResult.query.filter_by(user_id=user_rank.id, status="participated").all()
        users_contests.append(len(user_contests))

        if index != 0 and users_ranks[index-1].current_rank == users_ranks[index].current_rank:
            users_places_in_leaderboard.append(users_places_in_leaderboard[index-1])
        elif index != 0:
            users_places_in_leaderboard.append(users_places_in_leaderboard[index-1]+1)
        else:
            users_places_in_leaderboard.append(1)

    return render_template('user_rank.html', competitive_task_results=competitive_task_results, userRankHistory=userRankHistory, userPlaceInCompetitions=userPlaceInCompetitions, competitiveTaskNames=competitiveTaskNames, users_ranks=users_ranks, users_places_in_leaderboard=users_places_in_leaderboard, users_contests=users_contests, user_class_name=user_class_name, user=current_user, school_name=user_school_name(), userContests=findContests(), current_time=datetime.now(), pageName="Varžybų reitingai")



@views.route('/help')
def help_center():
    scrollTo = request.args.get('scrollTo', None)
    if not current_user.is_anonymous:
        return render_template('help_center.html', scrollTo=scrollTo, user=current_user, school_name=user_school_name(), pageName="Pagalbos centras")
    else:
        return render_template('help_center.html', user=None, scrollTo=scrollTo, pageName="Pagalbos centras")



@views.route('/api/uploadProfileImg', methods=['POST'])
@login_required
def uploadProfileImg():

    ### Papildoma funkcija, skirta nuotraukos matmenims keisti ###
    def resize_image(img, size):

        width, height = img.size
        new_size = (size, size)

        if width > height:
            left = (width - height) / 2
            upper = 0
            right = left + height
            lower = height
        else:
            left = 0
            upper = (height - width) / 2
            right = width
            lower = upper + width

        img = img.crop((left, upper, right, lower))
        img = img.resize(new_size, Image.LANCZOS)
        return img


    ## Patikriname, ar vartotojui ši funkcija nėra užblokuota
    if current_user.profileImgBan:
        return jsonify({'error': 'Profilio nuotraukos keitimo funkcija Jūsų paskyrai yra užblokuota, todėl Jūs negalite pakeisti savo profilio nuotraukos.'}), 400

    ## Gaunamas įkeltas nuotraukos failas
    file = request.files['profileImgFile']
    mime_type, encoding = mimetypes.guess_type(file.filename)

    if not file or file.filename == '':
        return jsonify({'error': 'Norint įkelti profilio nuotrauką, būtina pasirinkti nuotraukos failą.'}), 400

    # Patikriname, ar tinkamas failo formatas
    file_extension = os.path.splitext(file.filename)[1].lower()
    if not(file_extension == ".png" or file_extension == ".jpeg"):
        return jsonify({'error': 'Netinkamas profilio nuotraukos failo tipas. Prašome pasirinkti .png arba .jpeg failą.'}), 400
    if not(mime_type == "image/png" or mime_type == "image/jpeg"):
        return jsonify({'error': 'Netinkamas profilio nuotraukos failo tipas. Prašome pasirinkti .png arba .jpeg failą.'}), 400

    ## Patikriname failo dydį
    if 'Content-Length' in request.headers:
        content_length = int(request.headers['Content-Length'])
        if content_length > 5242880:
            return jsonify({'error': 'Per didelis nuotraukos failo dydis. Failo dydis neturi viršyti 5 MB.'}), 400
    

    ## Išsaugoma profilio nuotrauka
    file.save(f"/home/ubuntu/Profile_images/{current_user.id}.png")

    try:
        ## Išsaugoma profilio nuotrauka
        save_path = f"/home/ubuntu/Profile_images/{current_user.id}.png"
        file.save(save_path)

        ## Pakeičiami nuotraukos matmenys
        img = Image.open(file)
        img = resize_image(img, 320)
        img.save(save_path)
    except:
        return jsonify({'error': 'Įvyko nenumatyta klaida įkeliant nuotraukos failą.'}), 400

    return jsonify({'success': 'Profilio nuotrauka sėkmingai įkelta.'}), 200



@views.route('/getProfileImage')
@login_required
def getProfileImage():

    file_path = f"/home/ubuntu/Profile_images/{current_user.id}.png"
    if os.path.exists(file_path):
        return send_file(file_path)
    else:
        return send_file("/home/ubuntu/Profile_images/unknown.png")



@views.route('/getUserProfileImage/<userID>')
@login_required
def getUserProfileImage(userID):

    user = User.query.get(userID)
    user_joining_request = School_waiting_list.query.filter_by(user_id=userID).first()

    if not user:
        return send_file("/home/ubuntu/Profile_images/unknown.png")
    elif current_user.urole == "GENERAL" and user.school_id != current_user.school_id:
        return send_file("/home/ubuntu/Profile_images/unknown.png")
    elif current_user.urole == "SCHOOL-ADMIN" and not(user.school_id == current_user.school_id or user_joining_request.school_id == current_user.school_id):
        return send_file("/home/ubuntu/Profile_images/unknown.png")

    file_path = f"/home/ubuntu/Profile_images/{user.id}.png"
    if os.path.exists(file_path):
        return send_file(file_path)
    else:
        return send_file("/home/ubuntu/Profile_images/unknown.png")



@views.route('/api/deleteProfileRequest', methods=['POST'])
@login_required
def deleteProfileRequest():

    data = request.get_json()
    password = data.get('password')

    ## Patikriname vartotojo slaptažodį
    if not check_password_hash(current_user.password, password):
        return jsonify({'error': 'neteisingas vartotojo slaptažodis.'}), 400

    ## Patikriname ar nėra ankstesnių profilio pašalinimo užklausų
    delete_request = Profile_delete_request.query.filter_by(user_id=current_user.id).first()

    if delete_request:
        db.session.delete(delete_request)
        db.session.commit()

    ## Sugeneruojamas patvirtinimo kodas
    verification_code = secrets.randbelow(90000) + 10000
    same_verification_code = Profile_delete_request.query.filter_by(code=verification_code).first()
    while same_verification_code:
        verification_code = secrets.randbelow(90000) + 10000
        same_verification_code = Profile_delete_request.query.filter_by(code=verification_code).first()

    ## Sukuriama nauja profilio ištrynimo užklausa
    new_delete_request = Profile_delete_request(user_id=current_user.id, code=verification_code)
    db.session.add(new_delete_request)
    db.session.commit()

    ## Sugeneruotas patvirtinimo kodas išsiunčiamas el. paštu
    email_verification_code.delay(current_user.id, verification_code, "Paskyros pašalinimo patvirtinimo kodas")

    return jsonify({'requestID': new_delete_request.id}), 200



@views.route('/api/emailCodeVerification', methods=['POST'])
@login_required
def emailCodeVerification():

    data = request.get_json()
    code = data.get('code')

    ## Patikriname, ar yra pateikta profilio pašalinimo užklausa
    delete_request = Profile_delete_request.query.filter_by(user_id=current_user.id).first()
    if not delete_request:
        return jsonify({'error': 'profilio pašalinimo užklausa nebuvo gauta. Bandykite per naujo.'}), 400

    ## Patikriname, ar patvirtinimo kodas teisingas
    if not delete_request.code == code:
        return jsonify({'error': 'neteisingas patvirtinimo kodas.'}), 400

    ## Patikriname, ar užklausos galiojimo laikas dar nėra pasibaigęs
    code_request_date = datetime.strptime(delete_request.code_request_date, "%Y-%m-%d %H:%M:%S.%f")
    if datetime.now() - code_request_date > timedelta(minutes=10):
        return jsonify({'error': 'patvirtinimo kodo galiojimo laikas pasibaigęs.'}), 400

    ## Patvirtiname profilio pašalinimo užklausą
    delete_request.authorized = True
    db.session.commit()

    return jsonify({'success': 'Profilio pašalinimo užklausa sėkmingai patvirtinta.'}), 200



@views.route('/api/deleteUserProfile', methods=['POST'])
@login_required
def deleteUserProfile():

    ### Pagalbinė funkcija, skirta nustatyti, ar vartotojo ID yra grupėje ###
    def user_is_in_the_group_list(group_id):
        group = NewGroup.query.get(group_id)
        for group_user_id in group.students:
            if int(group_user_id) == current_user.id: return True
        return False

    ## Patikriname, ar yra pateikta profilio pašalinimo užklausa
    delete_request = Profile_delete_request.query.filter_by(user_id=current_user.id).first()
    if not delete_request:
        return jsonify({'error': 'profilio pašalinimo užklausa nebuvo gauta. Bandykite per naujo.'}), 400

    ## Patikriname, ar profilio pašalinimo užklausa yra patvirtinta
    if not delete_request.authorized:
        return jsonify({'error': 'profilio pašalinimo užklausa nebuvo patvirtinta.'}), 400

    all_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
    all_groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
    school_waiting_list = School_waiting_list.query.filter_by(user_id=current_user.id).first()
    settings = User_settings.query.filter_by(user_id=current_user.id).first()
    password_reset_requests = Password_reset_request.query.filter_by(user_id=current_user.id).all()
    submissions = Submissions.query.filter_by(user_id=current_user.id).all()
    user_messages = Messages.query.filter_by(user_id=current_user.id).all()
    competitive_task_results = CompetitiveTaskResult.query.filter_by(user_id=current_user.id).all()

    tasks = [task for task in all_tasks if user_is_in_the_task_list(task.id)]
    groups = [group for group in all_groups if user_is_in_the_group_list(group.id)]

    for task in tasks:
        task_users = task.users
        modified_task_users = [char_id for char_id in task_users if char_id != current_user.id and char_id != str(current_user.id)]
        task.users = modified_task_users
        if task.users == []: db.session.delete(task)

    for group in groups:
        group_users = group.students
        modified_group_users = [char_id for char_id in group_users if char_id != current_user.id and char_id != str(current_user.id)]
        group.students = modified_group_users
        if group.students == []:
            tasks_connected_to_group = Task.query.filter(Task.assigned_groups.contains(group)).all()
            for connected_task in tasks_connected_to_group:
                connected_task.assigned_groups.remove(group)
            db.session.delete(group)

    ## Patikriname, ar vartotojas nėra vienintelis klasės dalyvis
    if current_user.user_class:
        users_assigned_to_class = User.query.filter_by(class_id=current_user.class_id).all()
        user_class = User_class.query.get(current_user.class_id)
        if len(users_assigned_to_class) == 1:
            tasks_connected_to_class = Task.query.filter(Task.assigned_classes.contains(user_class)).all()
            for connected_task in tasks_connected_to_class:
                connected_task.assigned_classes.remove(user_class)

    if school_waiting_list:
        db.session.delete(school_waiting_list)
    if settings:
        db.session.delete(settings)
    for request in password_reset_requests:
        db.session.delete(request)
    for competitiveTaskResult in competitive_task_results:
        db.session.delete(competitiveTaskResult)
    for message in user_messages:
        db.session.delete(message)

    db.session.commit()

    for submission in submissions:
        plagiarism_pairs1 = Plagiarism_pair.query.filter_by(leftSubmissionID=submission.id).all()
        plagiarism_pairs2 = Plagiarism_pair.query.filter_by(rightSubmissionID=submission.id).all()
        plagiarism_pairs = plagiarism_pairs1 + plagiarism_pairs2
        submission_messages = Messages.query.filter_by(submission_id=submission.id).all()
        codeComments = CodeComment.query.filter_by(submission_id=submission.id).all()
        for plagiarism_pair in plagiarism_pairs:
            db.session.delete(plagiarism_pair)
        for submission_message in submission_messages:
            db.session.delete(submission_message)
        for comment in codeComments:
            db.session.delete(comment)
        db.session.delete(submission)

    ## Pašalinama vartotojo profilio nuotrauka
    try:
        os.remove(f'/home/ubuntu/Profile_images/{user.id}.png')
    except:
        pass

    ## Vartotojas informuojamas apie paskyros pašalinimą
    school_name = School.query.get(current_user.school_id)
    subject = f"Informacija apie Jūsų paskyros pašalinimą"
    message = f"Informuojame, kad Jūsų prašymu pašalinome Jūsų paskyrą bei visus su ja susijusius duomenis. Jei ateityje norėsite naudotis programavimo platforma, turėsite iš naujo susikurti savo paskyrą."
    email_msg.delay(current_user.first_last_name, current_user.email, subject, message)

    delete_user = User.query.get(current_user.id)
    logout_user()
    db.session.delete(delete_user)
    db.session.delete(delete_request)
    db.session.commit()

    return jsonify({'success': 'Profilis sėkmingai pašalintas.'}), 200



@views.route('/api/downloadUserData', methods=['POST'])
@login_required
def downloadUserData():

    data = request.get_json()
    password = data.get('password')

    ## Patikriname vartotojo slaptažodį
    if not check_password_hash(current_user.password, password):
        return jsonify({'error': 'neteisingas vartotojo slaptažodis.'}), 400

    school_waiting_list = School_waiting_list.query.filter_by(user_id=current_user.id).all()
    settings = User_settings.query.filter_by(user_id=current_user.id).first()
    password_reset_requests = Password_reset_request.query.filter_by(user_id=current_user.id).all()
    profile_delete_requests = Profile_delete_request.query.filter_by(user_id=current_user.id).all()
    submissions = Submissions.query.filter_by(user_id=current_user.id).all()
    user_messages = Messages.query.filter_by(user_id=current_user.id).all()
    code_comments = CodeComment.query.filter_by(user_id=current_user.id).all()
    competitive_task_results = CompetitiveTaskResult.query.filter_by(user_id=current_user.id).all()

    output = StringIO()
    writer = csv.writer(output)

    ## Vartotojo asmeninė informacija
    writer.writerow(["Profilio informacija"])
    dict_writer = csv.DictWriter(output, fieldnames=["id", "google_sub", "email", "password", "first_last_name", "urole", "school_id", "current_rank", "class_id", "Profilio nuotrauka (pasiekiama internetu)"])
    dict_writer.writeheader()

    dict_writer.writerow({
        "id": current_user.id, 
        "google_sub": current_user.google_sub, 
        "email": current_user.email, 
        "password": current_user.password, 
        "first_last_name": current_user.first_last_name, 
        "urole": current_user.urole,
        "school_id": current_user.school_id,
        "current_rank": current_user.current_rank,
        "class_id": current_user.class_id,
        "Profilio nuotrauka (pasiekiama internetu)": "https://programavimoplatforma.online/getProfileImage"
    })
    writer.writerow([])

    ## Vartotojo profilio nustatymai
    writer.writerow(["Profilio nustatymai"])
    dict_writer = csv.DictWriter(output, fieldnames=["id", "user_id", "send_submission_email", "send_student_submission_email", "send_new_comment_email", "send_new_student_comment_email", "hide_name_in_competitions", "show_message_alert", "default_language", "default_theme", "rank_alert_shown"])
    dict_writer.writeheader()

    dict_writer.writerow({
        "id": current_user.settings.id, 
        "user_id": current_user.settings.user_id, 
        "send_submission_email": current_user.settings.send_submission_email, 
        "send_student_submission_email": current_user.settings.send_student_submission_email, 
        "send_new_comment_email": current_user.settings.send_new_comment_email,
        "send_new_student_comment_email": current_user.settings.send_new_student_comment_email,
        "hide_name_in_competitions": current_user.settings.hide_name_in_competitions,
        "show_message_alert": current_user.settings.show_message_alert,
        "default_language": current_user.settings.default_language,
        "default_theme": current_user.settings.default_theme,
        "rank_alert_shown": current_user.settings.rank_alert_shown
    })
    writer.writerow([])

    ## Slaptažodžio pakeitimo užklausos
    if password_reset_requests:

        writer.writerow(["Slaptažodžio pakeitimo užklausos"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "user_id", "code", "date"])
        dict_writer.writeheader()

        for password_reset_request in password_reset_requests:
            dict_writer.writerow({
                "id": password_reset_request.id, 
                "user_id": password_reset_request.user_id, 
                "code": password_reset_request.code, 
                "date": password_reset_request.date
            })
        writer.writerow([])

    ## Profilio ištrynimo užklausos
    if profile_delete_requests:

        writer.writerow(["Profilio ištrynimo užklausos"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "user_id", "authorized", "code", "code_request_date"])
        dict_writer.writeheader()

        for profile_delete_request in profile_delete_requests:
            dict_writer.writerow({
                "id": profile_delete_request.id, 
                "user_id": profile_delete_request.user_id,
                "authorized": profile_delete_request.authorized,
                "code": profile_delete_request.code, 
                "code_request_date": profile_delete_request.code_request_date
            })
        writer.writerow([])

    ## Pateikti sprendimai
    plagiarism_pairs = []
    if submissions:

        writer.writerow(["Pateikti sprendimai"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "user_id", "task_id", "celery_id", "status", "results", "output", "score", "error_msg", "python_error_msg", "submitted_code", "language", "date"])
        dict_writer.writeheader()

        for submission in submissions:
            plagiarism_pairs1 = Plagiarism_pair.query.filter_by(leftSubmissionID=submission.id).all()
            plagiarism_pairs2 = Plagiarism_pair.query.filter_by(rightSubmissionID=submission.id).all()
            plagiarism_pairs = plagiarism_pairs + plagiarism_pairs1 + plagiarism_pairs2
            dict_writer.writerow({
                "id": submission.id, 
                "user_id": submission.user_id,
                "task_id": submission.task_id,
                "celery_id": submission.celery_id, 
                "status": submission.status,
                "results": submission.results,
                "output": submission.output,
                "score": submission.score,
                "error_msg": submission.error_msg,
                "python_error_msg": submission.python_error_msg,
                "submitted_code": submission.submitted_code,
                "language": submission.language,
                "date": submission.date
            })
        writer.writerow([])

    ## Plagijuotų kodų poros
    if plagiarism_pairs:

        writer.writerow(["Plagijuotų kodų poros"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "leftSubmissionID", "rightSubmissionID", "similarity"])
        dict_writer.writeheader()

        for plagiarism_pair in plagiarism_pairs:
            dict_writer.writerow({
                "id": plagiarism_pair.id, 
                "leftSubmissionID": plagiarism_pair.leftSubmissionID,
                "rightSubmissionID": plagiarism_pair.rightSubmissionID,
                "similarity": plagiarism_pair.similarity
            })
        writer.writerow([])

    ## Vartotojo žinutės
    if user_messages:

        writer.writerow(["Vartotojo žinutės"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "user_id", "message", "date", "seen", "submission_id"])
        dict_writer.writeheader()

        for message in user_messages:
            dict_writer.writerow({
                "id": message.id, 
                "user_id": message.user_id,
                "message": message.message,
                "date": message.date, 
                "seen": message.seen,
                "submission_id": message.submission_id
            })
        writer.writerow([])

    ## Kodų komentarai
    if code_comments:

        writer.writerow(["Kodų komentarai"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "user_id", "submission_id", "startRow", "startCol", "endRow", "endCol", "comment", "date"])
        dict_writer.writeheader()

        for comment in code_comments:
            dict_writer.writerow({
                "id": comment.id, 
                "user_id": comment.user_id,
                "submission_id": comment.submission_id,
                "startRow": comment.startRow, 
                "startCol": comment.startCol,
                "endRow": comment.endRow,
                "endCol": comment.endCol,
                "comment": comment.comment,
                "date": comment.date
            })
        writer.writerow([])

    ## Mokyklos priėmimo eilė
    if school_waiting_list:

        writer.writerow(["Mokyklos priėmimo eilė"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "user_id", "submission_id"])
        dict_writer.writeheader()

        for waiting_list in school_waiting_list:
            dict_writer.writerow({
                "id": waiting_list.id, 
                "user_id": waiting_list.user_id,
                "submission_id": waiting_list.submission_id
            })
        writer.writerow([])

    ## Užduočių varžybų rezultatai
    if competitive_task_results:

        writer.writerow(["Užduočių varžybų rezultatai"])
        dict_writer = csv.DictWriter(output, fieldnames=["id", "task_id", "user_id", "status", "start_date", "end_date", "best_submission_id", "attempts", "score", "rank"])
        dict_writer.writeheader()

        for competitiveTaskResult in competitive_task_results:
            dict_writer.writerow({
                "id": competitiveTaskResult.id, 
                "task_id": competitiveTaskResult.task_id,
                "user_id": competitiveTaskResult.user_id,
                "status": competitiveTaskResult.status, 
                "start_date": competitiveTaskResult.start_date,
                "end_date": competitiveTaskResult.end_date,
                "best_submission_id": competitiveTaskResult.best_submission_id,
                "attempts": competitiveTaskResult.attempts,
                "score": competitiveTaskResult.score,
                "rank": competitiveTaskResult.rank
            })
        writer.writerow([])

    response = Response(output.getvalue(), mimetype='text/csv')
    response.headers["Content-Disposition"] = "attachment; filename=vartotojo_asmeniniai_duomenys.csv"
    return response



@views.route('/api/saveTaskDraft', methods=['POST'])
@login_required
def saveTaskDraft():

    data = request.get_json()
    task_id = data.get('task_id')
    code = data.get('code')

    ## Patikriname, ar vartotojas turi teisę pasiekti užduotį
    if not task_authorization(task_id):
        return jsonify({'error': 'Pasirinkta užduotis neegzistuoja arba jūs neturite teisės jos pasiekti.'}), 400

    ## Patikriname juodraštinį sprendimą
    if len(code) >= 560000:
        return jsonify({'error': 'Sprendimas yra per ilgas, todėl jo išsaugoti negalima.'}), 400

    ## Jei yra ankstesnis juodraštis, jį ištriname
    same_task_draft = TaskDraft.query.filter_by(task_id=task_id, user_id=current_user.id).first()
    if same_task_draft:
        db.session.delete(same_task_draft)
        db.session.commit()

    ## Sukuriame užduoties juodraštį
    new_task_draft = TaskDraft(task_id=task_id, user_id=current_user.id, code=code)
    db.session.add(new_task_draft)
    db.session.commit()

    return jsonify({'success': 'Užduoties juodraštis sėkmingai sukurtas.'}), 200



@views.route('/api/getTaskDraft', methods=['POST'])
@login_required
def getTaskDraft():

    data = request.get_json()
    task_id = data.get('task_id')
    task_draft = TaskDraft.query.filter_by(task_id=task_id, user_id=current_user.id).first()

    if task_draft:
        return jsonify({'draft': task_draft.code}), 200
    else:
        return jsonify({'error': 'Užduoties juodraštis nerastas.'}), 400