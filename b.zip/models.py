from . import db
from flask_login import UserMixin
from sqlalchemy import DateTime, Table, Column, Integer
from sqlalchemy_jsonfield import JSONField as OriginalJSONField
from datetime import datetime
from sqlalchemy.sql import func
import pytz
from sqlalchemy import TypeDecorator
from sqlalchemy import ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from sqlalchemy import DateTime

timezone = pytz.timezone('Europe/Vilnius')

class JSONField(OriginalJSONField):
    cache_ok = True


Task_tag_connection = Table(
    'tag_task_association', db.Model.metadata,
    Column('tag_id', Integer, ForeignKey('tag.id')),
    Column('task_id', Integer, ForeignKey('task.id'))
)

Submission_plagiarismPair_connection = Table(
    'submission_plagiarismPair_association', db.Model.metadata,
    Column('plagiarism_pair_id', Integer, ForeignKey('plagiarism_pair.id')),
    Column('submission_id', Integer, ForeignKey('submissions.id'))
)

task_user_class_association = Table('task_user_class_association', db.Model.metadata,
    Column('task_id', Integer, ForeignKey('task.id'), primary_key=True),
    Column('user_class_id', Integer, ForeignKey('user_class.id'), primary_key=True)
)

task_group_association = Table('task_group_association', db.Model.metadata,
    Column('task_id', Integer, ForeignKey('task.id'), primary_key=True),
    Column('group_id', Integer, ForeignKey('new_group.id'), primary_key=True)
)

class Problems(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    timeLimit = db.Column(db.Integer, default=1)
    memoryLimit = db.Column(db.Integer, default=64)
    testCount = db.Column(db.Integer)
    uploaded_IN_files = db.Column(db.Integer, default=0)
    uploaded_SOL_files = db.Column(db.Integer, default=0)
    school_id = db.Column(db.Integer)
    custom_tester = db.Column(db.Boolean, default=False)
    order_doesnt_matter = db.Column(db.Boolean)
    ignore_multiple_whitespaces = db.Column(db.Boolean)
    input_file_name = db.Column(db.String(10))
    date = db.Column(db.String(19), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    celery_id = db.Column(db.String(200))
    visible = db.Column(db.Boolean, default=False)
    task = db.relationship('Task', backref='problems', lazy=True)
    category_id = db.Column(db.Integer, db.ForeignKey('problem_category.id'))
    category = relationship('ProblemCategory', back_populates='problems')

class ProblemCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer)
    name = db.Column(db.String(60))
    problems = relationship('Problems', back_populates='category')

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    problemsId = db.Column(db.Integer, db.ForeignKey('problems.id'))
    name = db.Column(db.String(100))
    openingDate = db.Column(DateTime, default=lambda: datetime.datetime.now(timezone))
    closingDate = db.Column(DateTime, default=lambda: datetime.datetime.now(timezone))
    school_id = db.Column(db.Integer)
    date = db.Column(db.String(19), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    testingDate = db.Column(db.DateTime(timezone=True))
    allow_cancel_submission = db.Column(db.Boolean, default=True)
    open_test_cases = db.Column(db.Integer, default=0)
    users = db.Column(JSONField)
    submissions = db.relationship('Submissions', backref='task', lazy=True)
    mode = db.Column(db.String(20), default="default") ## default, competitive
    competitiveTaskDuration = db.Column(db.Integer, default=-1) ## for competitive mode tasks
    not_participating = db.Column(JSONField) ## for competitive mode tasks
    tags = db.relationship('Tag', secondary=Task_tag_connection, back_populates='tasks')
    rank_FileID = db.Column(db.Integer, default=-1)
    contestID = db.Column(db.Integer, default=-1)
    assigned_classes = db.relationship('User_class', secondary=task_user_class_association, back_populates='tasks')
    assigned_groups = db.relationship('NewGroup', secondary=task_group_association, back_populates='tasks')

class TaskDraft(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer)
    user_id = db.Column(db.Integer)
    date = db.Column(DateTime, default=lambda: datetime.now())
    code = db.Column(db.String(560000))

class CompetitiveTaskCopy(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    taskID = db.Column(db.Integer, unique=True)
    school_id = db.Column(db.Integer)
    openingDate = db.Column(DateTime)
    date = db.Column(db.String(19))
    rank_FileID = db.Column(db.Integer, default=-1)

class School(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    owner_id = db.Column(db.Integer)
    problem_limit = db.Column(db.Integer)
    task_limit = db.Column(db.Integer)
    created_problems = db.Column(db.Integer, default=0)
    created_tasks = db.Column(db.Integer, default=0)
    invitation_code = db.Column(db.String(100), unique=True)
    availible_until = db.Column(DateTime)
    cppTemplate = db.Column(db.String(5000), default="")
    pythonTemplate = db.Column(db.String(5000), default="")

class School_waiting_list(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True)
    school_id = db.Column(db.Integer)
    user = relationship("User", back_populates="school_waiting_list")

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    google_sub = db.Column(db.String(1000), default='')
    email = db.Column(db.String(150), unique=True)
    emailVerified = db.Column(db.Boolean, default=False)
    password = db.Column(db.String(150))
    first_last_name = db.Column(db.String(41))
    urole = db.Column(db.String(20), default='GENERAL')
    school_id = db.Column(db.Integer, default=0)
    current_rank = db.Column(db.Integer, default=-1)
    profileImgBan = db.Column(db.Boolean, default=False)
    class_id = db.Column(db.Integer, db.ForeignKey('user_class.id'), nullable=True)
    submissions = db.relationship('Submissions', backref='user', lazy=True)
    school_waiting_list = relationship("School_waiting_list", back_populates="user")
    settings = db.relationship('User_settings', backref='user', uselist=False, lazy=True)
    loginForced = db.Column(db.Boolean, default=False)

class User_class(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer)
    name = db.Column(db.String(100))
    users = db.relationship('User', backref='user_class', lazy=True)
    tasks = db.relationship('Task', secondary=task_user_class_association, back_populates='assigned_classes')

class User_settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True)
    send_submission_email = db.Column(db.Boolean, default=True)
    send_student_submission_email = db.Column(db.Boolean, default=False)
    send_new_comment_email = db.Column(db.Boolean, default=True)
    send_new_student_comment_email = db.Column(db.Boolean, default=False)
    hide_name_in_competitions = db.Column(db.Boolean, default=False)
    show_message_alert = db.Column(db.Boolean, default=True)
    default_language = db.Column(db.String(20), default='c++')
    default_theme = db.Column(db.String(20), default='light')
    rank_alert_shown = db.Column(db.Boolean, default=False)

class Password_reset_request(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, unique=True)
    code = db.Column(db.String(15), unique=True)
    request_date = db.Column(db.String(19), default=lambda: datetime.now())
    verified = db.Column(db.Boolean, default=False)
    verification_date = db.Column(db.String(19), default=lambda: datetime.now())

class Profile_delete_request(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, unique=True)
    authorized = db.Column(db.Boolean, default=False)
    code = db.Column(db.String(15), unique=True)
    code_request_date = db.Column(db.String(19), default=lambda: datetime.now())

class Profiles_delete_request(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(15), unique=True)
    school_id = db.Column(db.Integer)
    users = db.Column(JSONField)
    authorized = db.Column(db.Boolean, default=False)
    code = db.Column(db.String(15), unique=True)
    code_request_date = db.Column(db.String(19), default=lambda: datetime.now())

class Email_verification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, unique=True)
    code = db.Column(db.String(15), unique=True)
    code_request_date = db.Column(db.String(19), default=lambda: datetime.now())

### Vartotojų pateikti sprendimai ###
## Pateiktas sprendimas turi šiuos statusus: ##
# -3 - pateiktas sprendimas laukia eilėje
# -2 - testavimas bus atliktas nustatytu metu
# -1 - testavimas atšauktas, nes testuojamas kitas pateiktas kodas
#  0 - pateiktas kodas šiuo metu testuojamas
#  1 - testavimas baigtas, testavimo metu atsirado nenumatyta klaida
#  2 - testavimas baigtas, pateiktas kodas nesikompiliuoja
#  3 - testavimas baigtas, pateiktas kodas kompiliuojasi

### Pateikto sprendimo rezultatai ###
## Pateikto sprendimo rezultatai turi šias reikšmes: ##
#  1 - testavimo metu viršytas laiko limitas
#  2 - testavimo metu viršytas atminties limitas
#  3 - pateiktas rezultatas tinka
#  4 - pateiktas rezultatas netinka
#  5 - dalinio testavimo metu atsirado nenumatyta klaida
#  6 - dalinio testavimo metu atsirado kompiliavimo klaida (tik Python kalbos kodams)
#  7 - Programos klaida: viršytas maksimalus vektoriaus dydis (cannot create std::vector larger than max_size())
#  8 - Programos klaida: neteisingas masyvo ilgis (std::bad_array_new_length)
#  9 - Programos klaida: atminties klaida (malloc(): corrupted top size)
#  10 - Programos klaida: atminties klaida (free(): invalid pointer)
#  11 - Programos klaida: viršytas atminties struktūros ilgio limitas (std::length_error)
#  12 - Programos klaida: duomenų perpildymo klaida (Buffer overflow)
#  13 - Programos klaida: duomenų paskirtymo klaida (std::bad_alloc)
#  14 - Programos klaida: programos vykdymo metu atsitiko nenumatyta klaida
#  15 - Programos klaida: neaprašyta c++ klaida

class Submissions(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'))
    celery_id = db.Column(db.String(200))
    status = db.Column(db.Integer) ## Pateikto sprendimo statusas
    results = db.Column(JSONField) ## Pateikto sprendimo rezultatai
    output = db.Column(JSONField) ## Programos spausdinami rezultatai
    score = db.Column(db.Integer, default=0)  ## Pateikto sprendimo įvertinimas
    error_msg = db.Column(db.String(300))
    python_error_msg = db.Column(JSONField)
    submitted_code = db.Column(db.String(560000))
    language = db.Column(db.String(20))
    date = date = db.Column(db.String(19), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    plagiarism_pairs = db.relationship('Plagiarism_pair', secondary=Submission_plagiarismPair_connection, back_populates='submissions')

class Plagiarism_pair(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    leftSubmissionID = db.Column(db.Integer)
    rightSubmissionID = db.Column(db.Integer)
    similarity = db.Column(db.Integer)
    submissions = db.relationship('Submissions', secondary=Submission_plagiarismPair_connection, back_populates='plagiarism_pairs')

class NewGroup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer)
    name = db.Column(db.String(100))
    color = db.Column(db.String(100))
    students = db.Column(JSONField)
    tasks = db.relationship('Task', secondary=task_group_association, back_populates='assigned_groups')

class Messages(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    message = db.Column(db.String(700))
    date = db.Column(db.String(19), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    seen = db.Column(db.Boolean, default=False)
    submission_id = db.Column(db.Integer, db.ForeignKey('submissions.id'))
    submission = relationship('Submissions', backref='messages')
    user = relationship('User', backref='messages')

class CodeComment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    submission_id = db.Column(db.Integer, db.ForeignKey('submissions.id'))
    startRow = db.Column(db.Integer)
    startCol = db.Column(db.Integer)
    endRow = db.Column(db.Integer)
    endCol = db.Column(db.Integer)
    comment = db.Column(db.String(650))
    date = Column(DateTime, default=lambda: datetime.now())
    submission = relationship('Submissions', backref='CodeComment')  
    user = relationship('User', backref='CodeComment')

class GlobalMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_role = db.Column(db.String(20), default='GENERAL')
    school_id = db.Column(db.Integer)
    message = db.Column(db.String(700))
    expiration_date = db.Column(DateTime)
    seen = db.Column(JSONField)

class Backups(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    backup_type = db.Column(db.String(20)) # database_backup or files_backup
    file_id = db.Column(db.String(100), default="-")
    status_msg = db.Column(db.String(100))
    download_url = db.Column(db.String(1000), default="-")
    date = db.Column(db.String(19), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

class Tag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer)
    name = db.Column(db.String(100))
    colour = db.Column(db.String(100))
    tasks = db.relationship('Task', secondary=Task_tag_connection, back_populates='tags')

class CompetitiveTaskResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    status = db.Column(db.String(20), default="participating") ## participating, participated
    start_date = db.Column(db.String(19), default=lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    end_date = db.Column(db.String(19), default="-")
    best_submission_id = db.Column(db.Integer, db.ForeignKey('submissions.id'), nullable=True)
    attempts = db.Column(db.Integer, default=0)
    score = db.Column(db.Integer, default=0)
    rank = db.Column(db.Integer, default=-1)

class Contest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    school_id = db.Column(db.Integer)
    name = db.Column(db.String(100))
    openingDate = db.Column(DateTime)
    closingDate = db.Column(DateTime)
    tasks = db.Column(JSONField)