from email.message import EmailMessage
from email.mime.text import MIMEText
from celery import shared_task
from jinja2 import Template
import smtplib
import imghdr
import shutil
from datetime import datetime, timedelta
from premailer import transform

### Import database ###
from . import db
from .models import User, Submissions, Password_reset_request, Problems, Messages, School, CompetitiveTaskResult, Task

### Email config ###
EMAIL_ADDRESS = 'programavimoplatforma@gmail.com'
EMAIL_PASSWORD = 'qzqnzflshfupcgvu'

### HTML code paths ###
USER_SUBMISSION_HTML_PATH = '/home/ubuntu/WebServer/website/email_templates/user_submission.html'
PASSWORD_RESET_HTML_PATH = '/home/ubuntu/WebServer/website/email_templates/password_reset.html'
NEW_MESSAGE_HTML_PATH = '/home/ubuntu/WebServer/website/email_templates/new_message.html'
COMPETITIVE_TASK_END_PATH = '/home/ubuntu/WebServer/website/email_templates/competitive_task_end.html'
COMPETITIVE_TASK_REMINDER_PATH = '/home/ubuntu/WebServer/website/email_templates/competitive_task_reminder.html'
EMAIL_CODE_VERIFICATION_PATH = '/home/ubuntu/WebServer/website/email_templates/email_code_verification.html'
EMAIL_MSG_PATH = '/home/ubuntu/WebServer/website/email_templates/email_msg.html'

@shared_task(bind=True, queue='email_sender')
def email_user_submission(self, submission_id, teacher_id):

	submission = Submissions.query.get(submission_id)
	user = User.query.get(submission.user_id)
	submission_date = submission.date

	if teacher_id:
		teacher = User.query.get(teacher_id)

	## Patikriname, ar vartotojo paskyra vis dar egzistuoja
	if teacher_id and not teacher:
		return
	if not user:
		return

	## Pasirenkami laiško gavėjai
	if teacher_id:
		contacts = [teacher.email]
	else:
		contacts = [user.email]


	## Sukuriamas laiško turinys
	msg = EmailMessage()
	msg['Subject'] = f'{submission.task.name} ({user.first_last_name})'
	msg['From'] = EMAIL_ADDRESS
	msg['To'] = contacts

	# Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
	with open(USER_SUBMISSION_HTML_PATH, 'r') as html_code:
		html_content = html_code.read()

	data = {
		'user_name': user.first_last_name,
		'submission_date': submission_date,
		'task_name': submission.task.name,
		'score': str(submission.score),
		'test_count': str(submission.task.problems.testCount),
		'submission_id': submission.id
	}

	template = Template(html_content)
	rendered_html = template.render(data)

	msg.add_alternative(rendered_html, subtype='html')

	## Pridedamas vartotojo pateiktas sprendimas
	cpp_attachment = MIMEText(submission.submitted_code, 'plain')

	if submission.language == "c++":
		cpp_attachment.add_header('Content-Disposition', 'attachment', filename=f'{submission.task.name}.cpp')
	else:
		cpp_attachment.add_header('Content-Disposition', 'attachment', filename=f'{submission.task.name}.py')
	
	msg.attach(cpp_attachment)

	## El. laiškas išsiunčiamas gavėjui/gavėjams
	with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
		smtp.ehlo()
		smtp.starttls()
		smtp.ehlo()
		smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
		smtp.send_message(msg)

	return


@shared_task(bind=True, queue='email_sender')
def email_new_message(self, message_id, teacher_id):

	message = Messages.query.get(message_id)
	if teacher_id:
		teacher = User.query.get(teacher_id)

	## Jei sprendimo autorius nebeegzistuoja
	if not teacher_id and not message.submission.user:
		return
	elif teacher_id and not teacher:
		return

	## Jei užduotis nebeegzistuoja
	if not message.submission.task:
		task_name = ""
	else:
		task_name = message.submission.task.name

	## Pasirenkami laiško gavėjai
	if teacher_id:
		contacts = [teacher.email]
	else:
		contacts = [message.submission.user.email]

	## Sukuriamas laiško turinys
	msg = EmailMessage()

	if message.submission.task:
		msg['Subject'] = f'Pridėtas naujas komentaras užduoties „{message.submission.task.name}” sprendimui'
	else:
		msg['Subject'] = f'Pridėtas naujas komentaras'

	msg['From'] = EMAIL_ADDRESS
	msg['To'] = contacts

	# Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
	with open(NEW_MESSAGE_HTML_PATH, 'r') as html_code:
		html_content = html_code.read()

	if teacher_id:
		data = {
			'user_name': teacher.first_last_name,
			'message_date': message.date,
			'submission_date': message.submission.date,
			'task_name': task_name,
			'message': message.message,
			'teachers_name': message.submission.user.first_last_name
		}
	else:
		data = {
			'user_name': message.submission.user.first_last_name,
			'message_date': message.date,
			'submission_date': message.submission.date,
			'task_name': task_name,
			'message': message.message,
			'teachers_name': message.user.first_last_name
		}


	template = Template(html_content)
	rendered_html = template.render(data)

	msg.add_alternative(rendered_html, subtype='html')

	## El. laiškas išsiunčiamas gavėjui/gavėjams
	with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
		smtp.ehlo()
		smtp.starttls()
		smtp.ehlo()
		smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
		smtp.send_message(msg)

	return



@shared_task(bind=True, queue='email_sender')
def email_competitive_task_end(self, user_id, task_id):

    competitive_task_result = CompetitiveTaskResult.query.filter_by(user_id=user_id, task_id=task_id, status="participated").first()
    user = User.query.get(user_id)
    task = Task.query.get(task_id)
    current_time = datetime.now()
    current_time = current_time.strftime("%Y-%m-%d %H:%M:%S")

    if not competitive_task_result or not user or not task:
        return

    ## Pasirenkami laiško gavėjai
    contacts = [user.email]

    ## Sukuriamas laiško turinys
    msg = EmailMessage()
    msg['Subject'] = f'Užduoties „{task.name}” varžybų ataskaita'
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = contacts

    ## Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
    with open(COMPETITIVE_TASK_END_PATH, 'r') as html_code:
        html_content = html_code.read()

    #### Sugeneruojame vartotojo varžybų ataskaitą ####
    competititve_task_report = []

    ## Į varžybų ataskaitą itraukiame varžybų pradžią
    report_data = {
        'action': 'competitive_task_start',
        'score': 0,
        'date': competitive_task_result.start_date
    }
    competititve_task_report.append(report_data)

    ## Į varžybų ataskaitą itraukiame visus vartotojo pateikimus ir papildomų pateikimų bausmes
    user_submissions = Submissions.query.filter_by(task_id=competitive_task_result.task_id, user_id=user.id, plagiarism_pairs=None).all()
    if not user_submissions:
        return
    
    elif len(user_submissions) == 1:

        ## Į ataskaitą įtraukiame vieną ir vienintelį pateikimą
        report_data = {
            'action': 'first_submission',
            'score': user_submissions[0].score,
            'date': user_submissions[0].date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame varžybų uždarymą
        report_data = {
            'action': 'competitive_task_end',
            'score': 0,
            'date': competitive_task_result.end_date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame vartotojo varžybų rezultatą
        report_data = {
            'action': 'competitive_task_result',
            'score': user_submissions[0].score,
            'date': f'{competitive_task_result.score} min.'
        }
        competititve_task_report.append(report_data)

    else:

        ## Į ataskaitą įtraukiame prirmą pateikimą
        report_data = {
            'action': 'first_submission',
            'score': user_submissions[0].score,
            'date': user_submissions[0].date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame papildomus pateikimus
        best_submission_score = 0
        for index, submission in enumerate(user_submissions):

            if index == 0:
                continue

            best_submission_score = max(best_submission_score, submission.score)

            report_data = {
                'action': 'aditional_submission',
                'score': submission.score,
                'date': submission.date
            }
            competititve_task_report.append(report_data)

            report_data = {
                'action': 'aditional_submission_time_penalty',
                'score': 0,
                'date': '+5 minutės'
            }
            competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame varžybų uždarymą
        report_data = {
            'action': 'competitive_task_end',
            'score': 0,
            'date': competitive_task_result.end_date
        }
        competititve_task_report.append(report_data)

        ## Į ataskaitą įtraukiame vartotojo varžybų rezultatą
        report_data = {
            'action': 'competitive_task_result',
            'score': best_submission_score,
            'date': f'{competitive_task_result.score} min.'
        }
        competititve_task_report.append(report_data)


    # Sugeneruojame varžybų ataskaitos laišką
    data = {
        'user_name': user.first_last_name,
        'message_date': current_time,
        'task_name': task.name,
        'task_id': task.id,
        'competititve_task_report': competititve_task_report
    }

    template = Template(html_content)
    rendered_html = template.render(data)
    rendered_html_premailer = transform(rendered_html)
    msg.add_alternative(rendered_html_premailer, subtype='html')

    ## El. laiškas išsiunčiamas gavėjui/gavėjams
    with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
        smtp.ehlo()
        smtp.starttls()
        smtp.ehlo()
        smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        smtp.send_message(msg)

    return



@shared_task(bind=True, queue='email_sender')
def email_competitive_task_reminder(self, competitive_task_result_id):

	competitive_task_result = CompetitiveTaskResult.query.get(competitive_task_result_id)
	defaultDate=datetime(1111, 1, 1, 11, 11, 11)

	if not competitive_task_result or competitive_task_result.status == "participated":
		return

	user = User.query.get(competitive_task_result.user_id)
	task = Task.query.get(competitive_task_result.task_id)

	if not user or not task:
		return

	current_time = datetime.now()
	current_time = current_time.strftime("%Y-%m-%d %H:%M:%S")

	if task.competitiveTaskDuration != -1:

		competititve_task_end = competitive_task_result.start_date + timedelta(minutes=task.competitiveTaskDuration)
		if competititve_task_end <= datetime.now():
			return

		time_difference = competititve_task_end - datetime.now()
		time_difference_minutes = round(time_difference.total_seconds() / 60)

		if time_difference_minutes < 60:
			left_time = f'{time_difference_minutes} minučių'
		else:
			hours = time_difference_minutes // 60
			remaining_minutes = time_difference_minutes % 60
			left_time = f'{hours} valandų ir {remaining_minutes} minučių'

	elif task.openingDate != defaultDate and task.closingDate != defaultDate:

		if task.closingDate <= datetime.now():
			return

		time_difference = task.closingDate - datetime.now()
		time_difference_minutes = round(time_difference.total_seconds() / 60)

		if time_difference_minutes < 60:
			left_time = f'{time_difference_minutes} minučių'
		else:
			hours = time_difference_minutes // 60
			remaining_minutes = time_difference_minutes % 60
			left_time = f'{hours} valandų ir {remaining_minutes} minučių'

	else:
		left_time = '2 dienų'

	## Pasirenkami laiško gavėjai
	contacts = [user.email]

	## Sukuriamas laiško turinys
	msg = EmailMessage()
	msg['Subject'] = f'Priminimas apie užduoties „{task.name}” varžybas'
	msg['From'] = EMAIL_ADDRESS
	msg['To'] = contacts

	## Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
	with open(COMPETITIVE_TASK_REMINDER_PATH, 'r') as html_code:
		html_content = html_code.read()

	data = {
		'user_name': user.first_last_name,
		'current_time': current_time,
		'task_name': task.name,
		'left_time': left_time,
		'task_id': task.id
	}

	template = Template(html_content)
	rendered_html = template.render(data)
	msg.add_alternative(rendered_html, subtype='html')

	## El. laiškas išsiunčiamas gavėjui/gavėjams
	with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
		smtp.ehlo()
		smtp.starttls()
		smtp.ehlo()
		smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
		smtp.send_message(msg)

	return


@shared_task(bind=True, queue='email_sender')
def email_password_reset(self, user_id, reset_request_id):

	user = User.query.get(user_id)
	reset_request = Password_reset_request.query.get(reset_request_id)

	while not user or not reset_request:
		user = User.query.get(user_id)
		reset_request = Password_reset_request.query.get(reset_request_id)

	## Pasirenkami laiško gavėjai
	contacts = [user.email]

	## Sukuriamas laiško turinys
	msg = EmailMessage()
	msg['Subject'] = "Slaptažodžio pakeitimo užklausa"
	msg['From'] = EMAIL_ADDRESS
	msg['To'] = contacts

	# Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
	with open(PASSWORD_RESET_HTML_PATH, 'r') as html_code:
		html_content = html_code.read()

	data = {
		'code': reset_request.code
	}

	template = Template(html_content)
	rendered_html = template.render(data)

	msg.add_alternative(rendered_html, subtype='html')

	## El. laiškas išsiunčiamas gavėjui/gavėjams
	with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
		smtp.ehlo()
		smtp.starttls()
		smtp.ehlo()
		smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
		smtp.send_message(msg)

	return


@shared_task(bind=True, queue='email_sender')
def delete_password_reset_request(self, reset_request_id):

	reset_request = Password_reset_request.query.get(reset_request_id)

	if reset_request:
		try:
			db.session.delete(reset_request)
			db.session.commit()
			return
		except:
			return
	else:
		return


@shared_task(bind=True, queue='delete_problem_celery')
def delete_problem_celery(self, problem_id):

	problem = Problems.query.get(problem_id)

	if problem and problem.visible == False:

		## Ištriname uždavinio testų aplankalą ir aplanke esančius failus
		try:
			shutil.rmtree(f"/home/ubuntu/Testai/{str(problem.id)}")
		except:
			pass

		## Ištriname uždavinį iš databazės
		try:
			db.session.delete(problem)
			db.session.commit()
			return
		except:
			return
	else:
		return


@shared_task(bind=True, queue='email_sender')
def email_verification_code(self, user_id, code, email_subject):

	user = User.query.get(user_id)
	if not user:
		return

	## Pasirenkami laiško gavėjai
	contacts = [user.email]

	## Sukuriamas laiško turinys
	msg = EmailMessage()
	msg['Subject'] = email_subject
	msg['From'] = EMAIL_ADDRESS
	msg['To'] = contacts

	# Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
	with open(EMAIL_CODE_VERIFICATION_PATH, 'r') as html_code:
		html_content = html_code.read()

	current_time = datetime.now()
	current_time = current_time.strftime("%Y-%m-%d %H:%M:%S")

	data = {
		'user_name': user.first_last_name,
		'current_time': current_time,
		'code': code
	}

	template = Template(html_content)
	rendered_html = template.render(data)
	msg.add_alternative(rendered_html, subtype='html')

	## El. laiškas išsiunčiamas gavėjui/gavėjams
	with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
		smtp.ehlo()
		smtp.starttls()
		smtp.ehlo()
		smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
		smtp.send_message(msg)

	return


@shared_task(bind=True, queue='email_sender')
def email_msg(self, userName, email, subject, message):

	## Pasirenkami laiško gavėjai
	contacts = [email]

	## Sukuriamas laiško turinys
	msg = EmailMessage()
	msg['Subject'] = subject
	msg['From'] = EMAIL_ADDRESS
	msg['To'] = contacts

	# Nuskaitomas laiško HTML kodas bei pridedamas prie laiško
	with open(EMAIL_MSG_PATH, 'r') as html_code:
		html_content = html_code.read()

	current_time = datetime.now()
	current_time = current_time.strftime("%Y-%m-%d %H:%M:%S")

	data = {
		'user_name': userName,
		'current_time': current_time,
		'message': message
	}

	template = Template(html_content)
	rendered_html = template.render(data)
	msg.add_alternative(rendered_html, subtype='html')

	## El. laiškas išsiunčiamas gavėjui/gavėjams
	with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
		smtp.ehlo()
		smtp.starttls()
		smtp.ehlo()
		smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
		smtp.send_message(msg)

	return