from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for, Response
from flask_login import login_required, current_user, logout_user
from .models import Task, Problems, User, School, Submissions, NewGroup, School_waiting_list, Messages, User_class, Tag, CompetitiveTaskResult, ProblemCategory, CompetitiveTaskCopy, Contest, CodeComment, User_settings, Password_reset_request, Profiles_delete_request
from .competitive_task_queue import end_competitive_task, end_all_competitive_task_results
from .ranking import competitive_task_ranking
from datetime import datetime, timedelta
from . import db
import os
import shutil
import re
import csv
from io import StringIO
from .email_sender import delete_problem_celery, email_competitive_task_end, email_msg, email_verification_code
from celery.result import AsyncResult
import pytz
from sqlalchemy import and_, func, not_, desc, asc, exists, or_, distinct
from sqlalchemy.orm import joinedload
import mimetypes
import magic
import chardet
from itertools import groupby
import uuid
import json
import zipfile
from threading import Thread, Lock
from sqlalchemy.orm.attributes import flag_modified
from .submitted_file_queue import compile_code
from werkzeug.security import check_password_hash
import secrets
import math
from pdf2image import convert_from_path
from PIL import Image
import fitz

### Blueprint config ###
school_admin = Blueprint('school_admin', __name__)
lock = Lock()

defaultDate=datetime(1111, 1, 1, 11, 11, 11)
vilnius_tz = pytz.timezone('Europe/Vilnius')

textchars = bytearray({7,8,9,10,12,13,27} | set(range(0x20, 0x100)) - {0x7f})
is_binary_string = lambda bytes: bool(bytes.translate(None, textchars))

@school_admin.context_processor
def inject_len():
    return dict(len=len)

def user_school_name():
    if current_user.school_id != 0: return School.query.get(current_user.school_id).name
    else: return ''

def is_leap_year(year):
    return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)

def days_in_date_range(start_date, end_date):
    for n in range(int((end_date - start_date).days) + 1):
        yield start_date + timedelta(n)

def user_is_in_the_task_list(task_id, user_id):

    task = Task.query.get(task_id)
    for task_user_id in task.users:
        if int(task_user_id) == user_id: return True
    return False

def user_is_in_the_group_list(group_id, user_id):

    group = NewGroup.query.get(group_id)
    for group_user_id in group.students:
        if int(group_user_id) == user_id: return True
    return False

def check_filename(filename):
    
    pattern = r'^[a-zA-Z0-9_]+\.(txt|in)$'
    if re.match(pattern, filename):
        return True
    else:
        return False

def weeks_in_date_range(start_date, end_date):
    current_date = start_date
    one_week = timedelta(days=7)
    current_date -= timedelta(days=current_date.weekday())
    while current_date <= end_date:
        week_start = current_date
        week_end = current_date + timedelta(days=6)
        if week_end > end_date:
            week_end = end_date
        yield week_start, week_end
        current_date += one_week

def months_in_date_range(start_date, end_date):
    current_date = start_date
    while current_date <= end_date:
        start_of_month = datetime(current_date.year, current_date.month, 1)
        next_month = start_of_month + timedelta(days=32)
        end_of_month = (next_month - timedelta(days=next_month.day))
        yield start_of_month, end_of_month
        current_date = next_month

def years_in_date_range(start_date, end_date):
    current_date = start_date
    while current_date <= end_date:
        start_of_year = datetime(current_date.year, 1, 1)
        end_of_year = datetime(current_date.year, 12, 31)
        if is_leap_year(current_date.year):
            current_date += timedelta(days=366)
        else:
            current_date += timedelta(days=365)
        yield start_of_year, end_of_year

def delete_new_problem_tests(problem_id):

    problem = Problems.query.get(problem_id)

    ## Ištriname uždavinio testų aplankalą ir aplanke esančius failus
    try:
        shutil.rmtree(f"/home/ubuntu/Testai/{str(problem.id)}")
    except:
        pass

    ## Atšaukiame suplanuotą uždavinio panaikinimą
    result = AsyncResult(problem.celery_id)
    if result.status == 'PENDING':
        result.revoke(terminate=True)

    ## Ištriname uždavinį iš databazės
    db.session.delete(problem)
    db.session.commit()

    return

def get_problem_tests_size(problem_id):
    total_size = 0
    for dirpath, _, filenames in os.walk(f"/home/ubuntu/Testai/{str(problem_id)}"):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def sorting_users_by_class(user):
    class_name = user.user_class.name if user.user_class else ""
    parts = ["".join(g) for _, g in groupby(class_name, key=str.isdigit)]
    parts = [int(part) if part.isdigit() else part for part in parts]
    parts = [str(part) for part in parts]
    first_last_name = user.first_last_name.split()
    second_word = first_last_name[1] if len(first_last_name) > 1 else ""
    return (user.user_class is None, parts, second_word)

def sorting_class(user_class):
    class_name = user_class.name if user_class else ""
    parts = ["".join(g) for _, g in groupby(class_name, key=str.isdigit)]
    parts = [int(part) if part.isdigit() else part for part in parts]
    parts = [str(part) for part in parts]
    return (user_class is None, parts)

def getSubmissionScoreByID(submission_id):
    submission = Submissions.query.get(submission_id)
    if submission:
        return submission.score
    else:
        return -1

def generate_unique_filename():
    folder_path = "/home/ubuntu/temp/"
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S%f")
    random_component = str(uuid.uuid4().hex)[:6]
    unique_filename = f"{timestamp}_{random_component}"
    full_path = os.path.join(folder_path, unique_filename)
    return full_path

def task_is_availible(task):
    if task.openingDate != defaultDate and task.closingDate != defaultDate and (task.openingDate <= datetime.now() and task.closingDate > datetime.now()):
        return True
    elif task.openingDate != defaultDate and task.closingDate == defaultDate and (task.openingDate <= datetime.now()):
        return True
    elif task.closingDate != defaultDate and task.openingDate == defaultDate and (task.closingDate > datetime.now()):
        return True
    elif task.openingDate == defaultDate and task.closingDate == defaultDate: return True
    else: return False

def task_authorization(task, user):

    if task and task.school_id == user.school_id and task_is_availible(task) and task.users == []:
        return True
    elif task and task.school_id == user.school_id and task_is_availible(task) and task.users != [] and user_is_in_the_task_list(task.id, user.id):
        return True
    elif task and task.school_id == user.school_id and user.urole == "SCHOOL-ADMIN":
        return True
    else: return False

def check_file(file_path):

    try:
        with open(file_path, 'r') as file:
            file_content = file.read()
            return True
    except:
        return False


def detect_first_page_margins(pdf_path):
    document = fitz.open(pdf_path)
    margin_info = []

    page_num = 0  # Process only the first page
    page = document.load_page(page_num)
    text = page.get_text("dict")

    if not text['blocks']:
        return None

    x_min, y_min, x_max, y_max = float('inf'), float('inf'), float('-inf'), float('-inf')

    for block in text['blocks']:
        for line in block.get('lines', []):
            for span in line.get('spans', []):
                bbox = span['bbox']
                x_min = min(x_min, bbox[0])
                y_min = min(y_min, bbox[1])
                x_max = max(x_max, bbox[2])
                y_max = max(y_max, bbox[3])

    page_width = page.rect.width
    page_height = page.rect.height

    left_margin = x_min
    top_margin = y_min
    right_margin = page_width - x_max
    bottom_margin = page_height - y_max

    margin_info.append({
        'page': page_num + 1,
        'left_margin': left_margin,
        'top_margin': top_margin,
        'right_margin': right_margin,
        'bottom_margin': bottom_margin
    })

    return margin_info


def convert_and_crop_pdf_page(pdf_path, output_image_path, crop_top, crop_bottom, new_height):
    
    # Convert first page of PDF to an image
    pages = convert_from_path(pdf_path, first_page=0, last_page=1)

    if not pages:
        return

    # The first page is the first item in the list
    page_image = pages[0]

    # Get dimensions of the image
    width, height = page_image.size

    # Get page margins
    margins = detect_first_page_margins(pdf_path)

    if margins:
        margin = margins[0]
        left = margin['left_margin']
        top = margin['top_margin']
        right = width - margin['right_margin']
    else:
        left = 0
        top = crop_top
        right = width

    # Crop the image
    cropped_image = page_image.crop((left, top, right, height))
    cropped_image.save(output_image_path)

    # Downscale the image to a width of 100px while maintaining aspect ratio
    new_height = int(cropped_image.height * (100 / cropped_image.width))
    resized_image = cropped_image.resize((100, new_height), Image.LANCZOS)

    # Crop the bottom of the resized image to achieve a height of 75px
    if resized_image.height > 75:
        bottom_crop = resized_image.height - 75
        resized_image = resized_image.crop((0, 0, 100, new_height - bottom_crop))

    # Save the final image
    resized_image.save(output_image_path)




@school_admin.route('/school_admin/new_problem/upload', methods=['POST'])
@login_required
def new_problem_upload():

    if current_user.urole == "SCHOOL-ADMIN":

        file = request.files.get('file')
        problem_id = request.form.get('problem_id')
        file_extension = os.path.splitext(file.filename)[1].lower()

        ## Jei testams priskirtas uždavinys neegzistuoja arba uždaviniui jau įkelti visi reikiami failai
        problem = Problems.query.get(int(problem_id))

        if not problem or problem.visible:
            flash('Testams priskirtas uždavinys neegzistuoja arba tam uždaviniui jau yra įkelti visi reikiami failai.', category='error')
            if problem:
                delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response

        ## Jei viršytas bendras maksimalus uždavinio testų failų dydis
        if get_problem_tests_size(problem.id) > 31457280:
            flash('Bendras visų testų failų dydis turi neviršyti 30mb.', category='error')
            delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response
        elif current_user.school_id == 2 and get_problem_tests_size(problem.id) > 41943040:
            flash('Bendras visų testų failų dydis turi neviršyti 40mb.', category='error')
            delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response

        ## Jei failo tipas yra netinkamas
        if file_extension != ".in" and file_extension != ".sol" and file_extension != ".ch":
            flash('Nepalaikomas testų failo formatas. Prašome pasirinkti .in, .sol arba .ch failus.', category='error')
            delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response

        ## Sukuriame failo path'a
        if file_extension == ".in":
            problem.uploaded_IN_files += 1
            db.session.commit()
            file_path = f'/home/ubuntu/Testai/{str(problem_id)}/{problem.uploaded_IN_files}.in'
        else:
            problem.uploaded_SOL_files += 1
            db.session.commit()
            file_path = f'/home/ubuntu/Testai/{str(problem_id)}/{problem.uploaded_SOL_files}.sol'

        ## Išsaugojame failą
        if not os.path.exists(file_path):
            file.save(file_path)
        else:
            flash('Testų failų pavadinimai turi būti unikalus.', category='error')
            delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response

        ## Patikriname failo tipą
        m = magic.open(magic.MAGIC_MIME)
        m.load()
        file_type = m.file(file_path)
        if not file_type.startswith("text/") and file_type != "application/octet-stream":
            flash('Testų failai privalo būti tekstinio tipo failai.', category='error')
            delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response

        ## Jei testinis failas yra binary tipo
        if is_binary_string(open(file_path, 'rb').read(1024)):

            with open(file_path, 'rb') as binary_file:
                binary_data = binary_file.read()

            ## Bandome automatiškai nustatyti encoding tipą
            result = chardet.detect(binary_data)
            detected_encoding = result['encoding']

            if detected_encoding:

                try:

                    text_data = binary_data.decode(detected_encoding)
                    with open(file_path, 'w', encoding='utf-8') as text_file:
                        text_file.write(text_data)

                    ## Patikriname, ar failo pakeitimas pavyko
                    if is_binary_string(open(file_path, 'rb').read(1024)):
                        flash('Testų failai negali būti dvejetainio tipo failai.', category='error')
                        delete_new_problem_tests(problem.id)
                        response = jsonify()
                        response.status_code = 400
                        return response

                except:

                    flash('Testų failai negali būti dvejetainio tipo failai.', category='error')
                    delete_new_problem_tests(problem.id)
                    response = jsonify()
                    response.status_code = 400
                    return response

            else:
                flash('Testų failai negali būti dvejetainio tipo failai.', category='error')
                delete_new_problem_tests(problem.id)
                response = jsonify()
                response.status_code = 400
                return response


        ## Patikriname, ar failas yra užkoduotas UTF-8 koduote
        try:

            with open(file_path, 'rb') as file:
                file_data = file.read()

            ## Nustatome koduotės tipą
            result = chardet.detect(file_data)
            detected_encoding = result['encoding']

            if detected_encoding and detected_encoding.lower() != "utf-8":

                try:
                    file_data_decoded = file_data.decode(detected_encoding)
                    with open(file_path, 'w', encoding='utf-8') as file_utf_8_encoded:
                        file_utf_8_encoded.write(file_data_decoded)

                except:
                    flash('Nepavyko pakeisti failo koduotės. Failas privalo būti užkoduotas UTF-8 koduote.', category='error')
                    delete_new_problem_tests(problem.id)
                    response = jsonify()
                    response.status_code = 400
                    return response

            elif not detected_encoding:
                flash('Failo koduotės patikrinimas nepavyko. Failas privalo būti užkoduotas UTF-8 koduote.', category='error')
                delete_new_problem_tests(problem.id)
                response = jsonify()
                response.status_code = 400
                return response

        except:
            flash('Failo koduotės patikrinimas nepavyko. Failas privalo būti užkoduotas UTF-8 koduote.', category='error')
            delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response


        ## Patikriname, ar failo turinys yra tinkamas platformos funckijoms
        if not check_file(file_path):
            flash(f'Failas "{file.filename}" yra netinkamas platformai.', category='error')
            delete_new_problem_tests(problem.id)
            response = jsonify()
            response.status_code = 400
            return response


        ## Jei įkeltas paskutinis failas
        if 2*problem.testCount == problem.uploaded_IN_files+problem.uploaded_SOL_files:

            if problem.uploaded_IN_files == problem.uploaded_SOL_files:

                problem.visible = True
                flash('Naujas uždavinys sukurtas sėkmingai!', category='success')

                ## Atšaukiame suplanuotą uždavinio panaikinimą
                result = AsyncResult(problem.celery_id)
                if result.status == 'PENDING':
                    result.revoke(terminate=True)

            else:
                flash('Uždavinio duomenų ir rezultatų failų skaičius privalo sutapti.', category='error')
                delete_new_problem_tests(problem.id)

            db.session.commit()
            response = jsonify()
            response.status_code = 400
            return response

        return jsonify()



@school_admin.route('/school_admin/new_problem', methods=['GET', 'POST'])
@login_required
def new_problem():

    ## Patikriname, ar neviršytas sukurtų uždavinių limitas
    school = School.query.get(current_user.school_id)
    if current_user.urole == "SCHOOL-ADMIN" and school.created_problems == school.problem_limit and request.method == 'POST':
        flash('Viršytas sukurtų uždavinių limitas.', category='error')
        return redirect(url_for('school_admin.new_problem'))

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        # Reikiama informacija apie uždavinį
        taskName = request.form.get('taskName')
        timeLimit = request.form.get('timeLimit')
        memoryLimit = request.form.get('memoryLimit')
        checkbox_value = request.form.get('order_doesnt_matter')
        ignore_multiple_whitespaces = request.form.get('ignore_multiple_whitespaces')
        input_file_name = request.form.get('input_file_name')
        categoryID = request.form.get('categoryID')
        testCount = int(request.form.get('testCount'))
        pdf_file = request.files['PDF']
        mime_type, encoding = mimetypes.guess_type(pdf_file.filename)

        if timeLimit != "" and (int(timeLimit) > 3 or int(timeLimit) < 1):
            flash('Laiko limitas galimas nuo 1 iki 3 sekundžių.', category='error')
            response = jsonify()
            response.status_code = 400
            return response
        elif memoryLimit != "" and (int(memoryLimit) > 300 or int(memoryLimit) < 10):
            flash('Atminties limitas galimas nuo 10 iki 300 mb.', category='error')
            response = jsonify()
            response.status_code = 400
            return response
        elif len(taskName) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
            response = jsonify()
            response.status_code = 400
            return response
        elif len(taskName) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
            response = jsonify()
            response.status_code = 400
            return response
        elif len(input_file_name) < 1:
            flash('Per trumpas duomenų failo pavadinimas.', category='error')
            response = jsonify()
            response.status_code = 400
            return response
        elif len(input_file_name) > 70:
            flash('Per ilgas duomenų failo pavadinimas.', category='error')
            response = jsonify()
            response.status_code = 400
            return response
        elif check_filename(input_file_name) == False or not (".txt" in input_file_name or ".in" in input_file_name):
            flash('Neteisingas duomenų failo pavadinimas. Palaikomi .txt arba .in formatai. Failo pavadinimą gali sudaryti didžiosios arba mažosios lotyniškos raidės, skaičiai bei apatinio brūkšnio "_" simbolis.', category='error')
            response = jsonify()
            response.status_code = 400
            return response
        else:

            if timeLimit == "":
                timeLimit = 1
            if memoryLimit == "":
                memoryLimit = 64

            if checkbox_value:
                order_doesnt_matter_bool = True
            else:
                order_doesnt_matter_bool = False

            if ignore_multiple_whitespaces:
                ignore_multiple_whitespaces_bool = True
            else:
                ignore_multiple_whitespaces_bool = False

            # Patikriname pasirinktą kategoriją
            if categoryID and categoryID != "":
                selected_category = ProblemCategory.query.get(categoryID)
                if not selected_category or selected_category.school_id != current_user.school_id:
                    flash('Pasirinkta uždavinio kategorija neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
                    response = jsonify()
                    response.status_code = 400
                    return response

            # Patikriname, ar tinkamas PDF formatas
            if pdf_file:
                pdf_extension = os.path.splitext(pdf_file.filename)[1].lower()
                if pdf_extension != ".pdf":
                    flash('Nepalaikomas uždavinio sąlygos failo formatas. Prašome pasirinkti .pdf failą.', category='error')
                    response = jsonify()
                    response.status_code = 400
                    return response
                if mime_type != "application/pdf":
                    flash('Nepalaikomas uždavinio sąlygos failo tipas. Prašome pasirinkti .pdf tipo failą.', category='error')
                    response = jsonify()
                    response.status_code = 400
                    return response

            # Patikriname, ar neviršytas sukurtų testų limitas
            if testCount >= 200:
                flash('Testų failų skaičius privalo būti mažesnis nei 200.', category='error')
                response = jsonify()
                response.status_code = 400
                return response
            elif testCount == 0:
                flash('Privaloma pasirinkti bent vieną testų porą.', category='error')
                response = jsonify()
                response.status_code = 400
                return response
            elif testCount % 2 != 0:
                flash('Pasirinktų testų skaičius privalo būti lyginis', category='error')
                response = jsonify()
                response.status_code = 400
                return response


            # Į databazę įkeliame informaciją apie sukurtą užduotį
            if categoryID and categoryID != "":
                new_problem = Problems(
                    name=taskName,
                    timeLimit=timeLimit,
                    memoryLimit=memoryLimit,
                    testCount=testCount / 2,
                    school_id=current_user.school_id,
                    category_id=selected_category.id,
                    order_doesnt_matter=order_doesnt_matter_bool,
                    ignore_multiple_whitespaces=ignore_multiple_whitespaces_bool,
                    input_file_name=input_file_name
                )
            else:
                new_problem = Problems(
                    name=taskName,
                    timeLimit=timeLimit,
                    memoryLimit=memoryLimit,
                    testCount=testCount / 2,
                    school_id=current_user.school_id,
                    order_doesnt_matter=order_doesnt_matter_bool,
                    ignore_multiple_whitespaces=ignore_multiple_whitespaces_bool,
                    input_file_name=input_file_name
                )
            db.session.add(new_problem)
            db.session.commit()

            # Atnaujiname sukurtų uždavinių skaičių
            school.created_problems = school.created_problems + 1
            db.session.commit()

            # Serveryje išsaugome uždavinio PDF sąlygą
            pdfName = str(new_problem.id) + '.pdf'
            pdf_file.save('/home/ubuntu/PDF_Salygos/' + pdfName)

            # Sukuriame naują aplankalą uždavinio testams
            os.makedirs(f"/home/ubuntu/Testai/{new_problem.id}")

            # Jei per 5 minutes neįkeliami užduoties testai, pašaliname uždavinį bei uždavinio testų aplankalą
            delete_datetime = datetime.now() + timedelta(minutes=5)
            vilnius_dt = vilnius_tz.localize(delete_datetime)
            scheduled_problem_deletion = delete_problem_celery.apply_async(args=(new_problem.id,), eta=vilnius_dt.astimezone(pytz.UTC))

            new_problem.celery_id = scheduled_problem_deletion.id
            db.session.commit()

            # Sukuriame uždavinio viršelį
            pdf_path = f'/home/ubuntu/PDF_Salygos/{new_problem.id}.pdf'
            output_image_path = f'/home/ubuntu/Thumbnails/{new_problem.id}.png'
            convert_and_crop_pdf_page(pdf_path, output_image_path, 100, 700, 85)

            # Jei nauja užduotis sukurta sėkmingai
            return jsonify({"problem_id": new_problem.id})

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':
        categories = ProblemCategory.query.filter_by(school_id=current_user.school_id).all()
        return render_template("new-problem.html", user=current_user, categories=categories, school_name=user_school_name(), pageName="Naujas uždavinys")
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/new_task', methods=['GET', 'POST'])
@login_required
def new_task():

    ## Patikriname, ar neviršytas sukurtų užduočių limitas
    school = School.query.get(current_user.school_id)
    if current_user.urole == "SCHOOL-ADMIN" and school.created_tasks == school.task_limit and request.method == 'POST':
        flash('Viršytas sukurtų užduočių limitas.', category='error')
        return redirect(url_for('school_admin.new_task'))

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        data = request.get_json()
        selected_problem_id = data.get('selectedProblemId')
        selected_contest_id = data.get('selectedContestId')
        taskName = data.get('taskName')
        opening_date_str = data.get('openingDate')
        closing_date_str = data.get('closingDate')
        testing_date_str = data.get('testingDate')
        dont_allow_cancel_submission = data.get('allow_cancel_submission')
        open_test_cases = data.get('openTestCases')
        selected_users = data.get('selectedUsers')
        selected_tags = data.get('selectedTags')
        task_mode = data.get('taskMode')
        competitiveTaskDurationHours = data.get('competitiveTaskDurationHours')
        competitiveTaskDurationMinutes = data.get('competitiveTaskDurationMinutes')
        competitiveTaskDurationConvertedToMinutes = -1


        ## Pagalbinės funkcijos, skirtos nustatyti, ar tam tikra grupė ar klasė yra priskirta užduočiai ##
        def checkIfGroupIsAssigned(group, task):
            for group_user_id in group.students:
                user = User.query.get(group_user_id)
                if not int(group_user_id) in task.users and user and user.school_id != 0:
                    return False
            return True

        def checkIfClassIsAssigned(user_class, task):
            for class_user in user_class.users:
                if not class_user.id in task.users and class_user.school_id != 0:
                    return False
            return True


        if open_test_cases == '': open_test_cases = 0
        else: open_test_cases = int(open_test_cases)

        if dont_allow_cancel_submission:
            allow_cancel_submission_bool = False
        else:
            allow_cancel_submission_bool = True

        if not selected_problem_id:
            return jsonify({'error': 'Būtina pasirinkti uždavinį.'}), 400

        selected_problem = Problems.query.get(selected_problem_id)
        ## Patikriname, ar egzistuoja ieškomas uždavinys ir ar jis priklauso tai pačiai mokyklai
        if not selected_problem or selected_problem.school_id != current_user.school_id:
            return jsonify({'error': 'Ieškomas uždavinys neegzistuoja.'}), 400

        selected_users = list(selected_users)
        selected_users = list(set(selected_users))

        selected_tags = list(selected_tags)
        selected_tags = list(set(selected_tags))

        ## Patikriname užduoties pavadinimą
        if not taskName:
            return jsonify({'error': 'Būtina sukurti užduoties pavadinimą.'}), 400
        if len(taskName) > 50:
            return jsonify({'error': 'Per ilgas užduoties pavadinimas.'}), 400
        if len(taskName) < 1:
            return jsonify({'error': 'Per trumpas užduoties pavadinimas.'}), 400

        ## Patikriname, ar teisingai pasirinkti atvirieji testai
        if open_test_cases != 0 and (open_test_cases < 1 or open_test_cases > selected_problem.testCount):
            return jsonify({'error': 'Neteisingai pasirinkti atvirieji testai.'}), 400

        ## Patikriname, ar teisingai pasirinktos žymės
        task_tags = []
        if selected_tags != []:
            for tag_id in selected_tags:
                tag = Tag.query.get(tag_id)
                task_tags.append(tag)
                if not tag or tag.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasiriktos užduoties žymės.'}), 400

        ## Nustatome užduočiai priskirtas klases ir grupes
        school_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
        school_groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        assigned_classes = []
        assigned_groups = []

        for school_class in school_classes:
            if len(school_class.users) != 0 and checkIfClassIsAssigned(school_class, task) and school_class not in assigned_classes:
                assigned_classes.append(school_class)

        for shcool_group in school_groups:
            if len(shcool_group.students) != 0 and checkIfGroupIsAssigned(shcool_group, task) and shcool_group not in assigned_groups:
                assigned_groups.append(shcool_group)

        #### Jei užduočiai pasirinktas konkurso rėžimas ####
        if task_mode == "contest":

            ## Patikriname pasirinktą konkursą
            selected_contest = Contest.query.get(selected_contest_id)
            if not selected_contest or selected_contest.school_id != current_user.school_id or selected_contest.openingDate < datetime.now():
                return jsonify({'error': 'Pasirinktas konkursas neegzistuoja, nepriklauso jūsų mokyklai arba jau yra prasidėjęs/pasibaigęs.'}), 400

            ## Sukuriama nauja užduotis
            new_task = Task(
                problemsId=selected_problem.id,
                contestID=selected_contest.id,
                name=taskName,
                openingDate=selected_contest.openingDate,
                closingDate=selected_contest.closingDate,
                testingDate=defaultDate,
                school_id=current_user.school_id,
                open_test_cases=open_test_cases,
                users=[],
                tags=task_tags,
                mode=task_mode,
                assigned_classes=assigned_classes,
                assigned_groups=assigned_groups
            )
            db.session.add(new_task)
            db.session.commit()

            ## Surikiuojame visas konkurso užduotis pagal taškų skaičių didėjimo tvarka
            contetsTasks = []
            for contestTaskID in selected_contest.tasks:
                contestTask = Task.query.get(contestTaskID)
                if contestTask and contestTask.school_id == current_user.school_id:
                    contetsTasks.append(contestTask)


            contetsTasks.append(new_task)
            contetsTasks = sorted(contetsTasks, key=lambda task: task.problems.testCount)

            ## Sudaromas užduočių ID sąrašas
            contetsTasksIDS = []
            for contetsTask in contetsTasks:
                contetsTasksIDS.append(contetsTask.id)

            ## Atnaujiname informaciją varžybų duomenų bazėje
            selected_contest.tasks = contetsTasksIDS
            flag_modified(selected_contest, 'tasks')
            db.session.commit()
            flash('Nauja užduotis sukurta sėkmingai!', category='success')
            return jsonify({'success': 'Nauja užduotis sukurta sėkmingai!'}), 200

        ## Patikriname, varžybų trukmė nustatyta kaip skaičius
        if task_mode == "competitive" and competitiveTaskDurationHours:
            try:
                competitiveTaskDurationHours = int(competitiveTaskDurationHours)
            except ValueError:
                return jsonify({'error': 'Užduoties varžybų trukmė privalo būti sveikasis skaičius.'}), 400

        if task_mode == "competitive" and competitiveTaskDurationMinutes:
            try:
                competitiveTaskDurationMinutes = int(competitiveTaskDurationMinutes)
            except ValueError:
                return jsonify({'error': 'Užduoties varžybų trukmė privalo būti sveikasis skaičius.'}), 400

        ## Užduoties varžybų trukmė paverčiama į minutes
        if task_mode == "competitive" and competitiveTaskDurationHours and competitiveTaskDurationMinutes:
            competitiveTaskDurationConvertedToMinutes = competitiveTaskDurationHours*60 + competitiveTaskDurationMinutes
        elif task_mode == "competitive" and competitiveTaskDurationHours:
            competitiveTaskDurationConvertedToMinutes = competitiveTaskDurationHours*60
        elif task_mode == "competitive" and competitiveTaskDurationMinutes:
            competitiveTaskDurationConvertedToMinutes = competitiveTaskDurationMinutes

        ## Patikriname užduoties varžybų trukmę
        if task_mode == "competitive" and competitiveTaskDurationConvertedToMinutes > 44640:
            return jsonify({'error': 'Užduoties varžybų trukmė negali būti ilgesnė nei 31 diena.'}), 400
        elif task_mode == "competitive" and competitiveTaskDurationConvertedToMinutes == 0:
            return jsonify({'error': 'Užduoties varžybų trukmė per trumpa.'}), 400

        ## Patikriname, ar teisingai pasirinkti mokiniai
        if selected_users != []:
            for user_id in selected_users:
                user = User.query.get(user_id)
                if not user or user.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirikti užduoties mokiniai.'}), 400

        ## Nustatome užduoties atidarymo ir uždarymo datas
        if opening_date_str == '': openingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')

        if closing_date_str == '': closingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

        ## Patikriname, ar varžybų rėžimo užduočiai nenustatyta testavimo data
        if task_mode == "competitive" and testing_date_str != '':
            return jsonify({'error': 'Užduočiai, kuriai nustatytas varžybų režimas, negalima testavimo datos funkcija.'}), 400

        ## Nustatome užduoties testavimo datą
        if testing_date_str == '': testingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: testingDate = datetime.strptime(testing_date_str, '%Y-%m-%dT%H:%M')

        ## Patikriname užduoties atidarymo ir uždarymo datas
        if openingDate != defaultDate and closingDate != defaultDate and openingDate >= closingDate:
            return jsonify({'error': 'Užduoties uždarymo data turi būti vėlesnė nei užduoties atidarymo data.'}), 400

        ## Jei užduoties varžybom pasirinktas atidarymo ir uždarymo laikas, varžybų trukmės funkcija negalima
        if task_mode == "competitive" and openingDate != defaultDate and closingDate != defaultDate and competitiveTaskDurationConvertedToMinutes != -1:
            return jsonify({'error': 'Pasirinkus užduoties atidarymo ir uždarymo datas, varžybų trukmė automatiškai nustatoma kaip laiko tarpas tarp užduoties atidarymo ir uždarymo datų, todėl negalima nustatyti varžybų trukmę rankiniu būdu.'}), 400

        ## Sukuriama nauja užduotis
        new_task = Task(
            problemsId=selected_problem.id,
            name=taskName,
            openingDate=openingDate,
            closingDate=closingDate,
            testingDate=testingDate,
            allow_cancel_submission=allow_cancel_submission_bool,
            school_id=current_user.school_id,
            open_test_cases=open_test_cases,
            users=selected_users,
            tags=task_tags,
            mode=task_mode,
            competitiveTaskDuration=competitiveTaskDurationConvertedToMinutes,
            assigned_classes=assigned_classes,
            assigned_groups=assigned_groups
        )
        db.session.add(new_task)
        db.session.commit()

        # Atnaujiname sukurtų užduočių skaičių
        school.created_tasks = school.created_tasks + 1
        db.session.commit()            

        flash('Nauja užduotis sukurta sėkmingai!', category='success')
        return jsonify({'success': 'Nauja užduotis sukurta sėkmingai!'}), 200

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET':

        problems = Problems.query.filter_by(school_id=current_user.school_id).all()
        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        users = User.query.filter_by(school_id=current_user.school_id, urole='GENERAL').all()
        users = sorted(users, key=sorting_users_by_class)
        school_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
        school_classes = sorted(school_classes, key=sorting_class)
        tags = Tag.query.filter_by(school_id=current_user.school_id).all()
        contests = Contest.query.filter(Contest.openingDate > datetime.now())

        all_classes_users = []
        for school_class in school_classes:
            class_users = User.query.filter_by(school_id=current_user.school_id, class_id=school_class.id, urole="GENERAL").all()
            class_users_ids = []
            for user_id in class_users:
                class_users_ids.append(user_id.id)
            all_classes_users.append(class_users_ids)

        return render_template("new-task.html", user=current_user, problems=problems, contests=contests, school_name=user_school_name(), groups=groups, users=users, school_classes=school_classes, all_classes_users=all_classes_users, tags=tags, pageName="Nauja užduotis")

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/problems')
@login_required
def problems():

    page = request.args.get('page', 1, type=int)
    problemID = request.args.get('problemID', None)
    categoryID = request.args.get('categoryID', None, type=int)
    problem_name = request.args.get('problem_name', None)

    if current_user.urole == "SCHOOL-ADMIN":

        problems = Problems.query.filter(Problems.school_id == current_user.school_id)
        problems = problems.order_by(Problems.date.desc())

        ## Jei nustatytas uždavinio filtravimas, filtruojame uždavinius pagal uždavinį
        selected_problem_name = ""
        selected_problem = Problems.query.get(problemID)
        if selected_problem and selected_problem.school_id == current_user.school_id:
            selected_problem_name = selected_problem.name
            problems = problems.filter(Problems.id == selected_problem.id)

        ## Jei nustatytas uždavinio fragmento filtravimas, filtruojame uždavinius pagal uždavinio fragmentą
        if not selected_problem and problem_name:
            problems = problems.filter(Problems.name.ilike(f'%{problem_name}%'))

        ## Jei nustatyta uždavinio kategorija, filtruojame pagal uždavinio kategoriją
        selected_category = ProblemCategory.query.get(categoryID)
        selected_category_name = ""

        if selected_category and selected_category.school_id == current_user.school_id:
            selected_category_name = selected_category.name
            problems = problems.filter(Problems.category_id == selected_category.id)

        try:
            problems = problems.paginate(page=page, per_page=20)
        except:
            return redirect(url_for('school_admin.problems', page=1, problemID=problemID, categoryID=categoryID, problem_name=problem_name))

        all_problems = Problems.query.filter_by(school_id=current_user.school_id).all()
        all_problems = sorted(all_problems, key=lambda problem: datetime.strptime(problem.date, '%Y-%m-%d %H:%M:%S'))
        categories = ProblemCategory.query.filter_by(school_id=current_user.school_id).all()

        return render_template("problems.html", user=current_user, problems=problems, categories=categories, categoryID=categoryID, category_name=selected_category_name, all_problems=all_problems, problemID=problemID, problem_name=problem_name, selected_problem_name=selected_problem_name, page=page, school_name=user_school_name(), pageName="Uždaviniai")
    
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/api/export_problems', methods=['POST'])
@login_required
def export_problems_api():

    data = json.loads(request.data.decode('utf-8'))
    selected_problems = data.get('selectedProblems')

    if current_user.urole == "SCHOOL-ADMIN":

        class SelectedProblem:
            def __init__(self, name, timeLimit, memoryLimit, testCount, order_doesnt_matter, ignore_multiple_whitespaces, input_file_name):
                self.name = name
                self.timeLimit = timeLimit
                self.memoryLimit = memoryLimit
                self.testCount = testCount
                self.order_doesnt_matter = order_doesnt_matter
                self.ignore_multiple_whitespaces = ignore_multiple_whitespaces
                self.input_file_name = input_file_name

        class SelectedProblemEncoder(json.JSONEncoder):
            def default(self, obj):
                if isinstance(obj, SelectedProblem):
                    return obj.__dict__
                return json.JSONEncoder.default(self, obj)

        ## Patikriname, ar pasirinkti norimi eksportuoti uždaviniai
        if not selected_problems or len(selected_problems) == 0:
            return jsonify({'error': '<strong>Klaida:</strong> norint eksportuoti uždavinius, būtina pasirinkti bent vieną uždavinį.'}), 400

        ## Patikriname pasirinktus eksportuoti uždavinius
        selectedProblems = []
        selectedProblemsData = []

        for selected_problem_id in selected_problems:
            selected_problem = Problems.query.get(selected_problem_id)
            if not selected_problem or selected_problem.school_id != current_user.school_id:
                return jsonify({'error': '<strong>Klaida:</strong> pasirinktas uždavinys neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400
            selectedProblems.append(selected_problem)
            selectedProblemData = SelectedProblem(selected_problem.name, selected_problem.timeLimit, selected_problem.memoryLimit, selected_problem.testCount, selected_problem.order_doesnt_matter, selected_problem.ignore_multiple_whitespaces, selected_problem.input_file_name)
            selectedProblemsData.append(selectedProblemData)

        ## Pagalbinė funkcija - laikinojo aplanko ištrynimas
        def delete_temp_dir(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                return
            except:
                return

        ## Uždavinių salygos failai perkeliami į laikinąjį aplanką
        temp_dir = generate_unique_filename()
        os.makedirs(temp_dir, exist_ok=True)

        for index, problem in enumerate(selectedProblems):
            src_file = f"/home/ubuntu/PDF_Salygos/{problem.id}.pdf"
            dest_file = f"{temp_dir}/{index}.pdf"
            if os.path.exists(src_file):
                shutil.copy(src_file, dest_file)
            else:
                delete_temp_dir(temp_dir)
                return jsonify({'error': f'<strong>Klaida:</strong> serveryje nerasta uždavinio "{problem.name}" sąlyga, todėl nebuvo galima eksportuoti pasirinktų uždavinių. Pabandykite atžymėti šį uždavinį ir bandyti per naujo.'}), 400


        ## Uždaviniu testai perkeliami į laikinąjį aplankalą
        for index, problem in enumerate(selectedProblems):
            src_folder = f"/home/ubuntu/Testai/{problem.id}"
            dest_folder = f"{temp_dir}/{index}"
            try:
                shutil.copytree(src_folder, dest_folder)
            except:
                delete_temp_dir(temp_dir)
                return jsonify({'error': f'<strong>Klaida:</strong> nepavyko eksportuoti uždavinio "{problem.name}" testų failų, todėl uždavinių eksportavimas buvo nutrauktas.'}), 400

        ## Išsaugoma informacija apie eksportuojamus uždavinius
        json_data = json.dumps(selectedProblemsData, cls=SelectedProblemEncoder)
        with open(f'{temp_dir}/data.json', 'w') as f:
            f.write(json_data)

        ## Eksportuojami uždaviniai suarchyvuojami į vieną failą
        with zipfile.ZipFile(f'{temp_dir}.zip', 'w') as zipf:
            for root, _, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    zipf.write(file_path, os.path.relpath(file_path, temp_dir))

        ## Laikinasis aplankalas ištrinamas
        delete_temp_dir(temp_dir)

        ## Eksportuoti uždaviniai išsiunčiami vartotojui
        response = send_file(f'{temp_dir}.zip', as_attachment=True)
        os.remove(f'{temp_dir}.zip')
        return response
    
    else:
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400



@school_admin.route('/school_admin/api/import_problems', methods=['POST'])
@login_required
def import_problems_api():

    fileId = request.form['fileId']
    currentChunk = request.form['currentChunk']
    totalChunks = request.form['totalChunks']

    if current_user.urole == "SCHOOL-ADMIN":

        ## Strukturos, skirtos saugoti pasirinktiems uždaviniams
        class SelectedProblem:
            def __init__(self, name, timeLimit, memoryLimit, testCount, order_doesnt_matter, ignore_multiple_whitespaces, input_file_name):
                self.name = name
                self.timeLimit = timeLimit
                self.memoryLimit = memoryLimit
                self.testCount = testCount
                self.order_doesnt_matter = order_doesnt_matter
                self.ignore_multiple_whitespaces = ignore_multiple_whitespaces
                self.input_file_name = input_file_name

        class SelectedProblemDecoder(json.JSONDecoder):
            def decode(self, s):
                decoded = super().decode(s)
                return [SelectedProblem(**item) for item in decoded]

        ## Pagalbinė funckija, skirta ištrinti laikinąjį failą
        def delete_temp_file(temp_file):
            try:
                os.remove(temp_file)
                return
            except:
                return

        ## Pagalbinė funkcija, skirta ištrinti laikinąjį aplanką
        def delete_temp_dir(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                return
            except:
                return

        ## Pagalbinė funkcija, skirta apskaičiuoti failo dydį
        def get_folder_size(folder_path):
            total_size = 0
            for dirpath, _, filenames in os.walk(folder_path):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    total_size += os.path.getsize(filepath)
            return total_size

        ## Reikiamus dydžius paverčiame į skaičius
        try:
            currentChunk = int(currentChunk)
        except ValueError:
            return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių paketo (neteisingai nurodytas dalies ID)'}), 400

        try:
            totalChunks = int(totalChunks)
        except ValueError:
            return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių paketo (neteisingai nurodytas dalių skaičius)'}), 400

        ## Gauname pridėto failo dalį
        if currentChunk != -1:
            chunk = request.files['chunk']

        ## Jei failas yra pabaigtas kelti
        if currentChunk == -1:

            ## Randame laikinąjį failą
            temp_file_path = f"/home/ubuntu/temp/{fileId}.zip"
            if not os.path.exists(temp_file_path):
                return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių paketo.'}), 400

            ## Patikriname pasirinktą kategoriją
            categoryID = request.form['categoryID']
            if categoryID:
                selected_category = ProblemCategory.query.get(categoryID)
                if not selected_category or selected_category.school_id != current_user.school_id:
                    delete_temp_file(temp_file_path)
                    return jsonify({'error': '<strong>Klaida:</strong> pasirinkta uždavinių kategorija neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400

            ## Sukuriame laikinąjį aplanką, kuriame išskleisime įkeltus uždavinius
            temp_dir = f"/home/ubuntu/temp/{fileId}"
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)

            ## Iškleidžiame įkeltą uždavinių archyvą
            try:
                with zipfile.ZipFile(temp_file_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
            except:
                delete_temp_file(temp_file_path)
                delete_temp_dir(temp_dir)
                return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių iš pateikto uždavinių paketo. Įsitikinkite, kad užduočių paketas nėra sugadintas.'}), 400

            ## Pašaliname laikinąjį failą
            delete_temp_file(temp_file_path)

            ## Iš duomenų failo ištraukiame duomenis apie uždavinius
            if os.path.exists(f"/home/ubuntu/temp/{fileId}/data.json"):

                ## Nuskaitome duomenis
                try:
                    with open(f"/home/ubuntu/temp/{fileId}/data.json", "r") as file:
                        json_data = file.read()
                    selectedProblemsData = json.loads(json_data, cls=SelectedProblemDecoder)
                except:
                    delete_temp_dir(temp_dir)
                    return jsonify({'error': '<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (nepavyko nuskaityti duomenų failo)'}), 400
                
                ## Patikriname išsaugotus uždavinių duomenis
                for problem in selectedProblemsData:

                    try:

                        ## Patikrinamas uždavinio pavadinimas
                        if len(problem.name) < 1 or len(problem.name) > 50:
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio pavadinimo ilgis)'}), 400

                        ## Patikrinamas laiko limitas
                        if int(problem.timeLimit) > 3 or int(problem.timeLimit) < 1:
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio laiko limitas)'}), 400

                        ## Patikrinamas atminties limitas
                        if int(problem.memoryLimit) > 300 or int(problem.memoryLimit) < 10:
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio atminties ilgis)'}), 400

                        ## Patikrinamas duomenų failo pavadinimas
                        if len(problem.input_file_name) < 1 or len(problem.input_file_name) > 70:
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio duomenų failo pavadinimas)'}), 400
                        if check_filename(problem.input_file_name) == False or not (".txt" in problem.input_file_name or ".in" in problem.input_file_name):
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio duomenų failo pavadinimas)'}), 400

                        if problem.testCount > 100 or problem.testCount == 0:
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio testų skaičius)'}), 400

                        ## Patikrinami uždavinio nustatymai
                        if not isinstance(problem.order_doesnt_matter, bool) or not isinstance(problem.ignore_multiple_whitespaces, bool):
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkami uždavinio nustatymai)'}), 400

                    except:
                        delete_temp_dir(temp_dir)
                        return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas.'}), 400

                ## Patikriname kiekvieno uždavinio saugomus failus
                for index, problem in enumerate(selectedProblemsData):

                    ## Patikriname, ar egzistuoja uždavinio sąlygos failas
                    if not os.path.exists(f"/home/ubuntu/temp/{fileId}/{index}.pdf"):
                        delete_temp_dir(temp_dir)
                        return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (nerastas uždavinio "{problem.name}" sąlygos failas)'}), 400

                    ## Patikriname testų dydžius
                    if get_folder_size(f"/home/ubuntu/temp/{fileId}/{index}") > 31457280:
                        delete_temp_dir(temp_dir)
                        return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (uždavinio "{problem.name}" bendras visų testų dydis yra per didelis)'}), 400

                    ## Patikriname, ar egzistuoja visi uždavinio testai bei ar jie tinkami platformai
                    for testCase in range(1, problem.testCount+1):

                        ## Patikriname, ar testai egzistuoja
                        if not os.path.exists(f"/home/ubuntu/temp/{fileId}/{index}/{testCase}.in"):
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (nerastas uždavinio "{problem.name}" duomenų failas)'}), 400
                        if not os.path.exists(f"/home/ubuntu/temp/{fileId}/{index}/{testCase}.sol"):
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (nerastas uždavinio "{problem.name}" rezultatų failas)'}), 400

                        ## Patikriname failų tipus
                        m = magic.open(magic.MAGIC_MIME)
                        m.load()

                        file_type_in = m.file(f"/home/ubuntu/temp/{fileId}/{index}/{testCase}.in")
                        if not file_type_in.startswith("text/") and file_type_in != "application/octet-stream":
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio "{problem.name}" testo failo tipas)'}), 400

                        file_type_sol = m.file(f"/home/ubuntu/temp/{fileId}/{index}/{testCase}.sol")
                        if not file_type_sol.startswith("text/") and file_type_sol != "application/octet-stream":
                            delete_temp_dir(temp_dir)
                            return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkamas uždavinio "{problem.name}" testo failo tipas)'}), 400

                        ## Patikriname failų koduotes
                        for testCaseIndex in range(1, 3):
                            try:

                                if testCaseIndex == 1:
                                    file_path = f"/home/ubuntu/temp/{fileId}/{index}/{testCase}.in"
                                else:
                                    file_path = f"/home/ubuntu/temp/{fileId}/{index}/{testCase}.sol"

                                with open(file_path, 'rb') as file:
                                    file_data = file.read()

                                ## Nustatome koduotės tipą
                                result = chardet.detect(file_data)
                                detected_encoding = result['encoding']

                                if detected_encoding and detected_encoding.lower() != "utf-8":
                                    try:
                                        file_data_decoded = file_data.decode(detected_encoding)
                                        with open(file_path, 'w', encoding='utf-8') as file_utf_8_encoded:
                                            file_utf_8_encoded.write(file_data_decoded)
                                    except Exception as e:
                                        delete_temp_dir(temp_dir)
                                        return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkama uždavinio "{problem.name}" testo failo koduotė)'}), 400
                                elif not detected_encoding:
                                    delete_temp_dir(temp_dir)
                                    return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkama uždavinio "{problem.name}" testo failo koduotė)'}), 400

                            except:
                                delete_temp_dir(temp_dir)
                                return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (netinkama uždavinio "{problem.name}" testo failo koduotė)'}), 400

                            ## Patikriname, ar failo turinys yra tinkamas platformos funckijoms
                            if not check_file(file_path):
                                delete_temp_dir(temp_dir)
                                return jsonify({'error': f'<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (sugadintas uždavinio "{problem.name}" testo failas)'}), 400

                ## Sukuriami nauji uždaviniai
                for index, problem in enumerate(selectedProblemsData):

                    if categoryID:
                        new_problem = Problems(
                            name=problem.name,
                            timeLimit=problem.timeLimit,
                            memoryLimit=problem.memoryLimit,
                            testCount=problem.testCount,
                            school_id=current_user.school_id,
                            order_doesnt_matter=problem.order_doesnt_matter,
                            ignore_multiple_whitespaces=problem.ignore_multiple_whitespaces,
                            input_file_name=problem.input_file_name,
                            category_id = int(categoryID),
                            visible=True
                        )
                    else:
                        new_problem = Problems(
                            name=problem.name,
                            timeLimit=problem.timeLimit,
                            memoryLimit=problem.memoryLimit,
                            testCount=problem.testCount,
                            school_id=current_user.school_id,
                            order_doesnt_matter=problem.order_doesnt_matter,
                            ignore_multiple_whitespaces=problem.ignore_multiple_whitespaces,
                            input_file_name=problem.input_file_name,
                            visible=True
                        )
                    db.session.add(new_problem)
                    db.session.commit()

                    ## Įkeliamas uždavinio sąlygos failas
                    try:
                        shutil.copyfile(f"/home/ubuntu/temp/{fileId}/{index}.pdf", f"/home/ubuntu/PDF_Salygos/{new_problem.id}.pdf")
                    except:
                        delete_temp_dir(temp_dir)
                        return jsonify({'error': f'<strong>Klaida:</strong> nepavyko importuoti uždavinių iš pateikto uždavinių paketo.'}), 400

                    ## Perkeliami uždavinio testų failai
                    os.makedirs(f"/home/ubuntu/Testai/{new_problem.id}")
                    for testCaseID in range(1, problem.testCount+1):
                        shutil.copyfile(f"/home/ubuntu/temp/{fileId}/{index}/{testCaseID}.in", f"/home/ubuntu/Testai/{new_problem.id}/{testCaseID}.in")
                        shutil.copyfile(f"/home/ubuntu/temp/{fileId}/{index}/{testCaseID}.sol", f"/home/ubuntu/Testai/{new_problem.id}/{testCaseID}.sol")

                ## Jei nauji uždaviniai sėkmingai įkelti į platformą:
                delete_temp_dir(temp_dir)
                return jsonify({'success': 'Nauji uždaviniai buvo sėkmingai įkelti į platformą.'}), 200

            else:
                delete_temp_dir(temp_dir)
                return jsonify({'error': '<strong>Klaida:</strong> įkeltas uždavinių paketas yra sugadintas, todėl uždavinių importavimas buvo sustabdytas (nerastas duomenų failas)'}), 400


        ## Patikriname, ar reikiama informacija nurodyta teisingai
        if currentChunk-1 > totalChunks:
            delete_temp_file(f"/home/ubuntu/temp/{fileId}.zip")
            return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių paketo (neteisingai nurodyta reikiama informacija)'}), 400

        ## Jei failas jau pradėtas kelti
        if fileId and currentChunk != 1:

            ## Randame laikinąjį failą
            temp_file_path = f"/home/ubuntu/temp/{fileId}.zip"
            if not os.path.exists(temp_file_path):
                return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių paketo.'}), 400

            ## Patikriname, ar neviršijamas failo dydžio limitas
            if os.path.getsize(temp_file_path) > 1073741824:
                delete_temp_file(temp_file_path)
                return jsonify({'error': '<strong>Klaida:</strong> įkeliamas uždavinių paketas viršijo leistiną 1GB failo dydį.'}), 400

            ## Išsaugome dalinį failą
            try:
                with open(temp_file_path, 'ab') as f:
                    chunk.save(f)
            except:
                delete_temp_file(temp_file_path)
                return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių paketo.'}), 400

            ## Gražiname failo id
            return jsonify({'fileId': fileId}), 200

        ## Jei įkeliama failo pirmoji dalis
        elif currentChunk == 1:

            ## Sugeneruojama naujo failo path'as
            temp_file_path = f"{generate_unique_filename()}.zip"

            ## Gaunamas failo ID
            parts = temp_file_path.split('/')
            filename = parts[-1]
            fileID = filename.split('.')[0]

            ## Išsaugome dalinį failą
            try:
                with open(temp_file_path, 'wb') as f:
                    chunk.save(f)
            except:
                delete_temp_file(temp_file_path)
                return jsonify({'error': '<strong>Klaida:</strong> nepavyko įkelti uždavinių paketo.'}), 400

            ## Patikriname, ar neviršijamas failo dydžio limitas
            if os.path.getsize(temp_file_path) > 1073741824:
                delete_temp_file(temp_file_path)
                return jsonify({'error': '<strong>Klaida:</strong> įkeliamas uždavinių paketas viršijo leistiną 1GB failo dydį.'}), 400

            ## Gražiname failo id
            return jsonify({'fileId': fileID}), 200
    
    else:
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400



@school_admin.route('/school_admin/problems/<problem_id>', methods=['GET', 'POST'])
@login_required
def edit_problem(problem_id):

    problem = Problems.query.get(problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST' and problem and problem.school_id == current_user.school_id and problem.visible:
        
        problemName = request.form.get('problemName')
        timeLimit = request.form.get('timeLimit')
        memoryLimit = request.form.get('memoryLimit')
        pdf_file = request.files.get('PDF')
        test_files = request.files.getlist('tests')
        checkbox_value = request.form.get('order_doesnt_matter')
        ignore_multiple_whitespaces = request.form.get('ignore_multiple_whitespaces')
        input_file_name = request.form.get('input_file_name')
        categoryID = request.form.get('selectedCategoryId')

        if timeLimit != "" and (int(timeLimit) > 3 or int(timeLimit) < 1):
            flash('Laiko limitas galimas iki 3 sekundžių.', category='error')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))
        elif memoryLimit != "" and (int(memoryLimit) > 300 or int(memoryLimit) < 10):
            flash('Atminties limitas galimas nuo 10 iki 300 mb.', category='error')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))
        elif len(problemName) > 50:
            flash('Per ilgas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))
        elif len(problemName) < 1:
            flash('Per trumpas uždavinio pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))
        elif len(input_file_name) < 1:
            flash('Per trumpas duomenų failo pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))
        elif len(input_file_name) > 70:
            flash('Per ilgas duomenų failo pavadinimas.', category='error')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))
        elif check_filename(input_file_name) == False or not (".txt" in input_file_name or ".in" in input_file_name):
            flash('Neteisingas duomenų failo pavadinimas. Palaikomi .txt arba .in formatai. Failo pavadinimą gali sudaryti didžiosios arba mažosios lotyniškos raidės, skaičiai bei apatinio brūkšnio "_" simbolis.', category='error')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))
        else:

            if timeLimit == "":
                timeLimit = 1
            if memoryLimit == "":
                memoryLimit = 64

            if checkbox_value:
                order_doesnt_matter_bool = True
            else:
                order_doesnt_matter_bool = False

            if ignore_multiple_whitespaces:
                ignore_multiple_whitespaces_bool = True
            else:
                ignore_multiple_whitespaces_bool = False

            ## Patikriname pasirinktą kategoriją
            if categoryID:
                selected_category = ProblemCategory.query.get(categoryID)
                if not selected_category or selected_category.school_id != current_user.school_id:
                    flash('Pasirinkta uždavinio kategorija neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
                    return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

            ## Patikriname, ar nėra sprendimų, kurie naudotų užduotis, kurios susietos su šiuo uždaviniu
            tasks_with_editing_problem = Task.query.filter_by(problemsId=problem.id).all()
            for task in tasks_with_editing_problem:
                task_submissions = Submissions.query.filter_by(task_id=task.id, status=0).first()
                if task_submissions:
                    flash(f'Šis uždavinys yra naudojamas užduotyje {task.name}, kurios sprendimas yra šiuo metu testuojamas, todėl uždavinio redaguoti šiuo metu negalima.', category='error')
                    return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

            ## Patikriname, ar uždavinio sąlygos failo formatas yra tinkamas
            if pdf_file:
                pdf_extension = os.path.splitext(pdf_file.filename)[1].lower()
                if pdf_extension != ".pdf":
                    flash('Nepalaikomas uždavinio sąlygos failo formatas. Prašome pasirinkti .pdf failą.', category='error')
                    return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

            ## Atnaujiname serveryje išsaugotą uždavinio PDF sąlygą
            if pdf_file:

                pdfName = str(problem.id) + '.pdf'
                if os.path.exists('/home/ubuntu/PDF_Salygos/' + pdfName):
                    os.remove('/home/ubuntu/PDF_Salygos/' + pdfName)

                pdf_file.save('/home/ubuntu/PDF_Salygos/' + pdfName)


            ## Patikriname bei pridedame naujus uždavinio testus
            test_files = [file for file in test_files if file.filename]
            if len(test_files) != 0:

                # Patikriname testų formatus
                IN_FILES = 0
                SOL_FILES = 0

                for test_file in test_files:

                    test_extension = os.path.splitext(test_file.filename)[1].lower()
                    if test_extension in [".in"]:
                        IN_FILES += 1
                    elif test_extension in [".sol"]:
                        SOL_FILES += 1
                    elif test_extension in [".ch"]:
                        SOL_FILES += 1
                    else:
                        flash('Nepalaikomas testų failo formatas. Prašome pasirinkti .in .sol arba .ch failus.', category='error')
                        return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                # Patikriname, ar duomenų ir rezultatų failų skaičius lygus
                if IN_FILES != SOL_FILES:
                    flash('Duomenų ir rezultatų failų skaičius turi būti lygus.', category='error')
                    return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                # Patikriname, ar neviršytas sukurtų testų limitas
                if len(test_files)+problem.testCount >= 200:
                    flash('Visų testų failų skaičius privalo būti mažesnis nei 200.', category='error')
                    return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                ## Pagalbinė funkcija, skirta įkeltų papildomų testų ištrynimui
                def delete_new_tests(test_case_id_IN, test_case_id_SOL):

                    test_case_id_IN -= 1
                    test_case_id_SOL -= 1

                    ## Ištriname naujai sukurtus uždavinio duomenų failus
                    while test_case_id_IN != problem.testCount:
                        test_case_name = str(test_case_id_IN) + '.in'
                        file_path = os.path.join('/home/ubuntu/Testai/', str(problem.id), test_case_name)
                        try:
                            os.remove(file_path)
                        except:
                            pass
                        test_case_id_IN -= 1

                    ## Ištriname naujai sukurtus uždavinio rezultatų failus
                    while test_case_id_SOL != problem.testCount:
                        test_case_name = str(test_case_id_SOL) + '.sol'
                        file_path = os.path.join('/home/ubuntu/Testai/', str(problem.id), test_case_name)
                        try:
                            os.remove(file_path)
                        except:
                            pass
                        test_case_id_SOL -= 1

                    return

                # Serveryje išsaugome uždavinio testus
                test_case_id_IN = problem.testCount + 1
                test_case_id_SOL = problem.testCount + 1
                for test_file in test_files:

                    file_extension = os.path.splitext(test_file.filename)[1]

                    ## Išsaugojame naują uždavinio testą
                    if file_extension == ".in":
                        test_case_name = str(test_case_id_IN) + '.in'
                        file_path = os.path.join('/home/ubuntu/Testai/', str(problem.id), test_case_name)
                        test_file.save(file_path)
                        test_case_id_IN += 1
                    else:
                        test_case_name = str(test_case_id_SOL) + '.sol'
                        file_path = os.path.join('/home/ubuntu/Testai/', str(problem.id), test_case_name)
                        test_file.save(file_path)
                        test_case_id_SOL += 1

                    ## Patikriname failo tipą
                    m = magic.open(magic.MAGIC_MIME)
                    m.load()
                    file_type = m.file(file_path)
                    if not file_type.startswith("text/") and file_type != "application/octet-stream":
                        delete_new_tests(test_case_id_IN, test_case_id_SOL)
                        flash('Testų failai privalo būti tekstinio tipo failai.', category='error')
                        return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                    ## Patikriname, ar failas yra užkoduotas UTF-8 koduote
                    try:

                        with open(file_path, 'rb') as file:
                            file_data = file.read()

                        ## Nustatome koduotės tipą
                        result = chardet.detect(file_data)
                        detected_encoding = result['encoding']

                        if detected_encoding and detected_encoding.lower() != "utf-8":

                            try:
                                file_data_decoded = file_data.decode(detected_encoding)
                                with open(file_path, 'w', encoding='utf-8') as file_utf_8_encoded:
                                    file_utf_8_encoded.write(file_data_decoded)

                            except:
                                delete_new_tests(test_case_id_IN, test_case_id_SOL)
                                flash('Nepavyko pakeisti failo koduotės. Failas privalo būti užkoduotas UTF-8 koduote.', category='error')
                                return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                        elif not detected_encoding:
                            delete_new_tests(test_case_id_IN, test_case_id_SOL)
                            flash('Failo koduotės patikrinimas nepavyko. Failas privalo būti užkoduotas UTF-8 koduote.', category='error')
                            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                    except:
                        delete_new_tests(test_case_id_IN, test_case_id_SOL)
                        flash('Failo koduotės patikrinimas nepavyko. Failas privalo būti užkoduotas UTF-8 koduote.', category='error')
                        return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                    ## Patikriname, ar failo turinys yra tinkamas platformos funckijoms
                    if not check_file(file_path):
                        delete_new_tests(test_case_id_IN, test_case_id_SOL)
                        flash(f'Failas "{file.filename}" yra netinkamas platformai.', category='error')
                        return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

                # Atnaujiname testų informaciją databazėje
                problem.testCount = problem.testCount + len(test_files) / 2

            ## Atnaujiname informaciją apie uždavinį
            problem.name=problemName
            problem.timeLimit=timeLimit
            problem.memoryLimit=memoryLimit
            problem.order_doesnt_matter=order_doesnt_matter_bool
            problem.ignore_multiple_whitespaces=ignore_multiple_whitespaces_bool
            problem.input_file_name=input_file_name
            if categoryID:
                problem.category_id = categoryID
            db.session.commit()

            flash('Uždavinys sėkmingai atnaujintas.', category='success')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))            

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET' and problem and problem.school_id == current_user.school_id:
        categories = ProblemCategory.query.filter_by(school_id=current_user.school_id).all()
        return render_template("edit_problem.html", user=current_user, problem=problem, categories=categories, school_name=user_school_name())
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_problem/<problem_id>', methods=['POST'])
@login_required
def delete_problem(problem_id):

    lock.acquire()
    delete_problem = Problems.query.get(problem_id)
    delete_problem_task = Task.query.filter_by(problemsId=delete_problem.id).first()

    if current_user.urole == "SCHOOL-ADMIN" and delete_problem and delete_problem_task:
        lock.release()
        return jsonify({'error': f'Šis uždavinys yra naudojamas užduotyje „{delete_problem_task.name}“, todėl uždavinio ištrinti negalima.'}), 400

    elif current_user.urole == "SCHOOL-ADMIN" and delete_problem and Submissions.query.filter(Submissions.status.in_([-3, -2, 0])).all():
        lock.release()
        return jsonify({'error': 'Šis uždavinys yra naudojamas vartotojo sprendimo testavime, kurio testavimas yra suplanuotas arba uždavinys yra testuojamas šiuo metu.'}), 400

    elif current_user.urole == "SCHOOL-ADMIN" and delete_problem and delete_problem.visible:

        db.session.delete(delete_problem)
        db.session.commit()

        # Atnaujiname sukurtų uždavinių skaičių
        school = School.query.get(current_user.school_id)
        school.created_problems = school.created_problems - 1
        db.session.commit()

        shutil.rmtree(f'/home/ubuntu/Testai/{delete_problem.id}/')
        os.remove(f'/home/ubuntu/PDF_Salygos/{delete_problem.id}.pdf')

        lock.release()
        flash('Uždavinys sėkmingai ištrintas.', category='success')
        return jsonify({'success': 'Uždavinys sėkmingai ištrintas.'}), 200

    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/view_problem_pdf/<problem_id>')
@login_required
def view_problem_pdf(problem_id):

    problem = Problems.query.get(problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and problem and problem.school_id == current_user.school_id and problem.visible:
        path = f'/home/ubuntu/PDF_Salygos/{problem_id}.pdf'
        return send_file(path)
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/view_test/<problem_id>/<test_case_id>/<test_type>')
@login_required
def view_problem_test_case(problem_id, test_case_id, test_type):

    problem_id = int(problem_id)
    test_case_id = int(test_case_id)
    problem = Problems.query.get(problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and problem and problem.visible and problem.school_id == current_user.school_id:

        if test_type == "IN":
            try: return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.in')
            except: return redirect(url_for('views.home'))

        elif test_type == "SOL":
            try: return send_file(f'/home/ubuntu/Testai/{problem.id}/{test_case_id}.sol')
            except: return redirect(url_for('views.home'))

        else: return redirect(url_for('views.home'))

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/delete_test/<problem_id>/<test_case_id>')
@login_required
def delete_problem_test_case(problem_id, test_case_id):

    problem_id = int(problem_id)
    test_case_id = int(test_case_id)
    problem = Problems.query.get(problem_id)

    if current_user.urole == "SCHOOL-ADMIN" and problem and problem.visible and problem.school_id == current_user.school_id:

        path_in = f'/home/ubuntu/Testai/{str(problem_id)}/{str(test_case_id)}.in'
        path_sol = f'/home/ubuntu/Testai/{str(problem_id)}/{str(test_case_id)}.sol'

        if os.path.exists(path_in) and os.path.exists(path_sol):

            os.remove(path_in)
            os.remove(path_sol)

            for test_id in range(test_case_id+1, problem.testCount+1):

                old_path_in = f'/home/ubuntu/Testai/{str(problem_id)}/{str(test_id)}.in'
                new_path_in = f'/home/ubuntu/Testai/{str(problem_id)}/{str(test_id-1)}.in'
                old_path_sol = f'/home/ubuntu/Testai/{str(problem_id)}/{str(test_id)}.sol'
                new_path_sol = f'/home/ubuntu/Testai/{str(problem_id)}/{str(test_id-1)}.sol'

                os.rename(old_path_in, new_path_in)
                os.rename(old_path_sol, new_path_sol)

            ## Patikriname užduočių atviruosius testus
            tasks = Task.query.filter(and_(Task.problemsId == problem.id, Task.open_test_cases > problem.testCount-1)).all()
            for task in tasks:
                task.open_test_cases = problem.testCount-1
                db.session.commit()

            ## Atnaujiname databazės informaciją
            problem.testCount = problem.testCount-1
            db.session.commit()
            flash(f'Testas nr. {test_case_id} sėkmingai pašalintas.', category='success')
            return redirect(url_for('school_admin.edit_problem', problem_id=problem.id))

        else:
            return redirect(url_for('views.home'))

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/tasks')
@login_required
def tasks():

    page = request.args.get('page', 1, type=int)
    taskID = request.args.get('taskID', None)
    task_name = request.args.get('task_name', None)
    task_mode = request.args.get('task_mode', 'all')
    task_status = request.args.get('task_status', 'visible')
    selectedTags_str = request.args.get('selected_tags', None)
    selectedTags = None
    if selectedTags_str:
        selectedTags = [int(tag) for tag in selectedTags_str.split(',')]

    if current_user.urole == "SCHOOL-ADMIN":

        tasks = Task.query.filter(Task.school_id == current_user.school_id)
        tasks = tasks.order_by(Task.date.desc())

        ## Duomenų struktūra, skirta saugoti užduoties statistikai
        class TaskStatistics:
            def __init__(self, taskID, assigned, submitted, correct):
                self.taskID = taskID
                self.assigned = assigned
                self.submitted = submitted
                self.correct = correct

        ## Jei nustatytas užduoties filtravimas, filtruojame užduotis pagal užduotį
        selected_task_name = ""
        selected_task = Task.query.get(taskID)
        if selected_task and selected_task.school_id == current_user.school_id:
            selected_task_name = selected_task.name
            tasks = tasks.filter(Task.id == selected_task.id)

        ## Jei nustatytas užduoties fragmento filtravimas, filtruojame užduotis pagal užduoties fragmentą
        if not selected_task and task_name:
            tasks = tasks.filter(Task.name.ilike(f'%{task_name}%'))

        ## Jei nustatytas užduoties tipo filtravimas, filtruojame užduotis pagal jų tipą
        if task_mode == "default" or task_mode == "competitive":
            tasks = tasks.filter(Task.mode == task_mode)

        ## Jei nustatytos užduočių žymės, filtruojame užduotis pagal nustatytas žymes
        if selectedTags and selectedTags != ['']:
            filter_conditions = [Task.tags.any(Tag.id == tag_id) for tag_id in selectedTags]
            filter_condition = or_(*filter_conditions)
            tasks = Task.query.filter(filter_condition)

        ## Jei nustatytas užduoties statuso filtravimas, filtruojame pagal užduoties statutą
        if task_status == "visible":
            tasks = tasks.filter(
                Task.openingDate <= datetime.now(),
                (Task.closingDate >= datetime.now()) | (Task.closingDate == defaultDate)
            )

        try:
            tasks = tasks.paginate(page=page, per_page=20)
        except:
            return redirect(url_for('school_admin.tasks', page=1, taskID=taskID, task_name=task_name, task_mode=task_mode, task_status=task_status, selected_tags=selectedTags_str))

        ## Sudaroma užduočių statistika
        tasks_statistics = []
        tasks_assigned_groups_classes = []
        for task in tasks:
            
            submitted = Submissions.query.join(User).filter(Submissions.task_id == task.id, User.urole == "GENERAL").all()
            submitted = sorted(submitted, key=lambda submission: submission.user_id)
            submitted_count = 0

            correct = Submissions.query.join(Task).join(User).join(Problems).filter(Submissions.task_id == task.id, User.urole == "GENERAL", Submissions.score == Problems.testCount).all()
            correct = sorted(correct, key=lambda submission: submission.user_id)
            correct_count = 0

            assigned_groups_classes = task.assigned_classes + task.assigned_groups
            assigned_groups_classes = sorted(assigned_groups_classes, key=lambda group: -len(group.name))
            tasks_assigned_groups_classes.append(assigned_groups_classes)

            for index, submission in enumerate(submitted):
                if index == 0: submitted_count += 1
                elif submitted[index-1].user_id != submission.user_id: submitted_count += 1

            for index, submission in enumerate(correct):
                if index == 0: correct_count += 1
                elif correct[index-1].user_id != submission.user_id: correct_count += 1

            if len(task.users) != 0:
                statistics = TaskStatistics(task.id, len(task.users), submitted_count, correct_count)
            else:
                school_users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
                statistics = TaskStatistics(task.id, len(school_users), submitted_count, correct_count)
            tasks_statistics.append(statistics)

        all_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        tags = Tag.query.filter_by(school_id=current_user.school_id).all()
        return render_template("tasks.html", user=current_user, tasks=tasks, tasks_statistics=tasks_statistics, tasks_assigned_groups_classes=tasks_assigned_groups_classes, all_tasks=all_tasks, tags=tags, selected_tags=selectedTags, task_status=task_status, task_mode=task_mode, taskID=taskID, taskName=task_name, selected_task_name=selected_task_name, school_name=user_school_name(), current_time=datetime.now(), defaultDate=defaultDate, page=page, pageName="Užduotys")
    
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/competitive_tasks')
@login_required
def competitive_tasks():

    page = request.args.get('page', 1, type=int)
    taskID = request.args.get('taskID', None)
    task_name = request.args.get('task_name', None)
    task_status = request.args.get('task_status', 'visible')
    selectedTags_str = request.args.get('selected_tags', None)
    selectedTags = None
    if selectedTags_str:
        selectedTags = [int(tag) for tag in selectedTags_str.split(',')]

    if current_user.urole == "SCHOOL-ADMIN":

        competitive_tasks = Task.query.filter(Task.school_id == current_user.school_id, Task.mode == "competitive")
        competitive_tasks = competitive_tasks.order_by(Task.date.desc())

        ## Duomenų struktūra, skirta saugoti užduoties statistikai
        class TaskStatistics:
            def __init__(self, taskID, assigned, participating, participated):
                self.taskID = taskID
                self.assigned = assigned
                self.participating = participating
                self.participated = participated

        ## Jei nustatytas užduoties filtravimas, filtruojame užduotis pagal užduotį
        selected_task_name = ""
        selected_task = Task.query.get(taskID)
        if selected_task and selected_task.school_id == current_user.school_id:
            selected_task_name = selected_task.name
            competitive_tasks = competitive_tasks.filter(Task.id == selected_task.id)

        ## Jei nustatytas užduoties fragmento filtravimas, filtruojame užduotis pagal užduoties fragmentą
        if not selected_task and task_name:
            competitive_tasks = competitive_tasks.filter(Task.name.ilike(f'%{task_name}%'))

        ## Jei nustatytos užduočių žymės, filtruojame užduotis pagal nustatytas žymes
        if selectedTags and selectedTags != ['']:
            filter_conditions = [Task.tags.any(Tag.id == tag_id) for tag_id in selectedTags]
            filter_condition = or_(*filter_conditions)
            competitive_tasks = Task.query.filter(filter_condition)

        ## Jei nustatytas užduoties statuso filtravimas, filtruojame pagal užduoties statutą
        if task_status == "visible":
            competitive_tasks = competitive_tasks.filter(
                Task.openingDate <= datetime.now(),
                (Task.closingDate >= datetime.now()) | (Task.closingDate == defaultDate)
            )

        try:
            competitive_tasks = competitive_tasks.paginate(page=page, per_page=20)
        except:
            return redirect(url_for('school_admin.competitive_tasks', page=1, taskID=taskID, task_name=task_name, task_status=task_status, selected_tags=selectedTags_str))

        ## Sudaroma užduočių statistika
        competitive_tasks_statistics = []
        competitive_tasks_assigned_groups_classes = []
        for task in competitive_tasks:
            
            participating = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participating").all()
            participated = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participated").all()

            if participating:
                participating_count = len(participating)
            else:
                participating_count = 0

            if participated:
                participated_count = len(participated)
            else:
                participated = 0

            assigned_groups_classes = task.assigned_classes + task.assigned_groups
            assigned_groups_classes = sorted(assigned_groups_classes, key=lambda group: -len(group.name))
            competitive_tasks_assigned_groups_classes.append(assigned_groups_classes)
            statistics = TaskStatistics(task.id, len(task.users), participating_count, participated_count)
            competitive_tasks_statistics.append(statistics)

        all_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        tags = Tag.query.filter_by(school_id=current_user.school_id).all()
        return render_template("competitive_tasks.html", user=current_user, competitive_tasks_statistics=competitive_tasks_statistics, competitive_tasks_assigned_groups_classes=competitive_tasks_assigned_groups_classes, competitive_tasks=competitive_tasks, all_tasks=all_tasks, tags=tags, selected_tags=selectedTags, task_status=task_status, taskID=taskID, taskName=task_name, selected_task_name=selected_task_name, school_name=user_school_name(), page=page, current_time=datetime.now(), defaultDate=defaultDate, pageName="Užduočių varžybos")
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/leaderboard')
@login_required
def leaderboard():

    classID = request.args.get('classID', -1, type=int)

    if current_user.urole == "SCHOOL-ADMIN":
        
        users_competitive_tasks = []
        users_places_in_leaderboard = []
        selected_class = User_class.query.get(classID)
        selected_class_name = ""

        if selected_class and selected_class.school_id == current_user.school_id:
            selected_class_name = selected_class.name
            users_with_rating = User.query.join(User_class).filter(User.school_id == current_user.school_id, User_class.id == selected_class.id, User.current_rank != -1).order_by(User.current_rank.desc())
        else:
            users_with_rating = User.query.filter(User.school_id == current_user.school_id, User.current_rank != -1).order_by(User.current_rank.desc())

        ## Surandame kiekvieno varžybų lentelės vartotojo varžybų skaičių
        for user in users_with_rating:
            user_competitive_tasks = CompetitiveTaskResult.query.filter_by(user_id=user.id, status="participated").all()
            if not user_competitive_tasks:
                users_competitive_tasks.append(0)
            else:
                users_competitive_tasks.append(len(user_competitive_tasks))

        ## Apskaičiuojame kiekivieno vartotojo vietą varžybų lentelėje
        for index, user_with_rating in enumerate(users_with_rating):
            if index == 0:
                users_places_in_leaderboard.append(1)
            elif users_with_rating[index].current_rank == users_with_rating[index-1].current_rank:
                users_places_in_leaderboard.append(users_places_in_leaderboard[index-1])
            else:
                users_places_in_leaderboard.append(users_places_in_leaderboard[index-1]+1)

        user_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
        return render_template("school_admin_leaderboard.html", user=current_user, users=users_with_rating, user_classes=user_classes, classID=classID, selected_class_name=selected_class_name, users_places_in_leaderboard=users_places_in_leaderboard, users_competitive_tasks=users_competitive_tasks, school_name=user_school_name(), pageName="Reitingų lentelė")
    
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/tasks/<task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):

    task = Task.query.get(task_id)

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST' and task and task.school_id == current_user.school_id:

        data = request.get_json()
        taskName = data.get('taskName')
        task_mode = data.get('taskMode')
        selected_problem_id = data.get('selectedProblemId')
        selected_contest_id = data.get('selectedContestId')
        opening_date_str = data.get('openingDate')
        closing_date_str = data.get('closingDate')
        testing_date_str = data.get('testingDate')
        dont_allow_cancel_submission = data.get('allow_cancel_submission')
        open_test_cases = data.get('openTestCases')
        selected_tags = data.get('selectedTags')
        selected_users = data.get('selectedUsers')
        competitiveTaskDurationHours = data.get('competitiveTaskDurationHours')
        competitiveTaskDurationMinutes = data.get('competitiveTaskDurationMinutes')
        competitiveTaskDurationConvertedToMinutes = -1


        ## Pagalbinės funkcijos, skirtos nustatyti, ar tam tikra grupė ar klasė yra priskirta užduočiai ##
        def checkIfGroupIsAssigned(group, task):
            for group_user_id in group.students:
                user = User.query.get(group_user_id)
                if not int(group_user_id) in task.users and user and user.school_id != 0:
                    return False
            return True

        def checkIfClassIsAssigned(user_class, task):
            for class_user in user_class.users:
                if not class_user.id in task.users and class_user.school_id != 0:
                    return False
            return True


        selected_users = list(selected_users)
        selected_users = list(set(selected_users))

        selected_tags = list(selected_tags)
        selected_tags = list(set(selected_tags))

        if dont_allow_cancel_submission:
            allow_cancel_submission_bool = False
        else:
            allow_cancel_submission_bool = True

        ## Patikrinamas užduoties pavadinimas
        if not taskName:
            return jsonify({'error': 'Būtina sukurti užduoties pavadinimą.'}), 400
        elif len(taskName) > 50:
            return jsonify({'error': 'Per ilgas užduoties pavadinimas.'}), 400
        elif len(taskName) < 1:
            return jsonify({'error': 'Per trumpas užduoties pavadinimas.'}), 400

        selected_problem = Problems.query.get(selected_problem_id)
        ## Patikriname, ar egzistuoja ieškomas uždavinys ir ar jis priklauso tai pačiai mokyklai
        if not selected_problem or selected_problem.school_id != current_user.school_id:
            return jsonify({'error': 'Pasirinktas uždavinys neegzistuoja.'}), 400

        ## Patikriname, ar teisingai pasirinktos žymės
        task_tags = []
        if selected_tags != []:
            for tag_id in selected_tags:
                tag = Tag.query.get(tag_id)
                task_tags.append(tag)
                if not tag or tag.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasiriktos užduoties žymės.'}), 400

        ## Patikriname, ar teisingai pasirinkti mokiniai
        if selected_users != []:
            for user_id in selected_users:
                user = User.query.get(user_id)
                if not user or user.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirikti užduoties mokiniai.'}), 400
                ## Jei užduočiai pasirinktas varžybų rėžimas, patikriname, ar pasirinktas mokinys dar nesprendė užduoties
                user_task_submissions = Submissions.query.filter_by(task_id=task.id, user_id=user.id).first()
                if task_mode == "competitive" and task.mode == "default" and user_task_submissions:
                    return jsonify({'error': f'Mokinys {user.first_last_name} jau yra sprendęs šią užduotį, todėl užduočiai negali būti nustatytas varžybų režimas.'}), 400

        ## Nustatome užduočiai priskirtas klases ir grupes
        school_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
        school_groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        assigned_classes = []
        assigned_groups = []

        for school_class in school_classes:
            if len(school_class.users) != 0 and checkIfClassIsAssigned(school_class, task) and school_class not in assigned_classes:
                assigned_classes.append(school_class)

        for shcool_group in school_groups:
            if len(shcool_group.students) != 0 and checkIfGroupIsAssigned(shcool_group, task) and shcool_group not in assigned_groups:
                assigned_groups.append(shcool_group)

        ## Patikriname pasirinktus atviruosius testus
        if int() != 0 and (int(open_test_cases) < 1 or int(open_test_cases) > task.problems.testCount):
            return jsonify({'error': 'Neteisingai pasirinkti atvirieji testai.'}), 400

        #### Jei užduočiai pasirinktas konkurso rėžimas ####
        if task.mode == "contest":
            ## Patikriname užduočiai priskirtą konkursą
            task_contest = Contest.query.get(task.contestID)
            if task_contest.openingDate <= datetime.now() and datetime.now() <= task_contest.closingDate:
                return jsonify({'error': 'Užduočiai priskirtas konkursas šiuo metu vyksta, todėl užduoties redaguoti negalima.'}), 400

        if task.mode == "contest" and task_mode == "contest":

            ## Jei keičiamas užduoties konkursas
            if task.contestID != int(selected_contest_id):

                ## Patikriname pasirinktą konkursą
                selected_contest = Contest.query.get(selected_contest_id)
                if not selected_contest or selected_contest.school_id != current_user.school_id or selected_contest.openingDate < datetime.now():
                    return jsonify({'error': 'Pasirinktas konkursas neegzistuoja, nepriklauso jūsų mokyklai arba jau yra prasidėjęs/pasibaigęs.'}), 400

                ## Užduotis pašalinama iš praeito konkurso
                contest_tasks = task_contest.tasks
                contest_tasks.remove(task.id)
                task_contest.tasks = contest_tasks
                flag_modified(task_contest, 'tasks')
                db.session.commit()

                ## Užduotis pridedama prie naujo konkurso ##
                ## Surikiuojame visas konkurso užduotis pagal taškų skaičių didėjimo tvarka
                contetsTasks = []
                for contestTaskID in selected_contest.tasks:
                    contestTask = Task.query.get(contestTaskID)
                    if contestTask and contestTask.school_id == current_user.school_id:
                        contetsTasks.append(contestTask)

                contetsTasks.append(task)
                contetsTasks = sorted(contetsTasks, key=lambda task: task.problems.testCount)

                ## Sudaromas užduočių ID sąrašas
                contetsTasksIDS = []
                for contetsTask in contetsTasks:
                    contetsTasksIDS.append(contetsTask.id)

                ## Atnaujiname informaciją varžybų duomenų bazėje
                selected_contest.tasks = contetsTasksIDS
                flag_modified(selected_contest, 'tasks')
                db.session.commit()

                ## Atnaujinama duomenų bazės informacija apie užduotį
                task.contestID = selected_contest.id
                task.openingDate = selected_contest.openingDate
                task.closingDate = selected_contest.closingDate
                db.session.commit()

            ## Atnaujinama užduoties informacija
            task.problemsId = selected_problem.id
            task.name = taskName
            task.open_test_cases = open_test_cases
            task.tags = task_tags
            db.session.commit()

            flash('Užduotis sėkmingai atnaujinta.', category='success')
            return jsonify({'success': 'Užduotis sėkmingai atnaujinta.'}), 200

        if task.mode != "contest" and task_mode == "contest":

            ## Patikriname, ar užduoties dar nesprendė mokiniai
            contestTaskSubmissions = Submissions.query.join(User).filter(Submissions.task_id == task.id, User.urole == "GENERAL").first()
            if contestTaskSubmissions:
                return jsonify({'error': 'Šią užduotį jau sprendė mokiniai, todėl jos priskirti konkursui negalima.'}), 400

            ## Patikriname pasirinktą konkursą
            selected_contest = Contest.query.get(selected_contest_id)
            if not selected_contest or selected_contest.school_id != current_user.school_id or selected_contest.openingDate < datetime.now():
                return jsonify({'error': 'Pasirinktas konkursas neegzistuoja, nepriklauso jūsų mokyklai arba jau yra prasidėjęs/pasibaigęs.'}), 400

            ## Atnaujinama užduoties informacija
            task.problemsId = selected_problem.id
            task.contestID = selected_contest.id
            task.name = taskName
            task.openingDate = selected_contest.openingDate
            task.closingDate = selected_contest.closingDate
            task.testingDate = defaultDate
            task.open_test_cases = open_test_cases
            task.users = []
            task.mode = "contest"
            task.competitiveTaskDuration = -1
            task.tags = task_tags
            db.session.commit()

            ## Surikiuojame visas konkurso užduotis pagal taškų skaičių didėjimo tvarka
            contetsTasks = []
            for contestTaskID in selected_contest.tasks:
                contestTask = Task.query.get(contestTaskID)
                if contestTask and contestTask.school_id == current_user.school_id:
                    contetsTasks.append(contestTask)

            contetsTasks.append(task)
            contetsTasks = sorted(contetsTasks, key=lambda task: task.problems.testCount)

            ## Sudaromas užduočių ID sąrašas
            contetsTasksIDS = []
            for contetsTask in contetsTasks:
                contetsTasksIDS.append(contetsTask.id)

            ## Atnaujiname informaciją varžybų duomenų bazėje
            selected_contest.tasks = contetsTasksIDS
            flag_modified(selected_contest, 'tasks')
            db.session.commit()

            flash('Užduotis sėkmingai atnaujinta.', category='success')
            return jsonify({'success': 'Užduotis sėkmingai atnaujinta.'}), 200

        ## Patikriname, varžybų trukmė nustatyta kaip skaičius
        if task_mode == "competitive" and competitiveTaskDurationHours:
            try:
                competitiveTaskDurationHours = int(competitiveTaskDurationHours)
            except ValueError:
                return jsonify({'error': 'Užduoties varžybų trukmė privalo būti sveikasis skaičius.'}), 400

        if task_mode == "competitive" and competitiveTaskDurationMinutes:
            try:
                competitiveTaskDurationMinutes = int(competitiveTaskDurationMinutes)
            except ValueError:
                return jsonify({'error': 'Užduoties varžybų trukmė privalo būti sveikasis skaičius.'}), 400

        ## Užduoties varžybų trukmė paverčiama į minutes
        if task_mode == "competitive" and competitiveTaskDurationHours and competitiveTaskDurationMinutes:
            competitiveTaskDurationConvertedToMinutes = competitiveTaskDurationHours*60 + competitiveTaskDurationMinutes
        elif task_mode == "competitive" and competitiveTaskDurationHours:
            competitiveTaskDurationConvertedToMinutes = competitiveTaskDurationHours*60
        elif task_mode == "competitive" and competitiveTaskDurationMinutes:
            competitiveTaskDurationConvertedToMinutes = int(competitiveTaskDurationMinutes)

        ## Jei norima pakeisti uždavinį ir šiuo metu šios užduoties sprendimas yra testuojamas
        if task.problemsId != selected_problem.id:
            current_task_submissions = Submissions.query.filter_by(task_id=task.id, status=0).first()
            if current_task_submissions:
                return jsonify({'error': 'Šiuo metu yra testuojamas šios užduoties sprendimas, todėl pakeisti uždavinį negalima.'}), 400

        ## Jei norima pašalinti užduoties, kaip varžybų statusą, patikriname, ar visi mokiniai jau pabaigė dalyvauti varžybose
        competititve_task_results = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participating").all()
        if not task_mode == "competitive" and competititve_task_results:
            return jsonify({'error': 'Užduoties varžybų statusas negali būti pakeistas jei yra bent vienas mokinys, šiuo metu dalyvaujantis varžybose.'}), 400

        ## Jei varžybose yra dalyvaujančių mokinių, pakeisti varžybų trukmę negalima
        if task.mode == "competitive":
            competitive_task_results = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participating").first()
            if competitive_task_results:
                return jsonify({'error': 'Kadangi šiuo metu yra užduoties varžybose dalyvaujančių mokinių, pakeisti varžybų trukmės negalima.'}), 400

        if task_mode == "competitive" and competitiveTaskDurationConvertedToMinutes > 44640:
            return jsonify({'error': 'Užduoties varžybų trukmė negali būti ilgesnė nei 31 diena.'}), 400
        elif task_mode == "competitive" and competitiveTaskDurationConvertedToMinutes == 0:
            return jsonify({'error': 'Užduoties varžybų trukmė per trumpa.'}), 400

        ## Patikriname užduoties varžybų trukmę
        if task_mode == "competitive" and competitiveTaskDurationConvertedToMinutes > 44640:
            return jsonify({'error': 'Užduoties varžybų trukmė negali būti ilgesnė nei 31 diena.'}), 400
        elif task_mode == "competitive" and competitiveTaskDurationConvertedToMinutes == 0:
            return jsonify({'error': 'Užduoties varžybų trukmė per trumpa.'}), 400

        ## Nustatoma užduoties atidarymo ir uždarymo datos
        if opening_date_str == '': openingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: openingDate = datetime.strptime(opening_date_str, '%Y-%m-%dT%H:%M')

        if closing_date_str == '': closingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: closingDate = datetime.strptime(closing_date_str, '%Y-%m-%dT%H:%M')

        ## Patikriname, ar varžybų rėžimo užduočiai nenustatyta testavimo data
        if task_mode == "competitive" and testing_date_str != '':
            return jsonify({'error': 'Užduočiai, kuriai nustatytas varžybų režimas, negalima testavimo datos funkcija.'}), 400

        ## Nustatome užduoties testavimo datą
        if testing_date_str == '': testingDate = datetime(1111, 1, 1, 11, 11, 11)
        else: testingDate = datetime.strptime(testing_date_str, '%Y-%m-%dT%H:%M')

        ## Jei pakeičiama užduoties atidarymo data, patikriname ar nėra šiuo metu dalyvaujančių mokinių
        if openingDate != defaultDate and task_mode == "competitive" and task.mode == "competitive":
            competitive_task_results = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participating").first()
            if competitive_task_results:
                return jsonify({'error': 'Šiuo metu yra užduoties varžybose dalyvaujančių mokinių, todėl pakeisti užduoties atidarymo datos negalima.'}), 400

        ## Patikriname užduoties atidarymo ir uždarymo datas
        if openingDate != defaultDate and closingDate != defaultDate and openingDate >= closingDate:
            return jsonify({'error': 'Užduoties uždarymo data turi būti vėlesnė nei užduoties atidarymo data.'}), 400

        ## Jei nustatytas varžybų rėžimas, patikriname uždarymo datą
        if task_mode == "competitive" and task.mode == "competitive" and closingDate != defaultDate and task.closingDate != closingDate:
            competitive_task_results = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participating").first()
            if competitive_task_results and closingDate-timedelta(minutes=1) < datetime.now(): 
                return jsonify({'error': 'Kadangi šiuo metu yra užduoties varžybose dalyvaujančių mokinių, užduoties uždarymo data yra per daug artima dabartinei datai.'}), 400

        ## Patikriname užduoties testavimo datą
        if testing_date_str != '' and (testingDate < datetime.now() or testingDate <= openingDate):
            return jsonify({'error': 'Netinkama užduoties testavimo data.'}), 400

        ## Jei yra šiuo metu varžybose dalyvaujančių mokinių ir buvo pakeistas užduoties uždarymo laikas, atnaujiname automatinį varžybų sustabdymą
        competitive_task_results = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participating").first()
        if competitive_task_results and task.closingDate != closingDate:
            end_competitive_task_time = task.closingDate + timedelta(minutes=2)
            end_competitive_task_time_seconds = (end_competitive_task_time - datetime.now()).total_seconds()
            end_all_competitive_task_results.apply_async(args=(task.id,), countdown=end_competitive_task_time_seconds)

        ## Jei užduočiai panaikinamas konkurso rėžimas, užduotis pašalinama iš priskirto konkurso
        if task.mode == "contest":
            contest_tasks = task_contest.tasks
            contest_tasks.remove(task.id)
            task_contest.tasks = contest_tasks
            flag_modified(task_contest, 'tasks')
            task.contestID = -1
            db.session.commit()

        ## Atnaujiname databazės informaciją apie užduotį
        task.name = taskName
        task.problemsId = selected_problem.id
        task.openingDate = openingDate
        task.closingDate = closingDate
        task.testingDate = testingDate
        task.allow_cancel_submission = allow_cancel_submission_bool
        task.open_test_cases = int(open_test_cases)
        task.users = selected_users
        task.tags=task_tags
        task.mode=task_mode
        task.competitiveTaskDuration = competitiveTaskDurationConvertedToMinutes
        db.session.commit()

        flash('Užduotis sėkmingai atnaujinta.', category='success')
        return jsonify({'success': 'Užduotis sėkmingai atnaujinta.'}), 200

    elif current_user.urole == "SCHOOL-ADMIN" and request.method == 'GET' and task and task.school_id == current_user.school_id:

        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        users = User.query.filter_by(school_id=current_user.school_id, urole='GENERAL').all()
        users = sorted(users, key=sorting_users_by_class)
        school_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
        school_classes = sorted(school_classes, key=sorting_class)
        problems = Problems.query.filter_by(school_id=current_user.school_id).all()
        all_tags = Tag.query.filter_by(school_id=current_user.school_id).all()
        contest = Contest.query.get(task.contestID)
        contests = Contest.query.filter(Contest.school_id == current_user.school_id, Contest.openingDate > datetime.now()).all()

        if task.users != []:
            selected_users = User.query.filter(User.id.in_(task.users)).all()
            selected_users = sorted(selected_users, key=lambda user: user.first_last_name.split()[-1])
        else:
            selected_users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
            selected_users = sorted(selected_users, key=lambda user: user.first_last_name.split()[-1])

        selected_tags = []
        selected_users_results = []
        all_classes_users = []

        for school_class in school_classes:
            class_users = User.query.filter_by(school_id=current_user.school_id, class_id=school_class.id, urole="GENERAL").all()
            class_users_ids = []
            for user_id in class_users:
                class_users_ids.append(user_id.id)
            all_classes_users.append(class_users_ids)

        for selected_user in selected_users:
            selected_user_best_submission = Submissions.query.filter_by(user_id=selected_user.id, task_id=task.id).order_by(Submissions.score.desc()).first()
            selected_users_results.append(selected_user_best_submission)

        for selected_tag in task.tags:
            selected_tags.append(selected_tag.id)

        return render_template("edit_task.html", user=current_user, task=task, problem=task.problems, problems=problems, school_name=user_school_name(), defaultDate=defaultDate, groups=groups, users=users, all_tags=all_tags, selected_tags=selected_tags, selected_users=selected_users, selected_users_results=selected_users_results, school_classes=school_classes, all_classes_users=all_classes_users, contest=contest, contests=contests, pageName=task.name)

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_task/<task_id>', methods=['POST'])
@login_required
def delete_task(task_id):

    delete_task = Task.query.get(task_id)

    ## Jei užduočiai yra priskirtas konkurso rėžimas, jos pašalinti negalima
    if delete_task.mode == "contest":
        return jsonify({'error': 'Ši užduotis yra priskirta konkursui, todėl jos pašalinti negalima.'}), 400

    ## Patikriname, ar norima ištrinti užduotis egzistuoja ir priklauso tai pačiai mokyklai
    if current_user.urole == "SCHOOL-ADMIN" and not delete_task or delete_task.school_id != current_user.school_id:
        return jsonify({'error': 'Užduotis neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400

    if current_user.urole == "SCHOOL-ADMIN" and Submissions.query.filter(Submissions.status.in_([-3, -2, 0]), Submissions.task_id == delete_task.id).all():
        return jsonify({'error': 'Ši užduotis yra naudojama vartotojo sprendimo testavime, kurio testavimas yra suplanuotas arba užduotis yra testuojama šiuo metu.'}), 400

    competititve_task_results = CompetitiveTaskResult.query.filter_by(task_id=delete_task.id, status="participating").all()
    if current_user.urole == "SCHOOL-ADMIN" and competititve_task_results:
        return jsonify({'error': 'Ši užduotis yra naudojama varžybose, kuriose šiuo metu yra dalyvaujančių mokinių, todėl jos ištrinti negalima.'}), 400

    elif current_user.urole == "SCHOOL-ADMIN" and delete_task:

        ## Jei užduočiai yra nustatytas varžybų rėžimas ir yra priskirtas reitingo failas, padarome užduoties kopija
        if delete_task.mode == "competitive" and delete_task.rank_FileID != -1:
            taskCopy = CompetitiveTaskCopy(taskID=delete_task.id, name=delete_task.name, school_id=delete_task.school_id, openingDate=delete_task.openingDate, date=delete_task.date, rank_FileID=delete_task.rank_FileID)
            db.session.add(taskCopy)
            db.session.commit()

        db.session.delete(delete_task)
        db.session.commit()

        # Atnaujiname sukurtų užduočių skaičių
        school = School.query.get(current_user.school_id)
        school.created_tasks = school.created_tasks - 1
        db.session.commit()

        flash('Užduotis pašalinta sėkmingai.', category='success')
        return jsonify({'success': 'Užduotis pašalinta sėkmingai.'}), 200

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/school_users')
@login_required
def school_users():

    userID = request.args.get('userID', None, type=int)
    classID = request.args.get('classID', None, type=int)

    if current_user.urole == "SCHOOL-ADMIN":

        school_users = User.query.filter(User.school_id == current_user.school_id, User.urole == "GENERAL")

        ## Jei nustatytas mokinio filtravimas, filtruojame sąrašą pagal mokinį
        selectedUser = User.query.get(userID)
        if selectedUser and selectedUser.school_id == current_user.school_id:
            school_users = school_users.filter(User.id == selectedUser.id)
        else:
            selectedUser = None

        ## Jei nustatytas klasės filtravimas, filtruojame sąrašą pagal klasę
        if classID == -1:
            class UsrWithoutClass:
                def __init__(self, id, name):
                    self.id = id
                    self.name = name
            selectedClass = UsrWithoutClass(-1, "Nenustatyta klasė")
            school_users = school_users.filter(User.class_id.is_(None))
        else:
            selectedClass = User_class.query.get(classID)
            if selectedClass and selectedClass.school_id == current_user.school_id:
                school_users = school_users.join(User_class).filter(User_class.id == selectedClass.id)
            else:
                selectedClass = None

        school_users.all()
        all_school_users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        school_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
        school_classes = sorted(school_classes, key=sorting_class)
        school_waiting_list = School_waiting_list.query.filter_by(school_id=current_user.school_id).all()
        invitation_code = School.query.get(current_user.school_id).invitation_code

        return render_template("school_users.html", user=current_user, selectedUser=selectedUser, selectedClass=selectedClass, all_school_users=all_school_users, school_users=school_users, school_waiting_list=school_waiting_list, school_name=user_school_name(), invitation_code=invitation_code, school_classes=school_classes, pageName="Mokiniai")
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/delete_user/<user_id>', methods=['POST'])
@login_required
def delete_school_user(user_id):

    lock.acquire()
    user = User.query.get(user_id)

    if current_user.urole == "SCHOOL-ADMIN" and user and user.school_id == current_user.school_id and user.urole == "GENERAL":

        all_school_tasks = Task.query.filter(Task.school_id == current_user.school_id).all()
        tasks = [task for task in all_school_tasks if user_is_in_the_task_list(task.id, user.id)]

        all_school_groups = NewGroup.query.filter(NewGroup.school_id == current_user.school_id).all()
        groups = [group for group in all_school_groups if user_is_in_the_group_list(group.id, user.id)]

        for task in tasks:
            task_users = task.users
            modified_task_users = [char_id for char_id in task_users if char_id != user.id and char_id != str(user.id)]
            task.users = modified_task_users
            if task.users == []: db.session.delete(task)

        for group in groups:
            group_users = group.students
            modified_group_users = [char_id for char_id in group_users if char_id != user.id and char_id != str(user.id)]
            group.students = modified_group_users
            if group.students == []: db.session.delete(group)

        user.school_id = 0
        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.school_users'))

    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/accept_joining_request', methods=['POST'])
@login_required
def accept_joining_request():

    data = request.get_json()
    requests = data.get('requests')

    if current_user.urole == "SCHOOL-ADMIN":
        for requestID in requests:

            user_joining_request = School_waiting_list.query.get(requestID)
            if user_joining_request:
                user = User.query.get(user_joining_request.user_id)

            if user_joining_request and user_joining_request.school_id == current_user.school_id and user:

                ## Vartotojas pridedamas prie mokyklos
                user.school_id = current_user.school_id
                db.session.delete(user_joining_request)
                db.session.commit()

                ## Išsiunčiamas informacinis laiškas
                school_name = School.query.get(current_user.school_id)
                subject = f"Informacija apie prašymą prisijungti prie {school_name.name}"
                message = f"Informuojame, kad {school_name.name} patvirtinio Jūsų prašymą prisijungti prie mokyklos. Dabar galite prisijungti ir pradėti naudotis programavimo platforma."
                email_msg.delay(user.first_last_name, user.email, subject, message)
        
        if len(requests) == 1:
            flash('Vartotojas sėkmingai pridėtas prie mokyklos.', category='success')
            return jsonify({'success': 'Vartotojas sėkmingai pridėtas prie mokyklos.'}), 200
        else:
            flash('Pasirinkti vartotojai sėkmingai pridėti prie mokyklos.', category='success')
            return jsonify({'success': 'Pasirinkti vartotojai sėkmingai pridėti prie mokyklos.'}), 200

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/reject_joining_request', methods=['POST'])
@login_required
def reject_joining_request():

    data = request.get_json()
    requests = data.get('requests')

    if current_user.urole == "SCHOOL-ADMIN":
        for requestID in requests:

            user_joining_request = School_waiting_list.query.get(requestID)
            if user_joining_request and user_joining_request.school_id == current_user.school_id:

                user = User.query.get(user_joining_request.user_id)
                db.session.delete(user_joining_request)
                db.session.commit()

                if user:

                    ## Išsiunčiamas informacinis laiškas
                    school_name = School.query.get(current_user.school_id)
                    subject = f"Informacija apie prašymą prisijungti prie {school_name.name}"
                    message = f"Informuojame, kad {school_name.name} atmetė Jūsų prašymą prisijungti prie mokyklos. Kadangi Jūsų prašymas buvo atmestas, Jūsų paskyra bei visi su ja susiję duomenys buvo pašalinti iš programavimo platformos."
                    email_msg.delay(user.first_last_name, user.email, subject, message)

                    ## Vartotojas pašalinamas
                    settings = User_settings.query.filter_by(user_id=user.id).first()
                    password_reset_requests = Password_reset_request.query.filter_by(user_id=user.id).all()

                    ## Pašalinama vartotojo profilio nuotrauka
                    try:
                        os.remove(f'/home/ubuntu/Profile_images/{user.id}.png')
                    except:
                        pass

                    if settings:
                        db.session.delete(settings)
                    if password_reset_requests:
                        db.session.delete(password_reset_requests)

                    db.session.delete(user)
                    db.session.commit()
        
        if len(requests) == 1:
            flash('Prisijungimo užklausa buvo sėkmingai pašalinta.', category='success')
            return jsonify({'success': 'Prisijungimo užklausa buvo sėkmingai pašalinta.'}), 200
        else:
            flash('Pasirinktos prisijungimo užklausos buvo sėkmingai pašalintos.', category='success')
            return jsonify({'success': 'Pasirinktos prisijungimo užklausos buvo sėkmingai pašalintos.'}), 200

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/new-group', methods=['POST'])
@login_required
def new_group():

    if current_user.urole == "SCHOOL-ADMIN":

        data = request.get_json()
        groupName = data.get('name')
        groupColor = data.get('color')
        selected_users = data.get('users')

        ## Visi sąrašo elementai paverčiami į skaičius
        selected_users = [int(x) for x in selected_users]

        ## Pašaliname atsikartojančius skaičius
        selected_users = list(selected_users)
        selected_users = list(set(selected_users))

        ## Patikriname, ar pasirinkti naujos grupės mokiniai
        if len(selected_users) == 0:
            return jsonify({'error': 'Būtina pasirinkti bent vieną naujos grupės mokinį.'}), 400

        ## Patikriname, ar teisingai pasirinkti mokiniai
        for user_id in selected_users:
            user = User.query.get(user_id)
            if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
                return jsonify({'error': 'Neteisingai pasirikti naujos grupės mokiniai.'}), 400

        ## Patikriname naujos grupės pavadinimo ilgį
        if len(groupName) < 1:
            return jsonify({'error': 'Per trumpas naujos grupės pavadinimas.'}), 400
        elif len(groupName) > 40:
            return jsonify({'error': 'Naujos grupės pavadinimas neturi viršyti 40 simbolių.'}), 400

        ## Patikriname ar pavadinime nėra draudžiamų simbolių
        if '`' in groupName:
            return jsonify({'error': 'Grupės pavadinime negali būti panaudotas draudžiamas simbolis `'}), 400

        ## Patikriname pasirinktą grupės spalvą
        available_colours = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark']
        if not groupColor in available_colours:
            return jsonify({'error': 'Neteisingai pasirinkta naujos grupės spalva.'}), 400

        ## Patikriname, ar su tokiu pavadinimu dar nėra sukurtos grupės
        group_with_the_same_name = NewGroup.query.filter_by(school_id=current_user.school_id, name=groupName).first()
        if group_with_the_same_name:
            return jsonify({'error': 'Jau yra sukurta grupė su tokiu pavadinimu.'}), 400

        ## Sukuriama nauja grupė
        new_group = NewGroup(name=groupName, color=groupColor, students=selected_users, school_id=current_user.school_id)
        db.session.add(new_group)
        db.session.commit()

        flash('Nauja grupė sukurta sėkmingai.', category='success')
        return jsonify({'success': 'Nauja grupė sukurta sėkmingai.'}), 200

    else:
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400


@school_admin.route('/school_admin/delete_group', methods=['POST'])
@login_required
def delete_group():

    if current_user.urole == "SCHOOL-ADMIN":

        data = request.get_json()
        groupID = data.get('id')
        group = NewGroup.query.get(groupID)

        ## Patikriname, ar tokia grupė egzistuoja ir ar ji priklauso vartotojo mokyklai
        if not group or group.school_id != current_user.school_id:
            return jsonify({'error': 'Grupė neegzistuoja arba nepriklauso jūsų mokyklai, todėl jos pašalinti negalima.'}), 400

        ## Randame visas susietas užduotis
        tasks = Task.query.filter(Task.assigned_groups.contains(group)).all()

        ## Atsiejame grupę nuo užduočių
        for task in tasks:
            task.assigned_groups.remove(group)
        db.session.commit()

        ## Pašaliname grupę
        db.session.delete(group)
        db.session.commit()

        flash('Grupė sėkmingai pašalinta.', category='success')
        return jsonify({'success': 'Grupė sėkmingai pašalinta.'}), 200

    else:
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400


@school_admin.route('/school_admin/edit_group', methods=['POST'])
@login_required
def edit_group():


    ## Pagalbinės funkcijos, skirtos nustatyti, ar tam tikra grupė yra priskirta užduočiai ##
    def checkIfGroupIsAssigned(group, task):
        for group_user_id in group.students:
            user = User.query.get(group_user_id)
            if not int(group_user_id) in task.users and user and user.school_id != 0:
                return False
        return True


    if current_user.urole == "SCHOOL-ADMIN":

        data = request.get_json()
        groupID = data.get('id')
        groupName = data.get('name')
        groupColor = data.get('color')
        selected_users = data.get('users')

        ## Pagal nurodytą grupės id surandame grupę
        group = NewGroup.query.get(groupID)
        if not group or group.school_id != current_user.school_id:
            return jsonify({'error': 'Grupė neegzistuoja arba nepriklauso jūsų mokyklai, todėl jos redaguoti negalima.'}), 400

        ## Visi sąrašo elementai paverčiami į skaičius
        selected_users = [int(x) for x in selected_users]

        ## Pašaliname atsikartojančius skaičius
        selected_users = list(selected_users)
        selected_users = list(set(selected_users))

        ## Patikriname, ar pasirinkti grupės mokiniai
        if len(selected_users) == 0:
            return jsonify({'error': 'Būtina pasirinkti bent vieną grupės mokinį.'}), 400

        ## Patikriname, ar teisingai pasirinkti mokiniai
        for user_id in selected_users:
            user = User.query.get(user_id)
            if not user or user.school_id != current_user.school_id:
                return jsonify({'error': 'Neteisingai pasirikti grupės mokiniai.'}), 400

        ## Patikriname grupės pavadinimo ilgį
        if len(groupName) < 1:
            return jsonify({'error': 'Per trumpas grupės pavadinimas.'}), 400
        elif len(groupName) > 40:
            return jsonify({'error': 'Grupės pavadinimas neturi viršyti 40 simbolių.'}), 400

        ## Patikriname ar pavadinime nėra draudžiamų simbolių
        if '`' in groupName:
            return jsonify({'error': 'Grupės pavadinime negali būti panaudotas draudžiamas simbolis `'}), 400

        ## Patikriname pasirinktą grupės spalvą
        available_colours = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark']
        if not groupColor in available_colours:
            return jsonify({'error': 'Neteisingai pasirinkta naujos grupės spalva.'}), 400

        ## Patikriname, ar su tokiu pavadinimu dar nėra sukurtos grupės
        if group.name != groupName:
            group_with_the_same_name = NewGroup.query.filter_by(school_id=current_user.school_id, name=groupName).first()
            if group_with_the_same_name:
                return jsonify({'error': 'Jau yra sukurta grupė su tokiu pavadinimu.'}), 400

        if set(group.students) != set(selected_users):

            ## Atsiejame grupę nuo visų užduočių
            tasks_connected_to_group = Task.query.filter(Task.assigned_groups.contains(group)).all()
            for connected_task in tasks_connected_to_group:
                connected_task.assigned_groups.remove(group)
            db.session.commit()

            ## Per naujo susiejame grupę su užduotim
            all_school_tasks = Task.query.filter(school_id=current_user.school_id).all()
            for task in all_school_tasks:
                if checkIfGroupIsAssigned(group, task) and group not in task.assigned_groups:
                    connected_task.assigned_groups.append(group)
                    db.session.commit()

        ## Grupės informacija atnaujinama
        group.name = groupName
        group.color = groupColor
        group.students = selected_users
        db.session.commit()

        flash('Grupė sėkmingai atnaujinta.', category='success')
        return jsonify({'success': 'Grupė sėkmingai atnaujinta.'}), 200

    else:
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400



@school_admin.route('/school_admin/student_submissions')
@login_required
def student_submissions():

    if current_user.urole == "SCHOOL-ADMIN":
        users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        return render_template('student-submissions.html', user=current_user, users=users, tasks=tasks, school_name=user_school_name(), pageName="Mokinių pateikti sprendimai")
    else:
        return redirect(url_for('views.home'))
    


@school_admin.route('/school_admin/api/student_submissions')
@login_required
def student_submissions_api():

    page = request.args.get('page', 1, type=int)
    start_date = request.args.get('start_date', None)
    end_date = request.args.get('end_date', None)
    task_id = request.args.get('taskID', None)
    user_id = request.args.get('userID', None)
    score_filter = request.args.get('score_filter', 'all')
    comments_filter = request.args.get('comments_filter', 'all')

    ## Patikriname vartotojo tipą
    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės naudotis šia platformos funkcija.'}), 400

    submission_query = Submissions.query.join(User).join(Task).join(Problems).filter(User.school_id == current_user.school_id, User.urole == "GENERAL")
    submission_query = submission_query.order_by(Submissions.date.desc())

    ## Jei nustatyta pradžios data, filtruojame pateiktus sprendimus
    if start_date != None and start_date != "None" and start_date != "":
        try:
            start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
            submission_query = submission_query.filter(Submissions.date >= start_date)
        except ValueError:
            return jsonify({'error': 'Neteisingai nurodyta pradžios data.'}), 400

    ## Jei nustatyta pabaigos data, filtruojame pateiktus sprendimus
    if end_date != None and end_date != "None" and end_date != "":
        try:
            end_date = datetime.strptime(end_date, "%Y-%m-%d").date() + timedelta(days=1)
            submission_query = submission_query.filter(Submissions.date < end_date)
        except ValueError:
            return jsonify({'error': 'Neteisingai nurodyta pabaigos data.'}), 400

    ## Jei nustatyta užduotis, ją patikriname ir pridedame prie bendro filtravimo
    if task_id:
        task = Task.query.get(task_id)
        if task and task.school_id == current_user.school_id:
            submission_query = submission_query.filter(Task.id == task.id)

    ## Jei nustatytas mokinys, jį patikriname ir pridedame prie bendro filtravimo
    if user_id:
        user = User.query.get(user_id)
        if user and user.school_id == current_user.school_id:
            submission_query = submission_query.filter(User.id == user.id)

    ## Ieškome sprendimų su nurodytu surinktų taškų tipu
    if score_filter == 'zero':
        submission_query = submission_query.filter(Submissions.status != -3, Submissions.status != -2, Submissions.status != 0, Submissions.score == 0)
    elif score_filter == 'max':
        submission_query = submission_query.filter(Submissions.status != -3, Submissions.status != -2, Submissions.status != 0, Submissions.score == Problems.testCount)
    elif score_filter == 'between':
        submission_query = submission_query.filter(Submissions.status != -3, Submissions.status != -2, Submissions.status != 0, Submissions.score > 0, Submissions.score < Problems.testCount)
    else:
        score_filter = 'all'

    ## Jei nustatytas komentarų filtravimas, ieškome sprendimų su sukurtais komentarais
    if comments_filter == 'with_comments':
        submission_query = submission_query.filter(exists().where(Submissions.id == Messages.submission_id))

    ## Surenkame informaciją apie pateiktus sprendimus
    submissions = submission_query.paginate(page=page, per_page=20)
    submissions_list = []

    for index, submission in enumerate(submissions):

        if submission.status == -3:
            if submission.task:
                submissions_in_queue = Submissions.query.filter(
                    (Submissions.status == -3) &
                    (Submissions.id < submission.id)
                ).all()
                status_msg = f'Pateiktas sprendimas yra {max(len(submissions_in_queue), 1)} eilėje'
            else:
                status_msg = "Pateiktas sprendimas laukia eilėje"

        elif submission.status == -2:
            if submission.task:
                status_msg = f'Testavimas suplanuotas {submission.task.testingDate}'
            else:
                status_msg = "Testavimas bus atliktas nustatytu metu"

        elif submission.status == -1:
            status_msg = "Testavimas atšauktas"
        elif submission.status == 0:
            status_msg = "Testuojama"
        elif submission.status == 1:
            status_msg = "Testavimo klaida"
        elif submission.status == 2:
            status_msg = "Nesikompiliuoja"
        elif submission.status == 3:
            status_msg = "Testavimas baigtas"


        if submission.task:
            task_name = submission.task.name
            task_id = submission.task.id
            if submission.task.problems:
                max_score = submission.task.problems.testCount
            else:
                max_score = -1
        else:
            task_name = "Užduoties sprendimas"
            task_id = -1
            max_score = -1


        if submission.user:
            user_name = submission.user.first_last_name
        else:
            user_name = "Pašalintas vartotojas"


        if submission.plagiarism_pairs:
            plagiarised = True
        else:
            plagiarised = False

        submission_data = {
            'id': submission.id,
            'task_id': task_id,
            'status': submission.status,
            'status_msg': status_msg,
            'row_id': (page-1)*20 + index + 1,
            'task_name': task_name,
            'user_name': user_name,
            'score': submission.score,
            'max_score': max_score,
            'date': submission.date,
            'error_msg': submission.error_msg,
            'messages': len(submission.messages),
            'plagiarised': plagiarised,
        }

        submissions_list.append(submission_data)

    return jsonify({'submissions': submissions_list, 'page': page, 'pages': submissions.pages})



@school_admin.route('/school_admin/edit_submission', methods=['POST'])
@login_required
def edit_submission():

    data = request.get_json()
    submission_id = data.get('submissionId')
    mode = data.get('mode')
    code = data.get('code')

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400

    ## Surandame mokinio pateiktą sprendimą
    submission = Submissions.query.get(submission_id)
    if not submission or not submission.user or submission.user.school_id != current_user.school_id:
        return jsonify({'error': 'Redaguojamas sprendimas arba jo autorius neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400

    ## Atnaujiname mokinio kodą duomenų bazėje
    submission.submitted_code = code
    db.session.commit()

    if mode == "save":
        return jsonify({'success': 'Mokinio pateiktas sprendimas sėkmingai atnaujintas.'}), 200

    ## Randamas sprendimo uždavinys ir užduotis
    task = Task.query.get(submission.task_id)
    if not task:
        return jsonify({'success': 'Mokinio pateiktas sprendimas sėkmingai atnaujintas, tačiau neištestuotas per naujo, nes nerasta sprendimo užduotis.'}), 200
    
    problem = Problems.query.get(task.problemsId)
    if not problem:
        return jsonify({'success': 'Mokinio pateiktas sprendimas sėkmingai atnaujintas, tačiau neištestuotas per naujo, nes nerastas sprendimo uždavinys.'}), 200

    ## Mokinio kodas testuojamas per naujo
    user_submission = compile_code.delay(current_user.id,  problem.id, task.id, problem.timeLimit, problem.memoryLimit, problem.testCount,
        code, task.open_test_cases, submission.user.settings.default_language, "clang")
    submission.celery_id = user_submission.id
    db.session.commit()
    return jsonify({'success': 'Mokinio pateiktas sprendimas sėkmingai atnaujintas bei netrukus bus ištestuotas per naujo.'}), 200



@school_admin.route('/school_admin/add_code_comment', methods=['POST'])
@login_required
def add_code_comment():

    data = request.get_json()
    submission_id = data.get('submissionId')
    startRow = data.get('startRow')
    startCol = data.get('startColumn')
    endRow = data.get('endRow')
    endCol = data.get('endColumn')
    comment = data.get('comment')

    startRow = int(startRow)
    startCol = int(startCol)
    endRow = int(endRow)
    endCol = int(endCol)

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400

    ## Surandame sprendimą, kuriam pridedamas komentaras
    submission = Submissions.query.get(submission_id)
    if not submission or not submission.user or submission.user.school_id != current_user.school_id:
        return jsonify({'error': 'Sprendimas arba jo autorius neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400

    ## Patikrinamas komentaro ilgis
    if len(comment) > 600:
        return jsonify({'error': 'Komentaro ilgis privalo būti mažesnis nei 600 simbolių.'}), 400

    ## Randamas bendras eilučių ir stulpelių skaičius
    code = submission.submitted_code
    lines = code.split('\n')
    total_rows = len(lines)
    columns_per_row = [len(line) for line in lines]

    ## Patikrinami komentaro pradžios ir pabaigos eilučių skaičiai
    if startRow < 0 or endRow < 0:
        return jsonify({'error': 'Netinkami komentaro pradžios ir pabaigos eilučių skaičiai.'}), 400
    if startRow >= total_rows or endRow >= total_rows:
        return jsonify({'error': 'Netinkami komentaro pradžios ir pabaigos eilučių skaičiai.'}), 400
    if startRow > endRow:
        return jsonify({'error': 'Netinkami komentaro pradžios ir pabaigos eilučių skaičiai.'}), 400

    ## Patikrinami komentaro pradžios ir pabaigos stulpelių skaičiai
    if startCol < 0 or endCol < 0:
        return jsonify({'error': 'Netinkami komentaro pradžios ir pabaigos stulpelių skaičiai.'}), 400
    if startCol > columns_per_row[startRow] or endCol > columns_per_row[endRow]:
        return jsonify({'error': 'Netinkami komentaro pradžios ir pabaigos stulpelių skaičiai.'}), 400
    if startRow == endRow and endCol <= startCol:
        return jsonify({'error': 'Netinkami komentaro pradžios ir pabaigos stulpelių skaičiai.'}), 400

    ## Sukuriame naują kodo komentarą
    new_comment = CodeComment(
        user_id=current_user.id,
        submission_id=submission.id,
        startRow=startRow,
        startCol=startCol,
        endRow=endRow,
        endCol=endCol,
        comment=comment
    )
    db.session.add(new_comment)
    db.session.commit()

    return jsonify({'success': 'Komentaras sėkmingai pridėtas prie mokinio sprendimo.'}), 200



@school_admin.route('/school_admin/api/updateTestCaseResult', methods=['POST'])
@login_required
def updateTestCaseResult():

    data = request.get_json()
    submissionID = data.get('submissionID')
    testCaseID = data.get('testCaseID')
    testCaseID = int(testCaseID)
    testCaseResultID = data.get('testCaseResultID')
    testCaseResultID = int(testCaseResultID)

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės naudotis šia platformos funkcija.'}), 400

    ## Gauname informaciją apie pateiktą sprendimą
    submission = Submissions.query.get(submissionID)

    ## Patikriname pateiktą sprendimą
    if not submission or not submission.user or submission.user.school_id != current_user.school_id:
        return jsonify({'error': 'Pateiktas sprendimas neegzistuoja, nepriklauso jūsų mokyklai arba nerastas sprendimo autorius.'}), 400

    if submission.status != 3:
        return jsonify({'error': 'Pateiktas sprendimas nėra ištestuotas, todėl pakeisti testavimo rezultatų negalima.'}), 400

    ## Patikrinamas pasirinktas testo numeris
    if testCaseResultID < 0 or len(submission.results) <= testCaseResultID:
        return jsonify({'error': 'Neteisingai nurodytas testo numeris.'}), 400

    if not(submission.results[testCaseID] == 3 or submission.results[testCaseID] == 4):
        return jsonify({'error': 'Neteisingai nurodytas testo numeris.'}), 400

    ## Patikrinamas pasirinktas testavimo rezultato ID
    if not(testCaseResultID == 3 or testCaseResultID == 4):
        return jsonify({'error': 'Neteisingai pasirinktas testavimo rezultato kodas.'}), 400

    if submission.results[testCaseID] == testCaseResultID:
        return jsonify({'error': 'Pasirinktas testavimo rezultato ID jau yra priskirtas šiam testui.'}), 400

    ## Atnaujinama pateikto sprendimo informacija
    results = submission.results
    results[testCaseID] = testCaseResultID
    submission.results = results
    flag_modified(submission, 'results')

    if testCaseResultID == 3:
        submission.score += 1
    else:
        submission.score -= 1
    db.session.commit()

    ## Jei užduočiai nustatytas varžybų rėžimas ir sprendimo autorius jame dalyvavo, atnaujiname vartotojo reitingą
    competitive_task_result = CompetitiveTaskResult.query.filter_by(user_id=submission.user_id, task_id=submission.task_id).first()
    if submission.task and submission.task.mode == "competitive" and competitive_task_result:

        submissions_not_plagiarised = Submissions.query.filter(Submissions.user_id==competitive_task_result.user_id, Submissions.task_id==competitive_task_result.task_id, Submissions.plagiarism_pairs==None, Submissions.status > 0).all()
        if submissions_not_plagiarised:

            submissions_not_plagiarised = sorted(submissions_not_plagiarised, key=lambda submission: submission.date)
            submissions_not_plagiarised_sorted = sorted(submissions_not_plagiarised, key=lambda submission: (-submission.score, submission.date))

            ## Parenkamas tinkamas pateiktas sprendimas retingavimui
            if submissions_not_plagiarised_sorted[0].score == submission.task.problems.testCount:
                submission_for_ranking = submissions_not_plagiarised_sorted[0]
            else:
                submission_for_ranking = submissions_not_plagiarised[-1]

            ## Jei sprendimo vartotojas šiuo metu dalyvauja varžybose ir dar nepateikė sprendimo, surinkusio maksimalų taškų skaičių, varžybos nestabdomos
            if competitive_task_result.status == "participating" and submission_for_ranking.score != submission.task.problems.testCount:
                flash('Sprendimo testavimo rezultatas sėkmingai atnaujintas.', category='success')
                return jsonify({'success': 'Sprendimo testavimo rezultatas sėkmingai atnaujintas.'}), 200

            ## Apskaičiuojamas bandymų skaičius
            submissions_attempts = Submissions.query.filter(Submissions.user_id == submission_for_ranking.user_id, Submissions.task_id == submission_for_ranking.task_id, Submissions.plagiarism_pairs==None, Submissions.status > 0, Submissions.id < submission_for_ranking.id).all()
            competitive_task_result.attempts = len(submissions_attempts)

            competitive_task_result.end_date = submission_for_ranking.date
            competitive_task_result.best_submission_id = submission_for_ranking.id

            start_date_datetime = datetime.strptime(competitive_task_result.start_date, "%Y-%m-%d %H:%M:%S")
            start_date_datetime = start_date_datetime.replace(second=0)

            end_date_datetime = datetime.strptime(submission_for_ranking.date, "%Y-%m-%d %H:%M:%S")
            end_date_datetime = end_date_datetime.replace(second=0)

            time_difference = end_date_datetime - start_date_datetime
            difference_in_minutes = time_difference.total_seconds() / 60
            score = round(difference_in_minutes) + len(submissions_attempts)*5
            competitive_task_result.score = score
            db.session.commit()

            ## Jei vartotojas dar dalyvauja varžybose, jos sustabdomos
            if competitive_task_result.status == "participating":
                competitive_task_result.status = "participated"
                db.session.commit()
                email_competitive_task_end.delay(competitive_task_result.user_id, competitive_task_result.task_id)

            ## Apskaičiuojamas vartotojo reitingas
            competitive_task_ranking.delay(submission.task.id)

            flash('Sprendimo testavimo rezultatas sėkmingai atnaujintas bei mokinio varžybos įvertintos iš naujo.', category='success')
            return jsonify({'success': 'Sprendimo testavimo rezultatas sėkmingai atnaujintas bei mokinio varžybos įvertintos iš naujo.'}), 200

    flash('Sprendimo testavimo rezultatas sėkmingai atnaujintas.', category='success')
    return jsonify({'success': 'Sprendimo testavimo rezultatas sėkmingai atnaujintas.'}), 200




@school_admin.route('/school_admin/api/plagiarism', methods=['POST'])
@login_required
def plagiarism_info_api():

    data = request.get_json()
    submission_id = data.get('submissionId')

    submission = Submissions.query.get(submission_id)
    task_name = "Pašalinta užduotis"

    if not submission or submission.user.school_id != current_user.school_id:
        return jsonify({'error': 'Sprendimas neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400

    if not submission.user:
        return jsonify({'error': 'Nerastas pateikto sprendimo autorius.'}), 400

    if not submission.plagiarism_pairs:
        return jsonify({'error': 'Pateiktui sprendimui nenustatytas plagiatas.'}), 400

    if submission.task:
        task_name = submission.task.name

    ## Surikiuojame plagijuotus sprendimus pagal jų panašuma didėjimo tvarka
    plagiarism_pairs = sorted(submission.plagiarism_pairs, key=lambda plagiarismPair: -plagiarismPair.similarity)

    ## Surenkame informaciją apie plagijuotus sprendimus
    plagiarismInfo = []
    plagiarismListNames = set()
    for plagiarism_pair in plagiarism_pairs:

        if plagiarism_pair.leftSubmissionID == submission.id:
            similar_submission = Submissions.query.get(plagiarism_pair.rightSubmissionID)
        else:
            similar_submission = Submissions.query.get(plagiarism_pair.leftSubmissionID)

        if not similar_submission or not similar_submission.user:
            continue

        if similar_submission.user.first_last_name in plagiarismListNames:
            continue
        plagiarismListNames.add(similar_submission.user.first_last_name)

        plagiarism_data = {
            'user_name': similar_submission.user.first_last_name,
            'similarity': plagiarism_pair.similarity,
            'submission': similar_submission.submitted_code,
            'submission_lang': similar_submission.language,
        }

        plagiarismInfo.append(plagiarism_data)

    ## Jei nepavyko gauti informacijos apie nei viena nuplagijuotą sprendimą
    if len(plagiarismInfo) == 0:
        return jsonify({'error': 'Nepavyko gauti informacijos apie nuplagijuotus sprendimus.'}), 400

    ## Gražiname surinktą informaciją apie plagijatą
    return jsonify({'plagiarismInfo': plagiarismInfo, 'user_name': submission.user.first_last_name, 'user_submission': submission.submitted_code, 'user_submission_lang': submission.language, 'task_name': task_name})



@school_admin.route('/school_admin/api/remove_plagiarism', methods=['POST'])
@login_required
def remove_plagiarism_api():

    data = request.get_json()
    submission_id = data.get('submissionId')

    submission = Submissions.query.get(submission_id)

    if not submission or submission.user.school_id != current_user.school_id:
        return jsonify({'error': 'Sprendimas neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400

    if not submission.plagiarism_pairs:
        return jsonify({'error': 'Pateiktui sprendimui nenustatytas plagiatas.'}), 400

    ## Šiam sprendimui priskirtos plagiato poros pašalinamos iš kitų sprendimų
    for plagiarism_pair in submission.plagiarism_pairs:

        if plagiarism_pair.leftSubmissionID == submission.id:
            plagiarised_submission = Submissions.query.get(plagiarism_pair.rightSubmissionID)
        else:
            plagiarised_submission = Submissions.query.get(plagiarism_pair.leftSubmissionID)

        if plagiarised_submission and plagiarised_submission.plagiarism_pairs and not plagiarism_pair in plagiarised_submission.plagiarism_pairs:
            db.session.delete(plagiarism_pair)

    ## Plagiato žymė pašalinama iš užduoties sprendimo
    submission.plagiarism_pairs.clear()
    db.session.commit()

    ## Jei sprendimo užuočiai nustatytas varžybų rėžimas, varžybos įvertinamos iš naujo
    task = Task.query.get(submission.task_id)
    competitive_task_result = CompetitiveTaskResult.query.filter_by(user_id=submission.user_id, task_id=submission.task_id).first()

    if task and task.mode == "competitive" and competitive_task_result:

        submissions_not_plagiarised = Submissions.query.filter(Submissions.user_id==competitive_task_result.user_id, Submissions.task_id==competitive_task_result.task_id, Submissions.plagiarism_pairs==None, Submissions.status > 0).all()
        if submissions_not_plagiarised:

            submissions_not_plagiarised = sorted(submissions_not_plagiarised, key=lambda submission: submission.date)
            submissions_not_plagiarised_sorted = sorted(submissions_not_plagiarised, key=lambda submission: (-submission.score, submission.date))

            ## Parenkamas tinkamas pateiktas sprendimas retingavimui
            if submissions_not_plagiarised_sorted[0].score == task.problems.testCount:
                submission_for_ranking = submissions_not_plagiarised_sorted[0]
            else:
                submission_for_ranking = submissions_not_plagiarised[-1]

            ## Jei sprendimo vartotojas šiuo metu dalyvauja varžybose ir dar nepateikė sprendimo, surinkusio maksimalų taškų skaičių, varžybos nestabdomos
            if competitive_task_result.status == "participating" and submission_for_ranking.score != task.problems.testCount:
                return jsonify({'success': 'Sprendimo plagiato žymė sėkmingai pašalinta.'}), 200

            ## Apskaičiuojamas bandymų skaičius
            submissions_attempts = Submissions.query.filter(Submissions.user_id == submission_for_ranking.user_id, Submissions.task_id == submission_for_ranking.task_id, Submissions.plagiarism_pairs==None, Submissions.status > 0, Submissions.id < submission_for_ranking.id).all()
            competitive_task_result.attempts = len(submissions_attempts)

            competitive_task_result.end_date = submission_for_ranking.date
            competitive_task_result.best_submission_id = submission_for_ranking.id

            start_date_datetime = datetime.strptime(competitive_task_result.start_date, "%Y-%m-%d %H:%M:%S")
            start_date_datetime = start_date_datetime.replace(second=0)

            end_date_datetime = datetime.strptime(submission_for_ranking.date, "%Y-%m-%d %H:%M:%S")
            end_date_datetime = end_date_datetime.replace(second=0)

            time_difference = end_date_datetime - start_date_datetime
            difference_in_minutes = time_difference.total_seconds() / 60
            score = round(difference_in_minutes) + len(submissions_attempts)*5
            competitive_task_result.score = score
            db.session.commit()

            ## Jei vartotojas dar dalyvauja varžybose, jos sustabdomos
            if competitive_task_result.status == "participating":
                competitive_task_result.status = "participated"
                db.session.commit()
                email_competitive_task_end.delay(competitive_task_result.user_id, competitive_task_result.task_id)

            ## Apskaičiuojamas vartotojo reitingas
            competitive_task_ranking.delay(task.id)
            return jsonify({'success': 'Sprendimo plagiato žymė sėkmingai pašalinta bei vartotojo varžybos buvo įvertintos iš naujo.'}), 200
    
    return jsonify({'success': 'Sprendimo plagiato žymė sėkmingai pašalinta.'}), 200



@school_admin.route('/school_admin/api/end_competitive_task', methods=['POST'])
@login_required
def end_competitive_task_api():

    data = request.get_json()
    competitive_task_result_id = data.get('competitive_task_id')
    competitive_task_result = CompetitiveTaskResult.query.get(competitive_task_result_id)

    if current_user.urole == "SCHOOL-ADMIN" and not competitive_task_result:
        return jsonify({'error': 'Vartotojo varžybų informaciją neegzistuoja, todėl negalima sustabdyti varžybų.'}), 400
    elif current_user.urole == "SCHOOL-ADMIN" and competitive_task_result and competitive_task_result.status == "participated":
        return jsonify({'error': 'Vartotojo varžybos jau sustabdytos, todėl negalima sustabdyti varžybų.'}), 400
    elif current_user.urole == "SCHOOL-ADMIN" and competitive_task_result:
        end_competitive_task.delay(competitive_task_result.id)
        return jsonify({'success': 'Vartotojo varžybos bus sustabdytos artimiausiu metu.'}), 200
    else:
        return jsonify({'error': 'Jūs neturite teisės naudotis šia platformos funkcija.'}), 200



@school_admin.route('/school_admin/delete_user_from_group/<user_id>/<group_id>', methods=['POST'])
@login_required
def delete_user_from_group(user_id, group_id):

    lock.acquire()
    user = User.query.get(user_id)
    group = NewGroup.query.get(group_id)

    if current_user.urole == "SCHOOL-ADMIN" and user and group and user.school_id == current_user.school_id and group.school_id == current_user.school_id and user.urole == "GENERAL":

        ## Pašaliname vartotoją iš grupės
        group_users = group.students
        modified_group_users = [char_id for char_id in group_users if char_id != str(user.id)]
        group.students = modified_group_users
        if group.students == []: db.session.delete(group)

        db.session.commit()
        lock.release()
        return redirect(url_for('school_admin.groups'))

    else:
        lock.release()
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/generate_submissions_report')
@login_required
def generate_submissions_report():

    if current_user.urole == "SCHOOL-ADMIN":

        submissions = (Submissions.query.join(User).options(joinedload(Submissions.user)).filter(Submissions.status.in_([1, 2, 3]), User.school_id == current_user.school_id).all())

        ## Jei nėra pateiktų ir įvertintų sprendimų:
        if not submissions:
            return jsonify({'error': 'Nėra pateiktų ir įvertintų mokinių sprendimų.'}), 400

        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=["Vartotojas", "Užduotis", "Data", "Rezultatas", "Sprendimas", "Kompiliavimo klaida"])
        writer.writeheader()

        for submission in submissions:

            if submission.user:
                first_last_name = submission.user.first_last_name
            else:
                first_last_name = "Ištrintas"

            if submission.task:
                task_name = submission.task.name
            else:
                task_name = "Ištrinta"

            writer.writerow({"Vartotojas": first_last_name, "Užduotis": task_name, "Data": submission.date, "Rezultatas": submission.score, "Sprendimas": submission.submitted_code, "Kompiliavimo klaida": submission.error_msg})

        response = Response(output.getvalue(), mimetype='text/csv')
        response.headers["Content-Disposition"] = "attachment; filename=mokiniu_pateikti_sprendimai.csv"
        return response

    else:
        return jsonify({'error': 'Jūs neturite teisės naudotis šia platformos funkcija.'}), 400


@school_admin.route('/school_admin/create_new_class', methods=['POST'])
@login_required
def create_new_class():

    data = request.get_json()
    class_name = data.get('class_name')

    if current_user.urole == "SCHOOL-ADMIN":

        if class_name == None:
            flash('Būtina nurodyti naujo mokymo lygio pavadinimą.', category='error')
            return jsonify()
        elif len(class_name) == 0:
            flash('Būtina nurodyti naujo mokymo lygio pavadinimą.', category='error')
            return jsonify()
        elif len(class_name) > 25:
            flash('Per ilgas naujo mokymo lygio pavadinimas.', category='error')
            return jsonify()
        elif class_name == "Nenustatyta klasė":
            flash('Nustatytas klasės pavadinimas yra neleidžiamas.', category='error')
            return jsonify()
        elif User_class.query.filter_by(name=class_name, school_id=current_user.school_id).first():
            flash('Mokymo lygis su tokiu pavadinimu jau egzistuoja.', category='error')
            return jsonify()

        new_class = User_class(
            name=class_name,
            school_id=current_user.school_id
        )
        db.session.add(new_class)
        db.session.commit()

        flash('Naujas mokymo lygis sėkmingai sukurtas.', category='success')
        return jsonify()

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/create_new_category', methods=['POST'])
@login_required
def create_new_category():

    data = request.get_json()
    category_name = data.get('name')

    if current_user.urole == "SCHOOL-ADMIN":

        if category_name == None:
            return jsonify({'error': 'Būtina nurodyti naujos kategorijos pavadinimą.'}), 400
        elif len(category_name) == 0:
            return jsonify({'error': 'Būtina nurodyti naujos kategorijos pavadinimą.'}), 400
        elif len(category_name) > 50:
            return jsonify({'error': 'Per ilgas naujos kategorijos pavadinimas.'}), 400
        elif ProblemCategory.query.filter_by(name=category_name, school_id=current_user.school_id).first():
            return jsonify({'error': 'Uždavinio kategorija su tokiu pavadinimu jau egzistuoja.'}), 400

        new_category = ProblemCategory(
            name=category_name,
            school_id=current_user.school_id
        )
        db.session.add(new_category)
        db.session.commit()

        return jsonify({'id': new_category.id, 'name': new_category.name}), 200

    else:
        return jsonify()


@school_admin.route('/school_admin/edit_class', methods=['POST'])
@login_required
def edit_class():

    data = request.get_json()
    class_id = data.get('class_id')
    class_name = data.get('class_name')

    if current_user.urole == "SCHOOL-ADMIN":

        class_to_edit = User_class.query.get(class_id)
        if not class_to_edit or class_to_edit.school_id != current_user.school_id:
            flash('Redaguojama klasė neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
            return jsonify()
        elif class_name == None:
            flash('Būtina nurodyti mokymo lygio pavadinimą.', category='error')
            return jsonify()
        elif len(class_name) == 0:
            flash('Būtina nurodyti mokymo lygio pavadinimą.', category='error')
            return jsonify()
        elif len(class_name) > 25:
            flash('Per ilgas mokymo lygio pavadinimas.', category='error')
            return jsonify()
        elif User_class.query.filter_by(name=class_name, school_id=current_user.school_id).first():
            flash('Mokymo lygis su tokiu pavadinimu jau egzistuoja.', category='error')
            return jsonify()

        class_to_edit.name = class_name
        db.session.commit()

        flash('Mokymo lygis sėkmingai atnaujintas.', category='success')
        return jsonify()

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/delete_class', methods=['POST'])
@login_required
def delete_class():

    data = request.get_json()
    class_id = data.get('class_id')

    if current_user.urole == "SCHOOL-ADMIN":

        class_to_delete = User_class.query.get(class_id)
        if not class_to_delete or class_to_delete.school_id != current_user.school_id:
            flash('Klasė neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
            return jsonify()

        ## Atsiejame klasę nuo susietų užduočių
        tasks_connected_to_class = Task.query.filter(Task.assigned_classes.contains(class_to_delete)).all()
        for connected_task in tasks_connected_to_class:
            connected_task.assigned_classes.remove(class_to_delete)

        db.session.delete(class_to_delete)
        db.session.commit()
        
        flash('Mokymo lygis sėkmingai ištrintas.', category='success')
        return jsonify()

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/update_user_class', methods=['POST'])
@login_required
def update_user_class():

    ## Pagalbinė funkcija, skirta nustatyti, ar tam tikra klasė yra priskirta užduočiai ##
    def checkIfClassIsAssigned(user_class, task):
        if len(user_class.users) == 0:
            return False
        for class_user in user_class.users:
            if not class_user.id in task.users and class_user.school_id != 0:
                return False
        return True

    data = request.get_json()
    classID = data.get('classID')
    users = data.get('users')

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės naudotis šia platformos funkcija.'}), 400

    users = list(users)
    users = list(set(users))

    ## Surandame pasirinktą klasę
    selected_class = User_class.query.get(classID)
    if selected_class and selected_class.school_id != current_user.school_id:
        return jsonify({'error': 'Pasirinkta klasė nepriklauso jūsų mokyklai.'}), 400

    ## Patikriname pasirinktus vartotojus
    for userID in users:
        user = User.query.get(userID)
        if not user or user.school_id != current_user.school_id or user.urole != "GENERAL":
            return jsonify({'error': 'Netinkamai pasirinkti mokiniai, kuriems norima nustatyti klasę.'}), 400

    ## Pasirinktiems mokiniams nustatome pasirinktą klasę
    old_users_classes = []
    for userID in users:
        user = User.query.get(userID)
        if user.user_class and user.user_class != selected_class:
            old_users_classes.append(user.user_class)
        if selected_class:
            user.class_id = selected_class.id
        else:
            user.class_id = None
    db.session.commit()

    ## Patikriname, ar nėra tuščių klasių
    school_classes = User_class.query.filter_by(school_id=current_user.school_id).all()
    for school_class in school_classes:
        class_users = User.query.filter_by(class_id=school_class.id).all()
        if not class_users:
            tasks_connected_to_class = Task.query.filter(Task.assigned_classes.contains(school_class)).all()
            for connected_task in tasks_connected_to_class:
                connected_task.assigned_classes.remove(school_class)
    db.session.commit()

    ## Sutvarkome senas vartotojų klases
    for old_class in old_users_classes:

        ## Pasirinkta klasė atsiejama nuo visų užduočių
        tasks_connected_to_class = Task.query.filter(Task.assigned_classes.contains(old_class)).all()
        for connected_task in tasks_connected_to_class:
            connected_task.assigned_classes.remove(old_class)
        db.session.commit()

        ## Pasirinkta klasė prisiejama prie atitinkamų užduočių
        all_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        for school_task in all_tasks:
            if checkIfClassIsAssigned(old_class, school_task) and old_class not in school_task.assigned_classes:
                school_task.assigned_classes.append(old_class)
                db.session.commit()


    if selected_class:

        ## Pasirinkta klasė atsiejama nuo visų užduočių
        tasks_connected_to_class = Task.query.filter(Task.assigned_classes.contains(selected_class)).all()
        for connected_task in tasks_connected_to_class:
            connected_task.assigned_classes.remove(selected_class)
        db.session.commit()

        ## Pasirinkta klasė prisiejama prie atitinkamų užduočių
        all_tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        for school_task in all_tasks:
            if checkIfClassIsAssigned(selected_class, school_task) and selected_class not in school_task.assigned_classes:
                school_task.assigned_classes.append(school_class)
                db.session.commit()

    flash("Pasirinkta klasė sėkmingai nustatyta pasirinktiems mokiniams.", category="success")
    return jsonify({'success': 'Pasirinkta klasė sėkmingai nustatyta pasirinktiems mokiniams.'}), 200



@school_admin.route('/school_admin/create_new_tag', methods=['POST'])
@login_required
def create_new_tag():

    data = request.get_json()
    name = data.get('name')
    colour = data.get('colour')

    if current_user.urole == "SCHOOL-ADMIN":

        available_colours = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark']

        if len(name) == 0:
            flash('Būtina nurodyti naujos žymės pavadinimą.', category='error')
            return jsonify()

        if len(name) > 30:
            flash('Naujos žymės pavadinimas turi būti mažesnis nei 30 simbolių.', category='error')
            return jsonify()

        if not colour in available_colours:
            flash('Neteisingai pasirinkta žymės spalva.', category='error')
            return jsonify()

        new_tag = Tag(
            school_id=current_user.school_id,
            name=name,
            colour=colour
        )
        db.session.add(new_tag)
        db.session.commit()

        flash('Nauja žymė sukurta sėkmingai.', category='success')
        return jsonify()

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/delete_tag', methods=['POST'])
@login_required
def delete_tag():

    data = request.get_json()
    tag_id = data.get('tagID')

    if current_user.urole == "SCHOOL-ADMIN":

        tag_to_delete = Tag.query.get(tag_id)
        if not tag_to_delete or tag_to_delete.school_id != current_user.school_id:
            flash('Žymė neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
            return jsonify()

        db.session.delete(tag_to_delete)
        db.session.commit()
        
        flash('Žymė sėkmingai ištrinta.', category='success')
        return jsonify()

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/edit_tag', methods=['POST'])
@login_required
def edit_tag():

    data = request.get_json()
    tagID = data.get('tagID')
    name = data.get('name')
    colour = data.get('colour')

    if current_user.urole == "SCHOOL-ADMIN":

        available_colours = ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'dark']
        tag_to_edit = Tag.query.get(tagID)

        if not tag_to_edit or tag_to_edit.school_id != current_user.school_id:
            flash('Žymė neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
            return jsonify()

        if len(name) == 0:
            flash('Būtina nurodyti žymės pavadinimą.', category='error')
            return jsonify()

        if len(name) > 30:
            flash('Žymės pavadinimas turi būti mažesnis nei 30 simbolių.', category='error')
            return jsonify()

        if not colour in available_colours:
            flash('Neteisingai pasirinkta žymės spalva.', category='error')
            return jsonify()

        tag_to_edit.name = name
        tag_to_edit.colour = colour
        db.session.commit()

        flash('Žymė sėkmingai atnaujinta.', category='success')
        return jsonify()

    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/statistics', methods=['GET'])
@login_required
def school_statistics():

    if current_user.urole == "SCHOOL-ADMIN":

        all_submissions_int = []
        correct_submissions_int = []
        incorrect_submissions_int = []
        uncompleted_submissions_int = []
        labels = []

        tasks = Task.query.filter_by(school_id=current_user.school_id).all()
        tags = Tag.query.filter_by(school_id=current_user.school_id).all()
        users = User.query.filter_by(school_id=current_user.school_id, urole='GENERAL').all()
        groups = NewGroup.query.filter_by(school_id=current_user.school_id).all()
        classes = User_class.query.filter_by(school_id=current_user.school_id).all()

        #### Generuojame pateiktų sprendimų ataskaitą ####
        ## Pereiname per visas penkias savaites ir surenkame duomenis
        current_date = datetime.now()
        start_date = current_date - timedelta(weeks=5)
        current_week = start_date

        ## Papildoma funkcija, skirta surikiuoti varžybų rezultatus pagal varžybų uždavinį
        def sort_by_task_rank_FileID(competitive_task_result):
            task = Task.query.get(competitive_task_result.task_id)
            task_copy = CompetitiveTaskCopy.query.filter_by(taskID=competitive_task_result.task_id).first()
            if task:
                return task.rank_FileID
            else:
                return task.task_copy

        while current_week <= current_date:

            start_of_week = current_week - timedelta(days=current_week.weekday())
            end_of_week = start_of_week + timedelta(days=6)

            all_submissions = (
                db.session.query(Submissions)
                .join(User, Submissions.user_id == User.id)
                .filter(
                    User.school_id == current_user.school_id,
                    User.urole == "GENERAL",
                    Submissions.date >= start_of_week,
                    Submissions.date <= end_of_week
                )
                .all()
            )
            all_submissions_int.append(len(all_submissions))

            correct_submissions = (
                db.session.query(Submissions)
                .join(User, Submissions.user_id == User.id)
                .join(Task, Submissions.task_id == Task.id)
                .join(Problems, Task.problemsId == Problems.id)
                .filter(
                    User.school_id == current_user.school_id,
                    User.urole == "GENERAL",
                    Submissions.date >= start_of_week,
                    Submissions.date <= end_of_week,
                    Submissions.score == Problems.testCount
                )
                .all()
            )
            correct_submissions_int.append(len(correct_submissions))

            incorrect_submissions = (
                db.session.query(Submissions)
                .join(User, Submissions.user_id == User.id)
                .join(Task, Submissions.task_id == Task.id)
                .join(Problems, Task.problemsId == Problems.id)
                .filter(
                    User.school_id == current_user.school_id,
                    User.urole == "GENERAL",
                    Submissions.date >= start_of_week,
                    Submissions.date <= end_of_week,
                    Submissions.score == 0
                )
                .all()
            )
            incorrect_submissions_int.append(len(incorrect_submissions))

            uncompleted_submissions = (
                db.session.query(Submissions)
                .join(User, Submissions.user_id == User.id)
                .join(Task, Submissions.task_id == Task.id)
                .join(Problems, Task.problemsId == Problems.id)
                .filter(
                    User.school_id == current_user.school_id,
                    User.urole == "GENERAL",
                    Submissions.date >= start_of_week,
                    Submissions.date <= end_of_week,
                    Submissions.score > 0,
                    Submissions.score < Problems.testCount
                )
                .all()
            )
            uncompleted_submissions_int.append(len(uncompleted_submissions))

            labels.append(f"{start_of_week.strftime('%Y-%m-%d')} - {end_of_week.strftime('%Y-%m-%d')}")
            current_week += timedelta(weeks=1)

        start_date = start_date.strftime('%Y-%m-%d')
        if current_week > datetime.now():
            default_end_date = datetime.now().strftime('%Y-%m-%d')
        else:
            current_week = current_week.strftime('%Y-%m-%d')


        #### Generuojame vartotojo reitingo ataskaitą ####
        ## Randame vartotoją su didžiausiu šiuo metu esančiu reitingu
        highest_rating_usr = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
        highest_rating_usr = sorted(highest_rating_usr, key=lambda user: -(user.current_rank))

        if not highest_rating_usr or not highest_rating_usr[0].current_rank or highest_rating_usr[0].current_rank == -1:
            rankStatisticsUsrName = None
            return render_template("school_admin_statistics.html", user=current_user, school_name=user_school_name(), all_submissions=all_submissions_int, correct_submissions=correct_submissions_int, incorrect_submissions=incorrect_submissions_int, uncompleted_submissions=uncompleted_submissions_int, labels=labels, tasks=tasks, tags=tags, users=users, groups=groups, classes=classes, default_start_date=start_date, default_end_date=default_end_date, rankStatisticsUsrName=rankStatisticsUsrName, userRankHistory=[], competitiveTaskNames=[])

        ## Surenkame sureitinguotų vartotojo varžybų informaciją
        user_competitive_tasks = CompetitiveTaskResult.query.filter(
            CompetitiveTaskResult.user_id == highest_rating_usr[0].id,
            CompetitiveTaskResult.status == "participated",
            CompetitiveTaskResult.rank != -1
        ).all()
        user_competitive_tasks = sorted(user_competitive_tasks, key=sort_by_task_rank_FileID)
        
        ## Gautą informaciją apdorojame ir išsaugojame
        userRankHistory = []
        competitiveTaskNames = []
        rankStatisticsUsrName = highest_rating_usr[0].first_last_name

        for competitiveTaskResult in user_competitive_tasks:
            userRankHistory.append(competitiveTaskResult.rank)
            competitiveTask = Task.query.get(competitiveTaskResult.task_id)
            competitiveTask_copy = CompetitiveTaskCopy.query.filter_by(taskID=competitiveTaskResult.task_id).first()
            if competitiveTask:
                competitiveTaskNames.append(competitiveTask.name)
            elif competitiveTask_copy:
                competitiveTaskNames.append(competitiveTask_copy.name)
            else:
                competitiveTaskNames.append("Užduotis pašalinta")

        return render_template("school_admin_statistics.html", user=current_user, school_name=user_school_name(), all_submissions=all_submissions_int, correct_submissions=correct_submissions_int, incorrect_submissions=incorrect_submissions_int, uncompleted_submissions=uncompleted_submissions_int, labels=labels, tasks=tasks, tags=tags, users=users, groups=groups, classes=classes, default_start_date=start_date, default_end_date=default_end_date, userRankHistory=userRankHistory, competitiveTaskNames=competitiveTaskNames, rankStatisticsUsrName=rankStatisticsUsrName, pageName="Statistika")

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/api/submissions_report', methods=['POST'])
@login_required
def api_submissions_report():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        data = json.loads(request.data.decode('utf-8'))
        selected_tasks = data.get('selectedTasks')
        selected_tags = data.get('selectedTags')
        selected_users = data.get('selectedUsers')
        selected_groups = data.get('selectedGroups')
        selected_classes = data.get('selectedClasses')
        submissionsReportStartDate = data.get('submissionsReportStartDate')
        submissionsReportEndDate = data.get('submissionsReportEndDate')
        dataType = data.get('dataType')

        ## Jei pasirinktų mokinių arba pasirinktų užduočių sąrašas yra tuščias
        if len(selected_tasks) == 0 and len(selected_tags) == 0:
            return jsonify({'error': 'Būtina pasirinkti bent vieną užduotį.'}), 400

        if max(len(selected_users), len(selected_groups), len(selected_classes)) == 0:
            return jsonify({'error': 'Būtina pasirinkti bent vieną mokinį, grupę arba klasę.'}), 400

        ## Konvertuojame pasirinktas datas į Datetime objektus
        if submissionsReportStartDate == '': startDate = datetime(1111, 1, 1, 11, 11, 11)
        else: startDate = datetime.strptime(submissionsReportStartDate, '%Y-%m-%dT%H:%M')

        if submissionsReportEndDate == '': endDate = datetime.now()
        else: endDate = datetime.strptime(submissionsReportEndDate, '%Y-%m-%dT%H:%M')

        ## Patikriname pasirinktas datas
        if startDate > endDate:
            return jsonify({'error': 'Sprendimų pabaigos data negali būti vėlesnė nei pradžios data.'}), 400

        ## Patikriname pasirinktas užduotis
        for selected_task_id in selected_tasks:
            selected_task = Task.query.get(selected_task_id)
            if not selected_task or selected_task.school_id != current_user.school_id:
                return jsonify({'error': 'Neteisingai pasirinktos užduotys.'}), 400

        ## Patikriname pasirinktas žymes
        for selected_tag_id in selected_tags:
            selected_tag = Tag.query.get(selected_tag_id)
            if not selected_tag or selected_tag.school_id != current_user.school_id:
                return jsonify({'error': 'Neteisingai pasirinktos žymės.'}), 400
            for selected_tag_task in selected_tag.tasks:
                if not selected_tag_task.id in selected_tasks:
                    selected_tasks.append(selected_tag_task.id)

        ## Išsisaugome pasirinktų uždavinių pavadinimus
        selected_tasks_names = []
        for selected_task_id in selected_tasks:
            selected_task = Task.query.get(selected_task_id)
            if selected_task:
                selected_tasks_names.append(selected_task.name)

        ## Patikriname pasirinktus mokinius
        for selected_user_id in selected_users:
            selected_user = User.query.get(selected_user_id)
            if not selected_user or selected_user.school_id != current_user.school_id:
                return jsonify({'error': 'Neteisingai pasirinkti mokiniai.'}), 400

        ## Patikriname pasirinktas grupes
        if selected_groups:
            for selected_group_id in selected_groups:
                selected_group = NewGroup.query.get(selected_group_id)
                if not selected_group or selected_group.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirinktos grupės.'}), 400
                for selected_group_user in selected_group.students:
                    selected_users.append(int(selected_group_user))

        ## Patikriname pasirinktas klases
        if selected_classes:
            for selected_class_id in selected_classes:
                selected_class = User_class.query.get(selected_class_id)
                if not selected_class or selected_class.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirinktos klasės.'}), 400
                selected_class_students = User.query.filter_by(school_id=current_user.school_id, class_id=selected_class.id).all()
                for selected_class_user in selected_class_students:
                    selected_users.append(selected_class_user.id)

        ## Dar kartą pašaliname dublikatus
        if selected_users:
            selected_users = list(set(selected_users))

        ## Kiekvienam mokiniui randame geriausia kiekvienos užduoties rezultatą
        results = []
        selected_users_names = []
        for selected_user_id in selected_users:

            selected_user = User.query.get(selected_user_id)
            selected_users_names.append(selected_user.first_last_name)
            user_results = []

            for selected_task_id in selected_tasks:

                best_task_submission = Submissions.query.filter(
                    Submissions.user_id == selected_user.id,
                    Submissions.task_id == selected_task_id,
                    Submissions.date >= startDate,
                    Submissions.date <= endDate
                ).order_by(desc(Submissions.score)).first()

                if best_task_submission:
                    if dataType == "points":
                        user_results.append(f"{best_task_submission.score}/{best_task_submission.task.problems.testCount}")
                    else:
                        percentage_of_collected_points = (best_task_submission.score * 100) / best_task_submission.task.problems.testCount
                        user_results.append(f"{round(percentage_of_collected_points)}%")
                else:
                    user_results.append("-")

            results.append(user_results)

        return jsonify({'results': results, 'user_names': selected_users_names, 'task_names': selected_tasks_names}), 200

    elif request.method == 'POST':
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400



@school_admin.route('/school_admin/task/<task_id>/standings')
@login_required
def task_standings(task_id):

    task = Task.query.get(task_id)
    if current_user.urole == "SCHOOL-ADMIN" and task and task.mode == "competitive":
        return render_template('task_standings_school_admin.html', task=task, user=current_user, school_name=user_school_name(), pageName="Varžybų rezultatai")
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/api/task/<task_id>/standings', methods=['GET'])
@login_required
def task_standings_api(task_id):

    task = Task.query.get(task_id)

    if not task or task.mode != "competitive" or not current_user.urole == "SCHOOL-ADMIN":
        return jsonify({'error': 'Nurodyta varžybų užduotis neegzistuoja arba jūs neturite teisės peržiūrėti varžybų rezultatų.'}), 400

    ## Surenkame informaciją apie varžybas pabaigusius vartotojus ir jų rezultatus
    competitive_task_results = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participated").all()
    competitive_task_results = sorted(competitive_task_results, key=lambda competitive_task_result: (-getSubmissionScoreByID(competitive_task_result.best_submission_id), competitive_task_result.score))
    
    best_submissions_scores = []
    user_places_in_competition = []
    standings = []

    for competitive_task_result in competitive_task_results:
        best_submissions_scores.append(getSubmissionScoreByID(competitive_task_result.best_submission_id))
            
    for index, competitive_task_result in enumerate(competitive_task_results):

        ## Išsaugomas vartotojo vardas
        user = User.query.get(competitive_task_result.user_id)
        if user:
            user_name = user.first_last_name
        else:
            user_name = "Vartotojas pašalintas"

        ## Išsaugoma informacija apie vartotojo užimtą vietą varžybose
        if index != 0 and best_submissions_scores[index-1] == best_submissions_scores[index] and competitive_task_results[index-1].score == competitive_task_result.score:
            user_places_in_competition.append(user_places_in_competition[index-1])
        elif index != 0 and best_submissions_scores[index-1] == 0:
            user_places_in_competition.append(user_places_in_competition[index-1])
        elif index != 0:
            user_places_in_competition.append(user_places_in_competition[index-1]+1)
        else:
            user_places_in_competition.append(1)

        data = {
            'user_name': user_name,
            'place_in_competition': user_places_in_competition[index],
            'score': best_submissions_scores[index],
            'time': competitive_task_results[index].score
        }
        standings.append(data)


    ## Surenkame informaciją apie šiuo metu varžybose dalyvaujančius vartotojus
    competitive_task_results_participating = CompetitiveTaskResult.query.filter_by(task_id=task.id, status="participating").all()
    participating_users = []

    for competitive_task_result in competitive_task_results_participating:

        ## Gauname informaciją apie vartotoją
        user = User.query.get(competitive_task_result.user_id)
        task = Task.query.get(competitive_task_result.task_id)

        if not user or not task:
            continue

        ## Randame geriausią pateiktą vartotojo sprendimą bei jo laiką
        user_submissions = Submissions.query.filter_by(user_id=user.id, task_id=task.id).all()
        user_submissions = sorted(user_submissions, key=lambda submission: (-submission.score, submission.date))

        if user_submissions:
            best_score = f"{user_submissions[0].score}/{task.problems.testCount}"
            best_score_time = user_submissions[0].date
        else:
            best_score = "-"
            best_score_time = "-"

        ## Randame vartotojo varžybų pradžios arba pabaigos laiką
        start_date = "-"
        end_date = "-"

        if task.competitiveTaskDuration != -1:
            end_date_datetime = datetime.strptime(competitive_task_result.start_date, "%Y-%m-%d %H:%M:%S") + timedelta(minutes=task.competitiveTaskDuration)
            end_date = end_date_datetime.strftime("%Y-%m-%d %H:%M:%S")
        else:
            start_date = competitive_task_result.start_date

        data = {
            'id': competitive_task_result.id,
            'user_name': user.first_last_name,
            'start_date': start_date,
            'end_date': end_date,
            'best_score': best_score,
            'best_score_time': best_score_time
        }
        participating_users.append(data)


    ## Išsiunčiame surinktą informaciją
    return jsonify({'standings': standings, 'participating_users': participating_users}), 200



@school_admin.route('/school_admin/api/download_submissions_report')
@login_required
def download_submissions_report():

    if current_user.urole == "SCHOOL-ADMIN":

        selected_tasks = request.args.get('selectedTasks')
        selected_tags = request.args.get('selectedTags')
        selected_users = request.args.get('selectedUsers')
        selected_groups = request.args.get('selectedGroups')
        selected_classes = request.args.get('selectedClasses')
        submissionsReportStartDate = request.args.get('submissionsReportStartDate')
        submissionsReportEndDate = request.args.get('submissionsReportEndDate')
        dataType = request.args.get('dataType')

        selected_tasks = json.loads(selected_tasks) if selected_tasks else []
        selected_tags = json.loads(selected_tags) if selected_tags else []
        selected_users = json.loads(selected_users) if selected_users else []
        selected_groups = json.loads(selected_groups) if selected_groups else []
        selected_classes = json.loads(selected_classes) if selected_classes else []

        created_fieldnames = ["Mokiniai"]

        ## Jei pasirinktų mokinių arba pasirinktų užduočių sąrašas yra tuščias
        if len(selected_tasks) == 0 and len(selected_tags) == 0:
            return jsonify({'error': 'Būtina pasirinkti bent vieną užduotį.'}), 400

        if max(len(selected_users), len(selected_groups), len(selected_classes)) == 0:
            return jsonify({'error': 'Būtina pasirinkti bent vieną mokinį, grupę arba klasę.'}), 400

        ## Konvertuojame pasirinktas datas į Datetime objektus
        if submissionsReportStartDate == '': startDate = datetime(1111, 1, 1, 11, 11, 11)
        else: startDate = datetime.strptime(submissionsReportStartDate, '%Y-%m-%dT%H:%M')

        if submissionsReportEndDate == '': endDate = datetime.now()
        else: endDate = datetime.strptime(submissionsReportEndDate, '%Y-%m-%dT%H:%M')

        ## Patikriname pasirinktas datas
        if startDate > endDate:
            return jsonify({'error': 'Sprendimų pabaigos data negali būti vėlesnė nei pradžios data.'}), 400

        ## Patikriname pasirinktas užduotis
        for selected_task_id in selected_tasks:
            selected_task = Task.query.get(int(selected_task_id))
            if not selected_task or selected_task.school_id != current_user.school_id:
                return jsonify({'error': 'Neteisingai pasirinktos užduotys.'}), 400
            else:
                created_fieldnames.append(selected_task.name)

        ## Patikriname pasirinktas žymes
        for selected_tag_id in selected_tags:
            selected_tag = Tag.query.get(selected_tag_id)
            if not selected_tag or selected_tag.school_id != current_user.school_id:
                return jsonify({'error': 'Neteisingai pasirinktos žymės.'}), 400
            for selected_tag_task in selected_tag.tasks:
                if not selected_tag_task.id in selected_tasks:
                    selected_tasks.append(selected_tag_task.id)
                    created_fieldnames.append(selected_tag_task.name)
        
        ## Patikriname pasirinktus mokinius
        for selected_user_id in selected_users:
            selected_user = User.query.get(selected_user_id)
            if not selected_user or selected_user.school_id != current_user.school_id:
                return jsonify({'error': 'Neteisingai pasirinkti mokiniai.'}), 400

        ## Patikriname pasirinktas grupes
        if selected_groups:
            for selected_group_id in selected_groups:
                selected_group = NewGroup.query.get(selected_group_id)
                if not selected_group or selected_group.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirinktos grupės.'}), 400
                for selected_group_user in selected_group.students:
                    selected_users.append(int(selected_group_user))

        ## Patikriname pasirinktas klases
        if selected_classes:
            for selected_class_id in selected_classes:
                selected_class = User_class.query.get(selected_class_id)
                if not selected_class or selected_class.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirinktos klasės.'}), 400
                selected_class_students = User.query.filter_by(school_id=current_user.school_id, class_id=selected_class.id).all()
                for selected_class_user in selected_class_students:
                    selected_users.append(selected_class_user.id)

        ## Dar kartą pašaliname dublikatus
        if selected_users:
            selected_users = list(set(selected_users))

        ## Pradedame kurti CSV failą
        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=created_fieldnames)
        writer.writeheader()

        ## Kiekvienam mokiniui randame geriausia kiekvienos užduoties rezultatą
        for selected_user_id in selected_users:

            selected_user = User.query.get(selected_user_id)
            row_data = {"Mokiniai": selected_user.first_last_name}

            for selected_task_id in selected_tasks:

                selected_task = Task.query.get(selected_task_id)
                best_task_submission = Submissions.query.filter(
                    Submissions.user_id == selected_user.id,
                    Submissions.task_id == selected_task_id,
                    Submissions.date >= startDate,
                    Submissions.date <= endDate
                ).order_by(desc(Submissions.score)).first()
                
                if best_task_submission:
                    if dataType == "points":
                        row_data[selected_task.name] = f"{best_task_submission.score}/{best_task_submission.task.problems.testCount}"
                    else:
                        percentage_of_collected_points = (best_task_submission.score * 100) / best_task_submission.task.problems.testCount
                        row_data[selected_task.name] = f"{round(percentage_of_collected_points)}%"
                else:
                    row_data[selected_task.name] = "-"

            writer.writerow(row_data)

        response = Response(output.getvalue(), mimetype='text/csv')
        response.headers["Content-Disposition"] = "attachment; filename=pateiktu_sprendimu_ataskaita.csv"
        output.close()
        return response

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/api/user_rank_report', methods=['POST'])
@login_required
def api_user_rank_report():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        data = json.loads(request.data.decode('utf-8'))
        selected_users = data.get('selectedUsers')

        labels = []
        datasets = []
        tasks = set()
        colours = ['rgb(54, 162, 235)', 'rgb(244, 208, 63)', 'rgb(147, 197, 114)', 'rgb(210, 43, 43)', 'rgb(165, 105, 189)', 'rgb(170, 51, 106)', 'rgb(255, 117, 24)', 'rgb(193, 154, 107)']

        ## Patikriname pasirinktą vartotoją
        for selected_user_id in selected_users:

            ## Patikriname, ar pasirinktas vartotojas egzistuoja
            selected_user = User.query.get(selected_user_id)
            if not selected_user or selected_user.school_id != current_user.school_id:
                return jsonify({'error': 'Pasirinktas mokinys neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400

            ## Pasirinkto vartotojo dalyvautas varžybas pridedame prie benro varžybų sąrašo
            user_competitive_tasks_results = CompetitiveTaskResult.query.filter(
                CompetitiveTaskResult.user_id == selected_user.id,
                CompetitiveTaskResult.status == "participated",
                CompetitiveTaskResult.rank != -1
            ).all()

            for user_competitive_task_result in user_competitive_tasks_results:
                user_task = Task.query.get(user_competitive_task_result.task_id)
                if user_task:
                    tasks.add(user_task)

        ## Papildoma funkcija, skirta surikiuoti varžybų rezultatus pagal varžybų uždavinį
        def sort_by_task_rank_FileID(competitive_task_result):
            task = Task.query.get(competitive_task_result.task_id)
            task_copy = CompetitiveTaskCopy.query.filter_by(taskID=competitive_task_result.task_id).id
            if task:
                return task.rank_FileID
            else:
                return task.task_copy
        tasks = sorted(tasks, key=sort_by_task_rank_FileID)

        ## Sudarome užduočių antraštes
        for task in tasks:
            labels.append(task.name)

        ## Pereiname per kiekvieną pasirinktą vartotoją ir surandame vartototo varžybų rezultatus
        for selected_user_id in selected_users:

            userRankHistory = []
            selected_user = User.query.get(selected_user_id)

            for task in tasks:

                ## Surenkame sureitinguotų vartotojo varžybų informaciją
                user_competitive_task_result = CompetitiveTaskResult.query.filter(
                    CompetitiveTaskResult.user_id == selected_user.id,
                    CompetitiveTaskResult.task_id == task.id,
                    CompetitiveTaskResult.status == "participated",
                    CompetitiveTaskResult.rank != -1
                ).first()

                ## Jei vartotojas nedalyvavo nei vienose varžybose arba nei viena iš dalyvautų varžybų dar nebuvo įvertinta
                if not user_competitive_task_result:
                    userRankHistory.append(None)
                else:
                    userRankHistory.append(user_competitive_task_result.rank)

            userRankHistory[1] = None

            ## Surinkta informacija išsaugoma
            dataset = {
                'label': f'{selected_user.first_last_name}',
                'data': userRankHistory,
                'borderColor': colours[len(datasets)%8],
                'backgroundColor': colours[len(datasets)%8],
                'spanGaps': True,
            }
            datasets.append(dataset)

        ## Išsiunčiame sugeneruotą vartotojo reitingo ataskaitą
        return jsonify({'labels': labels, 'datasets': datasets})

    else:
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400



@school_admin.route('/school_admin/api/submission_statistics', methods=['POST'])
@login_required
def api_submission_statistics():

    if current_user.urole == "SCHOOL-ADMIN" and request.method == 'POST':

        data = json.loads(request.data.decode('utf-8'))
        selected_users = data.get('selectedUsers')
        selected_groups = data.get('selectedGroups')
        selected_classes = data.get('selectedClasses')
        start_date_str = data.get('start_date')
        end_date_str = data.get('end_date')
        compareDataCheckbox = data.get('compareDataCheckbox')
        dataType = data.get('dataType')
        dateType = data.get('date_type')

        start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d")

        labels = []
        datasets = []
        colours = ['rgb(54, 162, 235)', 'rgb(244, 208, 63)', 'rgb(147, 197, 114)', 'rgb(210, 43, 43)', 'rgb(165, 105, 189)', 'rgb(170, 51, 106)', 'rgb(255, 117, 24)', 'rgb(193, 154, 107)']

        ## Pašaliname visus atsikartojančius ID
        if selected_users:
            selected_users = list(set(selected_users))
        if selected_groups:
            selected_groups = list(set(selected_groups))
        if selected_classes:
            selected_classes = list(set(selected_classes))

        ## Patikriname, ar teisingai nurodytos pradžios ir pabaigos datos
        if end_date > datetime.now() + timedelta(days=1):
            return jsonify({'error': 'Pabaigos data negali būti vėlesnė nei dabartinė data.'}), 400

        if start_date >= end_date:
            return jsonify({'error': 'Pradžios data negali būti vėlesnė nei pabaigos data.'}), 400

        ## Patikriname, ar teisingai nurodytas datos tipas
        if not(dateType == "dienos" or dateType == "savaites" or dateType == "menesiai" or dateType == "metai"):
            return jsonify({'error': 'Neteisingai nurodytas laikotarpio datos tipas.'}), 400

        ## Patikriname pasirinktus mokinius
        if selected_users:
            for selected_user_id in selected_users:
                selected_user = User.query.get(selected_user_id)
                if not selected_user or selected_user.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirinkti mokiniai.'}), 400

        ## Patikriname pasirinktas grupes
        if selected_groups:
            for selected_group_id in selected_groups:
                selected_group = NewGroup.query.get(selected_group_id)
                if not selected_group or selected_group.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirinktos grupės.'}), 400
                for selected_group_user in selected_group.students:
                    selected_users.append(selected_group_user)

        ## Patikriname pasirinktas klases
        if selected_classes:
            for selected_class_id in selected_classes:
                selected_class = User_class.query.get(selected_class_id)
                if not selected_class or selected_class.school_id != current_user.school_id:
                    return jsonify({'error': 'Neteisingai pasirinktos klasės.'}), 400
                selected_class_students = User.query.filter_by(school_id=current_user.school_id, class_id=selected_class.id).all()
                for selected_class_user in selected_class_students:
                    selected_users.append(selected_class_user.id)

        ## Jei pasirinktų mokinių arba pasirinktų užduočių sąrašas yra tuščias
        if compareDataCheckbox and len(selected_users) == 0:
            return jsonify({'error': 'Norint palyginti duomenis, būtina pasirinkti bent vieną mokinį, grupę, klasę.'}), 400

        ## Dar kartą pašaliname dublikatus
        if selected_users:
            selected_users = list(set(selected_users))

        ## Jei pasirinkti visi mokyklos mokiniai
        if not selected_users or len(selected_users) == 0:
            all_school_users = User.query.filter_by(school_id=current_user.school_id, urole="GENERAL").all()
            for school_user in all_school_users:
                selected_users.append(school_user.id)

        ## Nustatome pradžios ir pabaigos datas
        if dateType == "savaites":
            days_to_monday = (start_date.weekday() - 0 + 7) % 7
            start_date = start_date - timedelta(days=days_to_monday)
            days_until_sunday = (6 - end_date.weekday() + 7) % 7
            end_date = end_date + timedelta(days=days_until_sunday)

        elif dateType == "menesiai":
            start_date = start_date.replace(day=1)
            next_month = end_date.month + 1
            next_year = end_date.year + 1 if next_month > 12 else end_date.year
            first_day_of_next_month = datetime(next_year, next_month if next_month <= 12 else 1, 1)
            last_day_of_month = first_day_of_next_month - timedelta(days=1)
            end_date = end_date.replace(day=last_day_of_month.day)

        elif dateType == "metai":
            start_date = start_date.replace(month=1, day=1)
            first_day_of_next_year = datetime(end_date.year + 1, 1, 1)
            end_date = first_day_of_next_year - timedelta(days=1)

        labels_Y_M_D = []
        labels_M_D = []
        labels_D = []

        if dateType == "dienos":
            for date in days_in_date_range(start_date, end_date):
                labels_Y_M_D.append(f'{date.strftime("%Y-%m-%d")}')
                labels_M_D.append(f'{date.strftime("%m-%d")}')
                labels_D.append(f'{date.strftime("%d")}')
        elif dateType == "savaites":
            for start, end in weeks_in_date_range(start_date, end_date):
                labels_Y_M_D.append(f'{start.strftime("%Y-%m-%d")} - {end.strftime("%Y-%m-%d")}')
                labels_M_D.append(f'{start.strftime("%m-%d")} - {end.strftime("%m-%d")}')
                labels_D.append(f'{start.strftime("%d")} - {end.strftime("%d")}')
        elif dateType == "menesiai":
            for start, end in months_in_date_range(start_date, end_date):
                labels_Y_M_D.append(f'{start.strftime("%Y-%m-%d")} - {end.strftime("%Y-%m-%d")}')
                labels_M_D.append(f'{start.strftime("%m-%d")} - {end.strftime("%m-%d")}')
                labels_D.append(f'{start.strftime("%d")} - {end.strftime("%d")}')
        else:
            for start, end in years_in_date_range(start_date, end_date):
                labels_Y_M_D.append(f'{start.strftime("%Y-%m-%d")} - {end.strftime("%Y-%m-%d")}')
                labels_M_D.append(f'{start.strftime("%m-%d")} - {end.strftime("%m-%d")}')
                labels_D.append(f'{start.strftime("%d")} - {end.strftime("%d")}')


        ## Patikriname, ar datų skaičius nėra per didelis
        if len(labels_Y_M_D) <= 14:
            labels = labels_Y_M_D
        elif len(labels_Y_M_D) > 14 and len(labels_M_D) <= 31:
            labels = labels_M_D
        elif len(labels_Y_M_D) > 31 and len(labels_Y_M_D) <= 62:
            labels = labels_D
        else:
            return jsonify({'error': 'Pasirinktas per didelis sprendimų laikotarpis.'}), 400

        ## Jei duomenys yra lyginami
        if compareDataCheckbox:
                
            for selected_user_id in selected_users:

                selected_user = User.query.get(selected_user_id)
                selected_user_data = []

                if dateType == "dienos":
                    for start in days_in_date_range(start_date, end_date):
                        end = start.replace(hour=23, minute=59, second=59)

                        if dataType == "all":
                            submissions = Submissions.query.filter_by(user_id=selected_user.id).filter(Submissions.date.between(start, end)).all()
                        elif dataType == "max":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == Problems.testCount
                                )
                                .all()
                            )
                        elif dataType == "min":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == 0
                                )
                                .all()
                            )
                        else:
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score > 0,
                                    Submissions.score < Problems.testCount
                                )
                                .all()
                            )
                        
                        selected_user_data.append(len(submissions))

                elif dateType == "savaites":
                    for start, end in weeks_in_date_range(start_date, end_date):
                        end = end.replace(hour=23, minute=59, second=59)

                        if dataType == "all":
                            submissions = Submissions.query.filter_by(user_id=selected_user.id).filter(Submissions.date.between(start, end)).all()
                        elif dataType == "max":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == Problems.testCount
                                )
                                .all()
                            )
                        elif dataType == "min":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == 0
                                )
                                .all()
                            )
                        else:
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score > 0,
                                    Submissions.score < Problems.testCount
                                )
                                .all()
                            )
                        
                        selected_user_data.append(len(submissions))

                elif dateType == "menesiai":
                    for start, end in months_in_date_range(start_date, end_date):
                        end = end.replace(hour=23, minute=59, second=59)

                        if dataType == "all":
                            submissions = Submissions.query.filter_by(user_id=selected_user.id).filter(Submissions.date.between(start, end)).all()
                        elif dataType == "max":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == Problems.testCount
                                )
                                .all()
                            )
                        elif dataType == "min":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == 0
                                )
                                .all()
                            )
                        else:
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score > 0,
                                    Submissions.score < Problems.testCount
                                )
                                .all()
                            )
                        
                        selected_user_data.append(len(submissions))

                else:
                    for start, end in years_in_date_range(start_date, end_date):
                        end = end.replace(hour=23, minute=59, second=59)

                        if dataType == "all":
                            submissions = Submissions.query.filter_by(user_id=selected_user.id).filter(Submissions.date.between(start, end)).all()
                        elif dataType == "max":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == Problems.testCount
                                )
                                .all()
                            )
                        elif dataType == "min":
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score == 0
                                )
                                .all()
                            )
                        else:
                            submissions = (
                                db.session.query(Submissions)
                                .join(User, Submissions.user_id == User.id)
                                .join(Task, Submissions.task_id == Task.id)
                                .join(Problems, Task.problemsId == Problems.id)
                                .filter(
                                    User.id == selected_user.id,
                                    Submissions.date >= start,
                                    Submissions.date <= end,
                                    Submissions.score > 0,
                                    Submissions.score < Problems.testCount
                                )
                                .all()
                            )
                        
                        selected_user_data.append(len(submissions))


                dataset = {
                    'label': f'{selected_user.first_last_name}',
                    'data': selected_user_data,
                    'borderColor': colours[len(datasets)%6],
                    'backgroundColor': colours[len(datasets)%6],
                }

                datasets.append(dataset)

            ## Išsiunčiame sugeneruotą statistiką
            return jsonify({'labels': labels, 'datasets': datasets})


        else:

            all_submissions_int = []
            correct_submissions_int = []
            incorrect_submissions_int = []
            uncompleted_submissions_int = []

            if dateType == "dienos":
                for start in days_in_date_range(start_date, end_date):
                    end = start.replace(hour=23, minute=59, second=59)

                    all_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    all_submissions_int.append(len(all_submissions))

                    correct_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.score == Problems.testCount,
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    correct_submissions_int.append(len(correct_submissions))

                    incorrect_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score == 0
                        )
                        .all()
                    )
                    incorrect_submissions_int.append(len(incorrect_submissions))

                    uncompleted_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score > 0,
                            Submissions.score < Problems.testCount
                        )
                        .all()
                    )
                    uncompleted_submissions_int.append(len(uncompleted_submissions))

            elif dateType == "savaites":
                for start, end in weeks_in_date_range(start_date, end_date):
                    end = end.replace(hour=23, minute=59, second=59)

                    all_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    all_submissions_int.append(len(all_submissions))

                    correct_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.score == Problems.testCount,
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    correct_submissions_int.append(len(correct_submissions))

                    incorrect_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score == 0
                        )
                        .all()
                    )
                    incorrect_submissions_int.append(len(incorrect_submissions))

                    uncompleted_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score > 0,
                            Submissions.score < Problems.testCount
                        )
                        .all()
                    )
                    uncompleted_submissions_int.append(len(uncompleted_submissions))

            elif dateType == "menesiai":
                for start, end in months_in_date_range(start_date, end_date):
                    end = end.replace(hour=23, minute=59, second=59)

                    all_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    all_submissions_int.append(len(all_submissions))

                    correct_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.score == Problems.testCount,
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    correct_submissions_int.append(len(correct_submissions))

                    incorrect_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score == 0
                        )
                        .all()
                    )
                    incorrect_submissions_int.append(len(incorrect_submissions))

                    uncompleted_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score > 0,
                            Submissions.score < Problems.testCount
                        )
                        .all()
                    )
                    uncompleted_submissions_int.append(len(uncompleted_submissions))

            else:
                for start, end in years_in_date_range(start_date, end_date):
                    end = end.replace(hour=23, minute=59, second=59)

                    all_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    all_submissions_int.append(len(all_submissions))

                    correct_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.score == Problems.testCount,
                            Submissions.date >= start,
                            Submissions.date <= end
                        )
                        .all()
                    )
                    correct_submissions_int.append(len(correct_submissions))

                    incorrect_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score == 0
                        )
                        .all()
                    )
                    incorrect_submissions_int.append(len(incorrect_submissions))

                    uncompleted_submissions = (
                        db.session.query(Submissions)
                        .join(User, Submissions.user_id == User.id)
                        .join(Task, Submissions.task_id == Task.id)
                        .join(Problems, Task.problemsId == Problems.id)
                        .filter(
                            User.urole == "GENERAL",
                            User.id.in_(selected_users),
                            Submissions.date >= start,
                            Submissions.date <= end,
                            Submissions.score > 0,
                            Submissions.score < Problems.testCount
                        )
                        .all()
                    )
                    uncompleted_submissions_int.append(len(uncompleted_submissions))


            all_submissions_dataset = {
                'label': 'Bendras pateiktų sprendimų sk.',
                'data': all_submissions_int,
                'borderColor': 'rgb(54, 162, 235)',
                'backgroundColor': 'rgb(54, 162, 235)',
            }
            datasets.append(all_submissions_dataset)

            correct_submissions_dataset = {
                'label': 'Teisingų pateiktų sprendimų sk.',
                'data': correct_submissions_int,
                'borderColor': 'rgb(147, 197, 114)',
                'backgroundColor': 'rgb(147, 197, 114)',
            }
            datasets.append(correct_submissions_dataset)

            incorrect_submissions_dataset = {
                'label': 'Neteisingų pateiktų sprendimų sk.',
                'data': incorrect_submissions_int,
                'borderColor': 'rgb(210, 43, 43)',
                'backgroundColor': 'rgb(210, 43, 43)',
            }
            datasets.append(incorrect_submissions_dataset)

            uncompleted_submissions_dataset = {
                'label': 'Sprendimų su trūkstamais testais sk.',
                'data': uncompleted_submissions_int,
                'borderColor': 'rgb(244, 208, 63)',
                'backgroundColor': 'rgb(244, 208, 63)',
            }
            datasets.append(uncompleted_submissions_dataset)

            ## Išsiunčiame sugeneruotą statistiką
            return jsonify({'labels': labels, 'datasets': datasets})

    elif request.method == 'POST':
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400



@school_admin.route('/school_admin/user/<user_id>')
@login_required
def user_info(user_id):

    user = User.query.get(user_id)
    showTasks = request.args.get('tasks', 'active')
    showCompetitiveTasks = request.args.get('competitiveTasks', 'active')

    if current_user.urole == "SCHOOL-ADMIN" and user and user.school_id == current_user.school_id:

        ## Pagalbinės struktūros, skirtos saugoti informacijai apie mokinio uždavinius
        class User_task:
            def __init__(self, name, status, score, testCount, best_submission_time, best_submission_id, hidden):
                self.name = name
                self.status = status
                self.score = score
                self.testCount = testCount
                self.best_submission_time = best_submission_time
                self.best_submission_id = best_submission_id
                self.hidden = hidden

        class User_competitive_task:
            def __init__(self, name, status, place, score, testCount, time, hidden):
                self.name = name
                self.status = status
                self.place = place
                self.score = score
                self.testCount = testCount
                self.time = time
                self.hidden = hidden

        ## Pagalbinė funkcija, skirta surasti vartotojo užimtą vietą varžybose
        def user_place_in_competition(user_competitive_task_result):

            competitive_task_results_users = CompetitiveTaskResult.query.filter(
                CompetitiveTaskResult.task_id == user_competitive_task_result.task_id,
                CompetitiveTaskResult.status == "participated",
                CompetitiveTaskResult.score != -1
            ).all()
            competitive_task_results_users = sorted(competitive_task_results_users, key=lambda competitive_task_result: (-getSubmissionScoreByID(competitive_task_result.best_submission_id), competitive_task_result.score))

            best_submissions_scores = []
            user_places_in_competition = []

            for competitive_task_result in competitive_task_results_users:
                best_submissions_scores.append(getSubmissionScoreByID(competitive_task_result.best_submission_id))

            for index, competitive_task_result in enumerate(competitive_task_results_users):

                if index != 0 and best_submissions_scores[index-1] == best_submissions_scores[index] and competitive_task_results_users[index-1].score == competitive_task_result.score:
                    user_places_in_competition.append(user_places_in_competition[index-1])
                elif index != 0 and best_submissions_scores[index-1] == 0:
                    user_places_in_competition.append(user_places_in_competition[index-1])
                elif index != 0:
                    user_places_in_competition.append(user_places_in_competition[index-1]+1)
                else:
                    user_places_in_competition.append(1)

                if competitive_task_result.user_id == user_competitive_task_result.user_id:
                    return user_places_in_competition[index]


        tasks = Task.query.filter_by(school_id=current_user.school_id, mode="default").all()
        tasks = sorted(tasks, key=lambda task: datetime.strptime(task.date, '%Y-%m-%d %H:%M:%S'))

        competitive_tasks = Task.query.filter_by(school_id=current_user.school_id, mode="competitive").all()
        competitive_tasks = sorted(competitive_tasks, key=lambda task: datetime.strptime(task.date, '%Y-%m-%d %H:%M:%S'))

        ## Surenkame informaciją apie paprastojo rėžimo užduotis
        user_tasks = []
        for task in reversed(tasks):

            task_auth = task_authorization(task, user)

            if showTasks == 'active' and not task_auth:
                continue
            elif showTasks == 'all' and not (task.users == [] or user_is_in_the_task_list(task.id, user.id)):
                continue

            if not task_auth:
                task_hidden = True
            else:
                task_hidden = False

            user_task_submissions = Submissions.query.filter_by(user_id=user.id, task_id=task.id).all()
            user_task_submissions = sorted(user_task_submissions, key=lambda submission: (-submission.score, submission.date))

            if user_task_submissions:

                if user_task_submissions[0].score == task.problems.testCount:
                    task_status = "Atlikta"
                else:
                    task_status = "Atlikta neteisingai"

                userTaskData = User_task(task.name, task_status, user_task_submissions[0].score, task.problems.testCount, user_task_submissions[0].date, user_task_submissions[0].id, task_hidden)
                user_tasks.append(userTaskData)

            else:
                userTaskData = User_task(task.name, "Priskirta", -1, -1, -1, -1, task_hidden)
                user_tasks.append(userTaskData)


        ## Surenkame informaciją apie varžybų rėžimo užduotis
        user_competitive_tasks = []
        for task in reversed(competitive_tasks):

            task_auth = task_authorization(task, user)

            if showCompetitiveTasks == 'active' and not task_auth:
                continue
            elif showCompetitiveTasks == 'all' and not (task.users == [] or user_is_in_the_task_list(task.id, user.id)):
                continue

            if not task_auth:
                task_hidden = True
            else:
                task_hidden = False

            competitive_task_result = CompetitiveTaskResult.query.filter_by(task_id=task.id, user_id=user.id).first()

            if not competitive_task_result:
                userCompetitiveTaskData = User_competitive_task(task.name, "Priskirta", -1, -1, -1, -1, task_hidden)

            elif competitive_task_result.status == "participating":
                best_submissions = Submissions.query.filter(Submissions.user_id == user.id, Submissions.task_id == task.id, Submissions.status > 0).all()
                best_submissions = sorted(best_submissions, key=lambda submission: (-submission.score, submission.date))
                if best_submissions:
                    userCompetitiveTaskData = User_competitive_task(task.name, "Dalyvauja", -1, best_submissions[0].score, task.problems.testCount, -1, task_hidden)
                else:
                    userCompetitiveTaskData = User_competitive_task(task.name, "Dalyvauja", -1, -1, -1, -1, task_hidden)

            else:
                best_submission = Submissions.query.get(competitive_task_result.best_submission_id)
                if best_submission:
                    userCompetitiveTaskData = User_competitive_task(task.name, "Sudalyvauta", user_place_in_competition(competitive_task_result), best_submission.score, task.problems.testCount, competitive_task_result.score, task_hidden)
                else:
                    userCompetitiveTaskData = User_competitive_task(task.name, "Sudalyvauta", user_place_in_competition(competitive_task_result), -1, task.problems.testCount, competitive_task_result.score, task_hidden)

            user_competitive_tasks.append(userCompetitiveTaskData)

        ## Apskaičiuojame vartotojo tikslumą
        correct_submissions = Submissions.query.join(Task).join(Problems).filter(Submissions.user_id == user.id, Submissions.score == Problems.testCount).all()
        solved_tasks = []
        first_try_solved_tasks_count = 0

        for submission in correct_submissions:
            if submission.task_id in solved_tasks:
                continue
            solved_tasks.append(submission.task_id)
            total_task_submissions = Submissions.query.filter_by(user_id=user.id, task_id=submission.task_id).all()
            if len(total_task_submissions) == 1:
                first_try_solved_tasks_count += 1

        if correct_submissions:
            accuracy = (first_try_solved_tasks_count / len(solved_tasks)) * 100
        else:
            accuracy = -1

        if accuracy == int(accuracy):
            accuracy = round(accuracy)
        else:
            accuracy = math.ceil(accuracy * 10) / 10

        ### Apskaičiuojame vartotojo aktyvumą ###
        # Subquery to get the latest submission (highest ID) for each task_id per user
        latest_submissions_subquery = db.session.query(
            Submissions.id
        ).filter(
            Submissions.user_id == user.id,
            Submissions.score == Problems.testCount,
            not_(or_(
                and_(func.strftime('%m-%d', Submissions.date) >= '06-22', func.strftime('%m-%d', Submissions.date) <= '09-01')
            ))
        ).group_by(Submissions.task_id, Submissions.user_id).subquery()

        # Step 1: Filter correct submissions using the latest submissions subquery
        correct_submissions = db.session.query(
            Submissions
        ).filter(
            Submissions.id.in_(latest_submissions_subquery)
        ).all()

        # Step 2: Group submissions by year and week and count them
        submissions_per_week = db.session.query(
            func.extract('year', Submissions.date).label('year'),
            func.extract('week', Submissions.date).label('week'), 
            func.count(Submissions.id).label('submission_count')
        ).filter(
            Submissions.id.in_(latest_submissions_subquery)
        ).group_by('year', 'week').all()

        # Step 3: Calculate the average submissions per week
        if submissions_per_week:
            total_submissions = sum([week.submission_count for week in submissions_per_week])
            num_weeks = len(submissions_per_week)
            average_submissions_per_week = total_submissions / num_weeks
        else:
            average_submissions_per_week = 0

        ## Suapvaliname vartotojų aktyvumą
        if average_submissions_per_week == int(average_submissions_per_week):
            average_submissions_per_week = round(average_submissions_per_week)
        else:
            average_submissions_per_week = math.ceil(average_submissions_per_week * 10) / 10

        user_name = user.first_last_name
        return render_template('user_info.html', school_user=user, accuracy=accuracy, average_submissions_per_week=average_submissions_per_week, user_id=user.id, user_name=user_name, user_tasks=user_tasks, user_competitive_tasks=user_competitive_tasks, showTasks=showTasks, showCompetitiveTasks=showCompetitiveTasks, user=current_user, school_name=user_school_name(), pageName=user.first_last_name)

    elif current_user.urole == "SCHOOL-ADMIN":
        flash('Pasirinktas mokinys neegzistuoja arba nepriklauso jūsų mokyklai.', category='error')
        return redirect(url_for('school_admin.school_users'))

    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/contests')
@login_required
def school_contests():

    if current_user.urole == "SCHOOL-ADMIN":

        tasks = []
        contests = Contest.query.filter_by(school_id=current_user.school_id).all()
        for contest in contests:
            for taskID in contest.tasks:
                task = Task.query.get(taskID)
                if task:
                    tasks.append(task)

        return render_template("contests.html", contests=contests, tasks=tasks, user=current_user, school_name=user_school_name(), pageName="Konkursai")
    
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/new_contest', methods=['POST'])
@login_required
def new_contest():

    data = request.get_json()
    name = data.get('newContestName')
    openingDate_str = data.get('start_date')
    closingDate_str = data.get('end_date')

    if current_user.urole == "SCHOOL-ADMIN":

        def is_contest_overlap(existing_contest, new_opening_date, new_closing_date):
            return (existing_contest.openingDate < new_closing_date and existing_contest.closingDate > new_opening_date)
        
        ## Patikriname naujo konkurso pavadinimą
        if len(name) == 0:
            return jsonify({'error': 'Būtina nurodyti naujo konkurso pavadinimą.'}), 400
        elif len(name) > 50:
            return jsonify({'error': 'Naujo konkurso pavadinimas neturi viršyti 50 simbolių ilgio.'}), 400

        ## Konkurso datas paverčiame į datetime objektus
        if not openingDate_str:
            return jsonify({'error': 'Būtina nustatyti naujo konkurso pradžios laiką.'}), 400
        if not closingDate_str:
            return jsonify({'error': 'Būtina nustatyti naujo konkurso pabaigos laiką.'}), 400

        openingDate = datetime.strptime(openingDate_str, '%Y-%m-%dT%H:%M')
        closingDate = datetime.strptime(closingDate_str, '%Y-%m-%dT%H:%M')

        ## Patikriname konkurso pradžios ir pabaigos laiką
        if openingDate < datetime.now():
            return jsonify({'error': 'Neteisinga konkurso pradžios data.'}), 400
        if closingDate <= openingDate:
            return jsonify({'error': 'Neteisinga konkurso pabaigos data.'}), 400

        time_diff_from_now = openingDate - datetime.now()
        if time_diff_from_now.total_seconds() < 180:
            return jsonify({'error': 'Naujas konkursas turi būti sukurtas bent prieš 3 minutes iki nustatytos kokurso pradžios datos.'}), 400

        contest_duration = closingDate - openingDate
        if contest_duration.total_seconds() < 180:
            return jsonify({'error': 'Konkurso trukmė privalo būti ilgesnė nei 3 minutes.'}), 400

        school_contests = Contest.query.filter_by(school_id=current_user.school_id).all()
        for contest in school_contests:
            if is_contest_overlap(contest, openingDate, closingDate):
                return jsonify({'error': 'Netinkamos konkurso pradžios ir pabaigos datos - vietu metu gali būti tik vienas konkursas.'}), 400

        new_contest = Contest(school_id=current_user.school_id, name=name, openingDate=openingDate, closingDate=closingDate, tasks=[])
        db.session.add(new_contest)
        db.session.commit()

        flash('Naujas konkursas sėkmingai sukurtas.', category='success')
        return jsonify({'success': 'Naujas konkursas sėkmingai sukurtas.'}), 200
    
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/contests')
@login_required
def contests():

    if current_user.urole == "SCHOOL-ADMIN":

        tasks = []
        contests = Contest.query.filter_by(school_id=current_user.school_id).all()
        for contest in contests:
            for taskID in contest.tasks:
                task = Task.query.get(taskID)
                if task:
                    tasks.append(task)

        return render_template("contests.html", contests=contests, tasks=tasks, user=current_user, school_name=user_school_name())
    
    else:
        return redirect(url_for('views.home'))


@school_admin.route('/school_admin/edit_contest', methods=['POST'])
@login_required
def edit_contest():

    data = request.get_json()
    contestID = data.get('contestID')
    name = data.get('contestName')
    openingDate_str = data.get('startDate')
    closingDate_str = data.get('endDate')
    tasks = data.get('tasks')

    ## Gauname informaciją apie redaguojamą konkursą
    contest = Contest.query.get(contestID)
    if current_user.urole == "SCHOOL-ADMIN" and not contest or contest.school_id != current_user.school_id:
        return jsonify({'error': 'Redaguojamas konkursas neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400
    if current_user.urole == "SCHOOL-ADMIN" and contest.openingDate <= datetime.now() and datetime.now() <= contest.closingDate:
        return jsonify({'error': 'Konkurso metu redaguoti konkurso informaciją negalima.'}), 400

    if current_user.urole == "SCHOOL-ADMIN":

        def is_contest_overlap(existing_contest, new_opening_date, new_closing_date):
            return (existing_contest.openingDate < new_closing_date and existing_contest.closingDate > new_opening_date)
        
        ## Patikriname konkurso pavadinimą
        if len(name) == 0:
            return jsonify({'error': 'Būtina nustatyti konkurso pavadinimą.'}), 400
        elif len(name) > 50:
            return jsonify({'error': 'Konkurso pavadinimas neturi viršyti 50 simbolių ilgio.'}), 400

        ## Konkurso datas paverčiame į datetime objektus
        if not openingDate_str:
            return jsonify({'error': 'Būtina nustatyti konkurso pradžios laiką.'}), 400
        if not closingDate_str:
            return jsonify({'error': 'Būtina nustatyti konkurso pabaigos laiką.'}), 400

        openingDate = datetime.strptime(openingDate_str, '%Y-%m-%dT%H:%M')
        closingDate = datetime.strptime(closingDate_str, '%Y-%m-%dT%H:%M')

        ## Patikriname konkurso pradžios ir pabaigos laiką
        if contest.openingDate > datetime.now() and (contest.openingDate != openingDate or contest.closingDate != closingDate):
            if openingDate < datetime.now():
                return jsonify({'error': 'Neteisinga konkurso pradžios data.'}), 400
            if closingDate <= openingDate:
                return jsonify({'error': 'Neteisinga konkurso pabaigos data.'}), 400

            contest_duration = closingDate - openingDate
            if contest_duration.total_seconds() < 180:
                return jsonify({'error': 'Konkurso trukmė privalo būti ilgesnė nei 3 minutes.'}), 400

            school_contests = Contest.query.filter_by(school_id=current_user.school_id).all()
            for existing_contest in school_contests:
                if contest.id != existing_contest.id and is_contest_overlap(existing_contest, openingDate, closingDate):
                    return jsonify({'error': 'Netinkamos konkurso pradžios ir pabaigos datos - vietu metu gali būti tik vienas konkursas.'}), 400

        elif contest.openingDate != openingDate or contest.closingDate != closingDate:
            return jsonify({'error': 'Pasibaigus konkursui keisti konkurso pradžios ir pabaigos datas negalima.'}), 400

        ## Iš konkurso sąrašo pašaliname dublikatus
        tasks_unique_set = set(tasks)
        tasks_unique_list = list(tasks)
        if tasks != tasks_unique_list:
            return jsonify({'error': 'Neteisingai surikiuotos konkurso užduotys.'}), 400

        ## Patikriname surikiuotas konkurso užduotis
        if len(contest.tasks) != len(tasks):
            return jsonify({'error': 'Neteisingai surikiuotos konkurso užduotys.'}), 400

        for taskID in tasks:
            if not taskID in contest.tasks:
                return jsonify({'error': 'Neteisingai surikiuotos konkurso užduotys.'}), 400

        ## Jei reikia, atnaujiname konkurso užduočių atidarymo ir uždarymo datas
        if contest.openingDate != openingDate or contest.closingDate != closingDate:
            contestTasks = Task.query.filter_by(contestID=contest.id).all()
            for contestTask in contestTasks:
                contestTask.openingDate = openingDate
                contestTask.closingDate = closingDate
            db.session.commit()

        ## Atnaujinama konkurso informacija
        contest.name = name
        contest.openingDate = openingDate
        contest.closingDate = closingDate
        contest.tasks = tasks
        flag_modified(contest, 'tasks')
        db.session.commit()
        flash('Informacija apie konkursą sėkmingai atnaujinta.', category='success')
        return jsonify({'success': 'Informacija apie konkursą sėkmingai atnaujinta.'}), 200
    
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/delete_contest', methods=['POST'])
@login_required
def delete_contest():

    data = request.get_json()
    contestID = data.get('contestID')

    ## Gauname informaciją apie trinamą konkursą
    contest = Contest.query.get(contestID)
    if current_user.urole == "SCHOOL-ADMIN" and not contest or contest.school_id != current_user.school_id:
        return jsonify({'error': 'Konkursas neegzistuoja arba nepriklauso jūsų mokyklai.'}), 400
    if current_user.urole == "SCHOOL-ADMIN" and contest.openingDate <= datetime.now() and datetime.now() <= contest.closingDate:
        return jsonify({'error': 'Konkurso metu pašalinti konkursą negalima.'}), 400

    if current_user.urole == "SCHOOL-ADMIN":

        ## Visoms konkurso užduotim priskiriamas paprastasis rėžimas
        contestTasks = Task.query.filter_by(contestID=contest.id).all()
        for contestTask in contestTasks:
            contestTask.contestID = -1
            contestTask.mode = "default"
        db.session.commit()

        ## Pašalinama konkurso informacija
        db.session.delete(contest)
        db.session.commit()

        flash('Konkursas sėkmingai pašalintas.', category='success')
        return jsonify({'success': 'Konkursas sėkmingai pašalintas.'}), 200
    
    else:
        return redirect(url_for('views.home'))



@school_admin.route('/school_admin/api/deleteProfileRequest', methods=['POST'])
@login_required
def deleteProfileRequest():

    data = request.get_json()
    selected_users = data.get('users')
    password = data.get('password')

    ## Patikriname vartotojo profilio tipą
    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': 'Jūs neturite teisės pasiekti šios platformos funkcijos.'}), 400

    ## Patikriname vartotojo slaptažodį
    if not check_password_hash(current_user.password, password):
        return jsonify({'error': 'neteisingas vartotojo slaptažodis.'}), 400

    ## Sutvarkome mokinių sąrašą
    selected_users = [int(x) for x in selected_users]
    selected_users = list(selected_users)
    selected_users = list(set(selected_users))

    ## Patikriname ar teisingai pasirinktos pašalinamos paskyros
    for userID in selected_users:
        userToDelete = User.query.get(userID)
        if not userToDelete or userToDelete.school_id != current_user.school_id:
            return jsonify({'error': 'neteisingai pasirinktos pašalinamos paskyros.'}), 400

    ## Patikriname ar nėra ankstesnių profilio pašalinimo užklausų
    delete_request = Profiles_delete_request.query.filter_by(user_id=current_user.id).first()

    if delete_request:
        db.session.delete(delete_request)
        db.session.commit()

    ## Sugeneruojamas patvirtinimo kodas
    verification_code = secrets.randbelow(90000) + 10000
    same_verification_code = Profiles_delete_request.query.filter_by(code=verification_code).first()
    while same_verification_code:
        verification_code = secrets.randbelow(90000) + 10000
        same_verification_code = Profiles_delete_request.query.filter_by(code=verification_code).first()

    ## Sukuriama nauja profilio ištrynimo užklausa
    new_delete_request = Profiles_delete_request(user_id=current_user.id, school_id=current_user.school_id, users=selected_users, code=verification_code)
    db.session.add(new_delete_request)
    db.session.commit()

    ## Sugeneruotas patvirtinimo kodas išsiunčiamas el. paštu
    email_verification_code.delay(current_user.id, verification_code, "Pasirinktų paskyrų pašalinimo patvirtinimo kodas")

    return jsonify({'requestID': new_delete_request.id}), 200



@school_admin.route('/school_admin/api/emailCodeVerification', methods=['POST'])
@login_required
def emailCodeVerification():

    data = request.get_json()
    code = data.get('code')

    ## Patikriname, ar yra pateikta profilių pašalinimo užklausa
    delete_request = Profiles_delete_request.query.filter_by(user_id=current_user.id).first()
    if not delete_request:
        return jsonify({'error': 'profilių pašalinimo užklausa nebuvo gauta. Bandykite per naujo.'}), 400

    ## Patikriname, ar patvirtinimo kodas teisingas
    if not delete_request.code == code:
        return jsonify({'error': 'neteisingas patvirtinimo kodas.'}), 400

    ## Patikriname, ar užklausos galiojimo laikas dar nėra pasibaigęs
    code_request_date = datetime.strptime(delete_request.code_request_date, "%Y-%m-%d %H:%M:%S.%f")
    if datetime.now() - code_request_date > timedelta(minutes=10):
        return jsonify({'error': 'patvirtinimo kodo galiojimo laikas pasibaigęs.'}), 400

    ## Patvirtiname profilio pašalinimo užklausą
    delete_request.authorized = True
    db.session.commit()

    return jsonify({'success': 'Profilių pašalinimo užklausa sėkmingai patvirtinta.'}), 200



@school_admin.route('/school_admin/api/deleteUserProfile', methods=['POST'])
@login_required
def deleteUserProfile():

    ## Patikriname, ar yra pateikta profilių pašalinimo užklausa
    delete_request = Profiles_delete_request.query.filter_by(user_id=current_user.id).first()
    if not delete_request:
        return jsonify({'error': 'profilių pašalinimo užklausa nebuvo gauta. Bandykite per naujo.'}), 400

    ## Patikriname, ar profilių pašalinimo užklausa yra patvirtinta
    if not delete_request.authorized:
        return jsonify({'error': 'profilių pašalinimo užklausa nebuvo patvirtinta.'}), 400

    failed_count = 0
    for userID in delete_request.users:

        user = User.query.get(userID)
        if not user or user.school_id != current_user.school_id:
            failed_count += 1
            continue

        all_tasks = Task.query.filter_by(school_id=user.school_id).all()
        all_groups = NewGroup.query.filter_by(school_id=user.school_id).all()
        school_waiting_list = School_waiting_list.query.filter_by(user_id=user.id).first()
        settings = User_settings.query.filter_by(user_id=user.id).first()
        password_reset_requests = Password_reset_request.query.filter_by(user_id=user.id).all()
        submissions = Submissions.query.filter_by(user_id=user.id).all()
        user_messages = Messages.query.filter_by(user_id=user.id).all()
        competitive_task_results = CompetitiveTaskResult.query.filter_by(user_id=user.id).all()

        tasks = [task for task in all_tasks if user_is_in_the_task_list(task.id, user.id)]
        groups = [group for group in all_groups if user_is_in_the_group_list(group.id, user.id)]

        for task in tasks:
            task_users = task.users
            modified_task_users = [char_id for char_id in task_users if char_id != user.id and char_id != str(user.id)]
            task.users = modified_task_users
            if task.users == []: db.session.delete(task)

        for group in groups:
            group_users = group.students
            modified_group_users = [char_id for char_id in group_users if char_id != user.id and char_id != str(user.id)]
            group.students = modified_group_users
            if group.students == []:
                tasks_connected_to_group = Task.query.filter(Task.assigned_groups.contains(group)).all()
                for connected_task in tasks_connected_to_group:
                    connected_task.assigned_groups.remove(group)
                db.session.delete(group)

        ## Patikriname, ar vartotojas nėra vienintelis klasės dalyvis
        if user.user_class:
            users_assigned_to_class = User.query.filter_by(class_id=user.class_id).all()
            user_class = User_class.query.get(user.class_id)
            if len(users_assigned_to_class) == 1:
                tasks_connected_to_class = Task.query.filter(Task.assigned_classes.contains(user_class)).all()
                for connected_task in tasks_connected_to_class:
                    connected_task.assigned_classes.remove(user_class)

        if school_waiting_list:
            db.session.delete(school_waiting_list)
        if settings:
            db.session.delete(settings)
        for request in password_reset_requests:
            db.session.delete(request)
        for competitiveTaskResult in competitive_task_results:
            db.session.delete(competitiveTaskResult)
        for message in user_messages:
            db.session.delete(message)
        db.session.commit()

        for submission in submissions:
            plagiarism_pairs1 = Plagiarism_pair.query.filter_by(leftSubmissionID=submission.id).all()
            plagiarism_pairs2 = Plagiarism_pair.query.filter_by(rightSubmissionID=submission.id).all()
            plagiarism_pairs = plagiarism_pairs1 + plagiarism_pairs2
            submission_messages = Messages.query.filter_by(submission_id=submission.id).all()
            codeComments = CodeComment.query.filter_by(submission_id=submission.id).all()
            for plagiarism_pair in plagiarism_pairs:
                db.session.delete(plagiarism_pair)
            for submission_message in submission_messages:
                db.session.delete(submission_message)
            for comment in codeComments:
                db.session.delete(comment)
            db.session.delete(submission)

        ## Pašalinama vartotojo profilio nuotrauka
        try:
            os.remove(f'/home/ubuntu/Profile_images/{user.id}.png')
        except:
            pass

        ## Vartotojas informuojamas apie paskyros pašalinimą
        school_name = School.query.get(current_user.school_id)
        subject = f"Informacija apie Jūsų paskyros pašalinimą"
        message = f"Informuojame, kad mokytojo sprendimu Jūsų paskyros prieiga prie {school_name} buvo pašalinta. Kadangi Jūsų paskyra neteko prieigos prie mokyklos, Jūsų paskyra bei visi su ja susiję duomenys buvo pašalinti iš programavimo platformos. Jei ateityje norėsite naudotis programavimo platforma, turėsite iš naujo susikurti savo paskyrą."
        email_msg.delay(user.first_last_name, user.email, subject, message)

        db.session.delete(user)
        db.session.commit()

    ## Pašalinama paskyrų pašalinimo užklausa
    db.session.delete(delete_request)

    if failed_count == 0:
        flash("Pasirinktos mokinių paskyros sėkmingai pašalintos.", category="success")
        return jsonify({'success': 'Pasirinktos mokinių paskyros sėkmingai pašalintos.'}), 200
    else:
        flash(f"{failed_count} paskyrų nepavyko pašalinti, kitos paskyros pašalintos.", category="success")
        return jsonify({'success': f"{failed_count} paskyrų nepavyko pašalinti, kitos paskyros pašalintos."}), 200



@school_admin.route('/school_admin/api/template', methods=['POST'])
@login_required
def template_api():

    data = request.get_json()
    language = data.get('language')
    template = data.get('template')

    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': "Jūs neturite teisės pasiekti šios platformos funkcijos."})

    ## Patikriname nurodytą programavimo kalbą
    if not(language == "cpp" or language == "python3"):
        return jsonify({'error': "Neteisingai nurodyta šablono programavimo kalba."})

    ## Patikrinam nurodytą šabloną
    if len(template) >= 5000:
        return jsonify({'error': "Nurodytas šablonas yra per ilgas."})
    if '`' in template:
        return jsonify({'error': "Šablone panaudotas neleistinas simbolis"})

    ## Atnaujinama informacija
    user_school = School.query.get(current_user.school_id)
    if language == "cpp":
        user_school.cppTemplate = template
    else:
        user_school.pythonTemplate = template

    db.session.commit()
    if template != "":
        flash("Šablonas sėkmingai išsaugotas.", category="success")
        return jsonify({'success': "Šablonas sėkmingai išsaugotas."})
    else:
        flash("Šablonas sėkmingai panaikintas.", category="success")
        return jsonify({'success': "Šablonas sėkmingai panaikintas."})



@school_admin.route('/getProblemThumbnail/<problemID>')
@login_required
def getProblemThumbnail(problemID):

    problem = Problems.query.get(problemID)
    if current_user.urole != "SCHOOL-ADMIN":
        return jsonify({'error': "Jūs neturite teisės pasiekti šios platformos funkcijos."})
    if not problem or problem.school_id != current_user.school_id:
        return jsonify({'error': "Uždavinys neegzistuoja arba nepriklauso jūsų mokyklai."})

    file_path = f"/home/ubuntu/Thumbnails/{problem.id}.png"
    if os.path.exists(file_path):
        return send_file(file_path)
    else:
        return jsonify({'error': "Uždavinio viršelio nuotrauka nerasta."})